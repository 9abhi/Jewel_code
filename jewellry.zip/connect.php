<?php
	$ip = $_SERVER['REMOTE_ADDR'];
	date_default_timezone_set('Asia/Calcutta');
	
	if($ip == "127.0.0.1") {
	
		$DB_CONNECT = mysql_connect("localhost", "root", "mysql");
		mysql_select_db("jewel");
	
	} else {
		
		$DB_CONNECT = mysql_connect("localhost", "root", "mysql");
		
		mysql_select_db("jewel");
		
	}
?>