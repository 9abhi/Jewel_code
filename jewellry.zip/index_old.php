<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>create account</title>
<script src="jquery-1.9.1.min.js"></script>
</head>

<body>
<table>
<form  name="create_user" id="create_user" method="post">

<tr><td>
<input type="email" name="user_email" id="user_email"  />
</td>
</tr>
<tr><td>
<input type="password" name="password" id="password"  />
</td></tr>
<tr>
<td>
<input type="password" name="confirm_pass" id="confirm_pass"  />
</td>
</tr>
<tr>
<td>
<input type="submit" name="click_submit" id="click_submit" />
</td>
</tr>

</form>
</table>

</body>
</html>

<script>
$(document).ready(function() {
	
  
  $('#click_submit').click(function(e) {
	  e.preventDefault();
	  
	  var user_email	=	$('#user_email').val();
	  var password	  =	$('#password').val();
	  var confirm_pass  =	$('#confirm_pass').val();	
	  
	  if(user_email	==	'' || password	==	'' || confirm_pass	==	'')
	  {
		  alert('Enter required fields');
		  return false;
	  }

	var user_dat = $('form#create_user').serializeArray();
	
			
			$.ajax({
            type:"POST",
            url: "save_user.php",
			data: $.param(user_dat),
            success: function(data)
			{ 
				alert(data);
			}
			
			});
    
});
  
});

</script>