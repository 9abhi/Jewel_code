<?php
include "header.php";
?>

<!-- Top End--->

<!-- Main pic--->
<div class="inner-banner">
	<div class="diamond-p">
    <img src="assets/images/diamond-p.png" />
    </div>

    <div class="heading-b">
    <h2>The Celebrations</h2>
            <h1>DIAMOND</h1>
            <p>Collections </p> 
            <a href="#" class="order-in">Order Now!</a>
           
    </div>
</div>

<!-- Main pic End--->

<!-- Main box--->
<div class="inner-middle">

    <div class="error_box" id="error_box">
    </div>	
    
<!-- inner Box--->
	<div class="login_main-box">
	<div class="login_box">
		<h2>Welcome back to Bay Jewelers.</h2>
		<p>We're glad you've returned. We're ready to resume helping you.</p>
		
		<form  name="login_user" id="login_user" method="post">
		<div id="password-credentials">
			<div class="row">
				<label for="user_email">Email</label>
                <input type="email" name="user_email" id="user_email" size="30" tabindex="1" class="title" required  />
				
			</div>
			<div class="row">
				<label for="user_password">Password</label>
                <input type="password" name="password" id="password" size="30" tabindex="2" class="title" required  />
				
			</div>
		</div>
		<div class="rememberForgot">
			<div class="three columns alpha">
				<div style=" margin:15px 0 0;">                
                <input id="user_remember_me" name="user[remember_me]" tabindex="3" type="checkbox" value="1" class="checkboxHide">
       Remember me <a href="forgot_pass.php">Forgot Password?</a></div>
			</div>
			
		</div><br />

    
    <input type="submit" name="click_submit" id="click_submit" value="Sign In"  class="sign-in-btn" />
</form>		
	</div>
    
    
    <div class="login_box">
  <h2>Why create a Bay Jewelers account?</h2>
  <p>Once you have an account you can:</p>
  <ul>
    <li>Access your order history from one convenient location</li>
    <li>View saved favorites on any device — tablet, mobile or computer</li>
    <li>A seamless checkout experience</li>
  </ul>
  <a href="register.php"><input class="sign-in-btn" name="commit" tabindex="4" type="submit" value="Create an Account"></a>
</div>
<div class="clear"></div>
</div>

<!-- inner Box End--->

<div class="four-bnr">
    <a href="#"> <img src="assets/images/bnr-1.png" border="0" /> </a>
    <a href="#"> <img src="assets/images/bnr-2.png" border="0" /> </a>
    <a href="#"> <img src="assets/images/bnr-3.png" border="0" /> </a>
    <a href="#"> <img src="assets/images/bnr-4.png" border="0" /> </a>
    <div class="clear"></div>
    </div>
<?php
include "footer.php";
?>

<div id="saving_container" style="display:none;">
	<div id="saving" style="background-color:#000; position:fixed; width:100%; height:100%; top:0px; left:0px;z-index:100000"></div>
	<img id="saving_animation" src="assets/images/storing_animation.gif" alt="saving" style="z-index:100001; margin-left:-32px; margin-top:-32px; position:fixed; left:50%; top:50%"/>
	<div id="saving_text" style="text-align:center; width:100%; position:fixed; left:0px; top:50%; margin-top:40px; color:#fff; z-index:100001">
	Loading</div>
</div>

<script>
$(document).ready(function() {
	


  $('#click_submit').click(function(e) {
		e.preventDefault();

	 
	  
	  var user_email	=	$('#user_email').val();
	  var password	  =	$('#password').val();
	 

	  if(user_email	==	'' || password	==	'' )
	  {
		  $('#error_box').html('Enter Required Fields').show(400);
		  return false;
	  }
	  

	 
 	show_animation();
	var user_dat = $('form#login_user').serializeArray();
	
			
			$.ajax({
            type:"POST",
            url: "register/check_login.php",
			data: $.param(user_dat),
            success: function(data)
			{ 
				setTimeout('hide_animation()', 500);
			
				var bt=data.split('_');
				
				if(bt[0]=='1')
				{
					window.location='index.php';
					
				}
				else
				{
					
					$('#error_box').html(bt[1]).show(400);
					
				}
				
			}
			
			});
    
  });

});


function show_animation()
{
	$('#saving_container').css('display', 'block');
	$('#saving').css('opacity', '.8');
}

function hide_animation()
{
	$('#saving_container').fadeOut();
}


</script>