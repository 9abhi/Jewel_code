<?php
include "header.php";
include "admin/inc/function.php";

$get_user= isset($_SESSION['user_email']) ? $_SESSION['user_email'] : '';
if(!empty($get_user))
{
	$get_p=mysql_query("select * from recent_product where user_id='".$get_user."' AND sold_status='1'");
	
	$count_ab=mysql_num_rows($get_p);
	
	
?>
<!-- Top End--->

<!-- Main pic--->
<div class="inner-banner">
	<div class="diamond-p">
    <img src="assets/images/diamond-p.png" />
    </div>

    <div class="heading-b">
    <h2>The Celebrations</h2>
            <h1>DIAMOND</h1>
            <p>Collections </p> 
            <a href="#" class="order-in"> Order Now!</a>
           
    </div>
    
</div>

<!-- Main pic End--->

<!-- Main box--->
<div class="inner-middle">
<div class="leftbar-main">
	<?php
	include "category_bar.php";
	?>
    </div>
<!-- inner Box--->
	<div class="contant-box">
    <h2><?php echo 'Recent Views';  ?></h2>
       <div class="in-mtr-box">
	   <?php
	  
       if($count_ab>0)
       {
		   
		   $i=0;
           while($pro=mysql_fetch_array($get_p))
           {
			    $pr_fix	=	 get_recent_prefix($pro['type']);
			    $tabl_name = get_recent_table($pro['type']);
				$tabl_img= get_recent_img($pro['type']);
			      
				   $get_pimages	=	mysql_query("select * from $tabl_img where p_id='".$pro['pro_id']."' AND image LIKE '204x179%' LIMIT 1");
				   $count_img	  =	mysql_num_rows($get_pimages);
				   
				   if($count_img>0)
				   {
					   $p_img=mysql_fetch_array($get_pimages);
					   
				   }
              
         ?>
         
           <div class="product">
           <a style="font-size: 12px; text-decoration:none;color: #666;" href="product_details.php?product=<?=$pr_fix?>_<?=$pro['pro_id']?>">
            
            <div class="product_pic">
                
                <img src="uploads/<?=$p_img['image']?>" />
            
            </div>
            
            <?php
			$get_pinfo=mysql_query("select * from $tabl_name where id='".$pro['pro_id']."'");
			$get_inf=mysql_fetch_array($get_pinfo);
			?>
            <h3><?=$get_inf['name']?> </h3>
            <div class="product_disc">
				<?php
				$string = strip_tags($get_inf['description']);
				
				if (strlen($string) > 16) {
				
					// truncate string
					$stringCut = substr($string, 0, 500);
				
					// make sure it ends in a word so assassinate doesn't become ass...
					$string = substr($stringCut, 0, strrpos($stringCut, ' ')).'... <a style="color:#C60;" href="">More</a>'; 
				}
				echo $string;
                   ?>
            </div>
            <div class=" price_pro">
            <?=format_currency($get_inf['retail_price'])?>
            </div>
             </a>
           </div>
         
		 <?php
			   
		 	$i++;
			
           	 }
	   }
        	}
         ?>    

   
</div>

    </div>
<div class="clear"></div>
<!-- inner Box End--->

<div class="four-bnr">
    <a href="#"> <img src="assets/images/bnr-1.png" border="0" /> </a>
    <a href="#"> <img src="assets/images/bnr-2.png" border="0" /> </a>
    <a href="#"> <img src="assets/images/bnr-3.png" border="0" /> </a>
    <a href="#"> <img src="assets/images/bnr-4.png" border="0" /> </a>
    <div class="clear"></div>
    </div>
</div>
<?php
include "footer.php";
?>
