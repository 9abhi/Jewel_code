<?php
include "../connect.php";

$customer_email	=	mysql_real_escape_string(isset($_REQUEST['customer_email'])? $_REQUEST['customer_email'] : '');

$date_time	=	 date('Y-m-d H:i:s');

$query	=	mysql_query("select * from customers where email='".$customer_email."'");
$count	=	mysql_num_rows($query);
if($count>0)
{
	$password = substr(rand(0, 1000000), 0, 7);
	$m_password	=	md5($password);
	$row	=	mysql_fetch_array($query);
	$login_tm	=	mysql_query("UPDATE customers SET date_time='".$date_time."',password='".$m_password."' WHERE id='".$row['id']."'");
	if($login_tm)
	{
		$to      = $customer_email;
		$subject = 'New Password';
		$message = 'This is from Bay Jewellers. Your Password is '.$m_password;
		$headers = 'From: webmaster@example.com' . "\r\n" .
		'Reply-To: webmaster@example.com' . "\r\n" .
		'X-Mailer: PHP/' . phpversion();
		
		mail($to, $subject, $message, $headers);
		
		echo 'Password sent to your email sucessfully';
	}
	else
	{
		echo 'Something is wrong'.mysql_error();
	}
}
else
{
	echo 'Invalid Credential';
}

?>