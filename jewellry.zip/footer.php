
<!-- footer--->
	<div class="footer">
    
    <div class="botm-bar">
	<div class=" links">
   
    <!-- links-1 --->
    <div class="link-titl">COMPANY INFO.</div>
    <div class="links-box">     
            <div class="meenu">
            <p><a href="#">Home </a></p>
            <p><a href="#">About Us</a></p>
            <p><a href="#">Browse Jewelry </a></p>
            <p><a href="#">Collections </a></p>
            <p><a href="#">Contact Us </a></p>
            <div style="clear:both"></div>
            </div>   
    
    </div>

</div>

	<div class=" links">
   
    <!-- links-1 --->
    <div class="link-titl">OTHER LINKS</div>
    <div class="links-box">     
            <div class="meenu">
            <p><a href="#">Top Sellers</a></p>
            <p><a href="#">Specials</a></p>
            <p><a href="#">Legeal Notice </a></p>
            <p><a href="#">Term & Conditions</a></p>
            <p><a href="#">Sitemap</a></p>
            </div>   
    
    </div>
</div>

	<div class=" links">
   
    <!-- links-1 --->
    <div class="link-titl">EDUCATION</div>
    <div class="links-box">     
            <div class="meenu">
            <p><a href="#">Color </a></p>
            <p><a href="#">Clarity</a></p>
            <p><a href="#">Cut </a></p>
            <p><a href="#">Carat Weight </a></p>

            </div>   
    
    </div>
</div>

	<div class="social_box">
    	<div class="social-icon-bar">
        	<h2>Follow Us : </h2>
            
			

            <div class="social-icon">
            	<ul>
                	<li><a href="#" class="tooltip" title="Facebook"> <img src="assets/images/fb-icon.png" /></a></li>
                	<li><a href="#" class="tooltip" title="Twitter"> <img src="assets/images/twt-icon.png" /></a></li>
                	<li><a href="#" class="tooltip" title="Google +"> <img src="assets/images/g-icon.png" /></a></li>
                	<li><a href="#" class="tooltip" title="Pinterest"> <img src="assets/images/p-icon.png" /></a></li>
                
                </ul>
            </div>
            <div class="clear"></div>
        </div>
        
        <div class="newsltr_box">
         <input data-provide="typeahead" placeholder="Receive our email newsletter" name="txtQ" autocomplete="off" type="text">
         <input type="submit" name="sign-up" id="sign-up" value="Sign Up"  />
         
             <div class=" clear"></div>
        </div>
    </div>

<div style="clear:both"></div>
</div>
    
    
    </div>

<!-- footer End--->


<!-- Main box end--->

</div>


<div class=" footer-2">
<div class="footr-grid">
  <div class="fotr-cont"> Powered By : WEBCHILLI </div>
  <div class="fotr-cont2"> © 2014 Bay Jewelers All Rights Reserved</div>
  <div class="clear"></div>
  </div>
</div>

</div>

</body>

</html>