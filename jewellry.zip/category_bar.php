
<div class="left-bar">
    	<div class="left-bar-titl"> Browse Jewelry</div>
        	<div class="prod-range">
            	<ul>
                <?php
				
				$type_query=mysql_query("select * from product_type");
				$count_type = mysql_num_rows($type_query);
				if($count_type>0)
				{
					while($row=mysql_fetch_array($type_query))
					{
						if($t_name[0]=='P')
						{
						$active = isset($type_id) ? $type_id : '';
						}else
						{
							$active='';
						}
					?>
                    <li <?php if($active != '' && $active == $row['id']){ echo 'class="active"'; } else {} ?>>
                    <a href="browse.php?pro=P_<?=$row['id']?>"><?=$row['name']?>
                    <span><img src="uploads_type/<?=$row['image']?>" border="0" /></span>
                    
                    <div class="clear"></div>
                    </a>
                    </li>
						
					<?php
                    }
					
				}
				
				?>
                	

                
                </ul>  

            <div class="clear"></div>
            </div>
            
            <div class="link2">
	 		<a href="browse.php?pro=D_all">Loose Diamonds</a> | <a href="browse.php?pro=G_all">Gemstones</a> | <a href="browse.php?pro=Pl_all">Pearls</a>
            </div>
        	
        
        <div class="left-bar-titl"> Collections</div>
        
        <div class="collect">
        	<ul>
             <?php
		$collections_query	=	mysql_query("select * from collection_type ");
		$count_c			  =	mysql_num_rows($collections_query);
		if($count_c>0)
		{
			while($row_coll=mysql_fetch_array($collections_query))
			{
				
		?>
        <li><a href="browse.php?pro=C_<?=$row_coll['id']?>"><?=$row_coll['name']?></a></li>
		<?php
			}
		}
		?>
            	
            </ul>
        
        </div>
        
        
        
       
    </div>