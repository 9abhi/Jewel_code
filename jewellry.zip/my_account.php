<?php
include "header.php";
include "connect.php";
$get_user_details=mysql_query("select * from customers where email='".$_SESSION['user_email']."'");
$get_data=mysql_fetch_array($get_user_details);
?>
<!-- Top End--->

<!-- Main pic--->
<div class="inner-banner">
	<div class="diamond-p">
    <img src="assets/images/diamond-p.png" />
    </div>

<div class="heading-b">
<h2>The Celebrations</h2>
    	<h1>DIAMOND</h1>
        <p>Collections </p> 
        <a href="#" class="order-in"> Order Now!</a>
       
</div>
</div>

<!-- Main pic End--->

<!-- Main box--->
<div class="inner-middle">
	<div class="error_box" id="error_box">
    </div>
<!-- inner Box--->
	<div class="login_main-box">
	<div class="login_box" style="width:100%; margin:0 auto;">
		<div class="page_titl">My Account</div><br />

        
        <form  name="update_account" id="update_account" method="post" style="width:auto;">
		
        <div class="my_account_bar">
        <div class="col_grid_2">
        <h2>First Name</h2><div class="input_box"><input type="text" name="fname" value="<?=$get_data['fname']?>" id="fname" placeholder="First Name" />*</div>
		</div>
        <div class="col_grid_2">
        <h2>Middle Name</h2><div class="input_box"><input type="text" name="mname" placeholder="Middle Name" value="<?=$get_data['mname']?>" /></div>
        </div>
        <div class="col_grid_2">
        <h2>Last Name</h2><div class="input_box"><input type="text" name="lname" id="lname" placeholder="Last Name" value="<?=$get_data['lname']?>" />*</div>
        </div>
        <br />
			<div class="clear"></div>
                <div class="col_grid_2">
        <h2>Addressline 1</h2><div class="input_box"><textarea rows="4" cols="15" name="address1"><?=$get_data['addressline1']?></textarea></div>
        </div>
        
        <input type="hidden" value="<?=$_SESSION['user_email']?>" name="email_user" />
		<div class="col_grid_2">
        <h2>Addressline 2</h2><div class="input_box"><textarea rows="4" cols="15" name="address2"><?=$get_data['addressline2']?></textarea></div>
        </div>
        
        <div class="col_grid_2">
        <h2>City</h2><div class="input_box"><input type="text" name="city" placeholder="City" value="<?=$get_data['city']?>" ></div>
        </div>
        
        <div class="col_grid_2">
        <h2>State</h2><div class="input_box"><select name="state" style="padding:10px;">
        <?php
		$st_query=mysql_query("select * from states");
		while($row=mysql_fetch_array($st_query))
		{
			if($row['code']==$get_data['state'])
			{
			 ?>
				<option value="<?=$row['code']?>" selected="selected"><?=$row['state']?></option>	
		<?php
			}else
			{?>
				<option value="<?=$row['code']?>" ><?=$row['state']?></option>
		<?php	}
        }
		?>
        </select></div>
        </div>
        
         <div class="col_grid_2">
        <h2>Email</h2><div class="input_box"><input type="email" placeholder="Email" name="email" value="<?=$get_data['email']?>" disabled /></div>
        </div>
        
          <div class="col_grid_2">
        <h2>New Password</h2><div class="input_box"><input type="password" name="pass" placeholder="password" /></div>
        </div>
       
          <div class="col_grid_2">
        <h2>New Confirm Password</h2><div class="input_box"><input type="password" name="confirm_pass" placeholder="Confirm password" /></div>
        </div>

		  <div class="col_grid_2">
        <h2>Phone1</h2><div class="input_box"><input type="password" name="phone1" placeholder="phone1"  value="<?=$get_data['phone1']?>" /></div>
        </div>
        
          <div class="col_grid_2">
        <h2>Phone2</h2><div class="input_box"><input type="password" name="phone2" placeholder="phone2" value="<?=$get_data['phone2']?>" /></div>
        </div>
        
        <div class="clear"></div>
        </div>
			
	<input type="submit" name="update_acc" id="update_acc" value="Update" class="updat-b" style="float:right; margin-right:120px; margin-bottom:50px; padding:10px 25px;" />

</form>
	
	</div>
    
    
    
<div class="clear"></div>
</div>

<!-- inner Box End--->

<div class="four-bnr">
    <a href="#"> <img src="assets/images/bnr-1.png" border="0" /> </a>
    <a href="#"> <img src="assets/images/bnr-2.png" border="0" /> </a>
    <a href="#"> <img src="assets/images/bnr-3.png" border="0" /> </a>
    <a href="#"> <img src="assets/images/bnr-4.png" border="0" /> </a>
    <div class="clear"></div>
    </div>

<?php
include "footer.php";
?>

<div id="saving_container" style="display:none;">
	<div id="saving" style="background-color:#000; position:fixed; width:100%; height:100%; top:0px; left:0px;z-index:100000"></div>
	<img id="saving_animation" src="assets/images/storing_animation.gif" alt="saving" style="z-index:100001; margin-left:-32px; margin-top:-32px; position:fixed; left:50%; top:50%"/>
	<div id="saving_text" style="text-align:center; width:100%; position:fixed; left:0px; top:50%; margin-top:40px; color:#fff; z-index:100001">
	Creating Account</div>
</div>

<script>
$(document).ready(function() {
	
  
  $('#update_acc').click(function(e) {
	  e.preventDefault();
	  
	  var fname	=	$('#fname').val();
	  var lname	=	$('#lname').val();
	  var password	  =	$('#password').val();
	  var confirm_pass  =	$('#confirm_pass').val();	
	  
	  if(password != confirm_pass)
	  {
		  $('#error_box').html('Password did not match').show(400);
		  return false;
	  }
	  if(fname =='' || lname=='')
	  {
		$('#error_box').html('Enter required fields').show(400);
		return false; 
	  }
	show_animation();
	var user_dat = $('form#update_account').serializeArray();
	
	
			
			$.ajax({
            type:"POST",
            url: "register/update_account.php",
			data: $.param(user_dat),
            success: function(data)
			{ 
				setTimeout('hide_animation()', 500);
									
					$('#error_box').html(data).show(400);
					
				
			}
			
			});
    
});
  
});

function show_animation()
{
	$('#saving_container').css('display', 'block');
	$('#saving').css('opacity', '.8');
}

function hide_animation()
{
	$('#saving_container').fadeOut();
}
</script>