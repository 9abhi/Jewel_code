<?php
include "header.php";
include "admin/inc/function.php";
include "connect.php";

$get_type_id	=	isset($_REQUEST['pro']) ? $_REQUEST['pro'] : '';


$t_name	= explode('_',$get_type_id);
$type_id	=	$t_name[1];
if($t_name[0]=='P')
{
	$table_name='product';
	$table_img = 'product_images';
}
else if($t_name[0]=='D')
{
	$table_name='diamond';
	$table_img = 'diamond_images';
	$page_title='Diamond';
}
else if($t_name[0]=='Pl')
{
	$table_name='pearl';
	$table_img = 'pearl_images';
	$page_title='Pearl';
}
else if($t_name[0]=='S')
{
	$table_name='setting';
	$table_img = 'setting_images';
	$page_title='Setting';
}
else if($t_name[0]=='C')
{
	$table_name='product';
	$table_img = 'product_images';
}
else if($t_name[0]=='G')
{
	$table_name='gemstone';
	$table_img = 'gemstone_images';
	$page_title='Gemstone';
}

if(!empty($get_type_id) )
{
	if(!empty($get_type_id))
	{
		if($t_name[0]=='P')
		{
		$get_pro_type	=	mysql_query("select * from $table_name where type = '".$type_id."' AND sold_status='0'");
		$get_title	   =    mysql_query("select name from product_type where id='".$type_id."'");
		
		$title	   =	mysql_fetch_array($get_title);
		$page_title	=	$title['name'];
		$count_pro	=	mysql_num_rows($get_pro_type);
	   }
	   else if($t_name[0]=='C')
	   {
		   
	   	$get_pro_type	=	mysql_query("select * from $table_name where collection LIKE '%".$type_id."%' AND sold_status='0'");
		$get_title	   =    mysql_query("select name from collection_type where id='".$type_id."'");
		
		$title	   =	mysql_fetch_array($get_title);
		$page_title	=	$title['name'];
		
		$count_pro	=	mysql_num_rows($get_pro_type);
		
	   }
	   else 
	   {
	   	$get_pro_type	=	mysql_query("select * from $table_name WHERE sold_status='0'");
	   	
	   	$count_pro	=	mysql_num_rows($get_pro_type);
	   }
	   
	}
	
	
?>
<!-- Top End--->

<!-- Main pic--->
<div class="inner-banner">
	<div class="diamond-p">
    <img src="assets/images/diamond-p.png" />
    </div>

<div class="heading-b">
<h2>The Celebrations</h2>
    	<h1>DIAMOND</h1>
        <p>Collections </p> 
        <a href="#" class="order-in"> Order Now!</a>
       
</div>
</div>

<!-- Main pic End--->

<!-- Main box--->
<div class="inner-middle">
	
    
    <div class="leftbar-main">
    <?php
	
	include "category_bar.php";
	
	?>
    
  <div style="clear:both;"></div>
    <div class="recently_box">
    
    <?php
	
	if(!empty($_SESSION['user_id']) && empty($_SESSION['user_email']))
	{
		$get_id	=	$_SESSION['user_id'];
	}
	else if(!empty($_SESSION['user_email']))
	{
		$get_id	=	$_SESSION['user_email'];
	}
		$get_recent 	=	mysql_query("select * from recent_product where user_id = '".$get_id."' AND sold_status='0' ORDER BY start_time DESC LIMIT 3");
		$get_r_count   =	mysql_num_rows($get_recent);
		if($get_r_count>0)
		{
			 echo '<div class="left-bar-titl"  >Recent View Products</div>';
			 echo '<div class="recently-view"><ul>';
			while($r_pro 	= mysql_fetch_array($get_recent))
			{
				$recent_table=get_recent_table($r_pro['type']);
				$recent_img=get_recent_img($r_pro['type']);
				$recent_prefix =get_recent_prefix($r_pro['type']);
				
				$get_r_prods	   =	mysql_query("select id,name from $recent_table where id= '".$r_pro['pro_id']."'");
				$get_name_count	=	mysql_num_rows($get_r_prods);
				if($get_name_count>0)
				{
					
					$get_name=mysql_fetch_array($get_r_prods);
					$get_r_img	=	mysql_query("select image from $recent_img where p_id='".$r_pro['pro_id']."' AND image LIKE '60x58%' LIMIT 1 ");
					$get_img	=	mysql_fetch_array($get_r_img);
					
				
	?>
   
        
           
                	
                    <li><a href="product_details.php?product=<?=$recent_prefix?>_<?=$get_name['id']?>"><img src="uploads/<?=$get_img['image']?>" /><?=$get_name['name']?></a></li>

           
     <?php
	 		 }
			 
			}
			
			echo '</ul></div>';
            echo '<a class="recnt-more" href="#">[ More ]</a>';
            
			
		}
	
	 ?>       
         
         
                  <div style="clear:both;"></div>
        </div>
        
        </div>
  
<!-- inner Box--->

	<div class="contant-box">
    <h2><?php echo isset($page_title) ? $page_title : 'No Type Assigned';  ?></h2>
       <div class="in-mtr-box">
	   <?php
       if($count_pro>0)
       {
		   $i=0;
           while($pro=mysql_fetch_array($get_pro_type))
           {
			     
				   
              
         ?>
         
           <div class="product">
           <a style="font-size: 12px; text-decoration:none;color: #666;" href="product_details.php?product=<?=$t_name[0]?>_<?=$pro['id']?>">
            <div class="product_pic">
            <?php
			$get_pimages	=	mysql_query("select * from $table_img where p_id='".$pro['id']."' AND image LIKE '204x179%' LIMIT 1");
				   $count_img	=	mysql_num_rows($get_pimages);
				   
				   if($count_img>0)
				   {
					   $p_img=mysql_fetch_array($get_pimages);
					   ?>
					   <img src="uploads/<?=$p_img['image']?>" />
				   <?php 
				   }
				   else
				   {
					   ?>
                       <img src="uploads/index.gif" height="168px" width="190px" />
					   <?php
				   }
				   ?>
                
            </div>
            <h3><?=$pro['name']?> </h3>
            <div class="product_disc">
				<?php
				$string = strip_tags($pro['description']);
				
				if (strlen($string) > 16) {
				
					// truncate string
					$stringCut = substr($string, 0, 500);
				
					// make sure it ends in a word so assassinate doesn't become ass...
					$string = substr($stringCut, 0, strrpos($stringCut, ' ')).'... <a style="color:#C60;" href="">More</a>'; 
				}
				echo $string;
                   ?>
            </div>
            <div class=" price_pro">
            <?=format_currency($pro['retail_price'])?>
            </div>
             </a>
           </div>
         
		 <?php
			   
		 	$i++;
			
           	 }
        	}
         ?>    

   <div class="clear"></div>
</div>

    </div>
  

<div class="clear"></div>
  <br />
<!-- inner Box End--->

<div class="four-bnr">

    <a href="#"> <img src="assets/images/bnr-1.png" border="0" /> </a>
    <a href="#"> <img src="assets/images/bnr-2.png" border="0" /> </a>
    <a href="#"> <img src="assets/images/bnr-3.png" border="0" /> </a>
    <a href="#"> <img src="assets/images/bnr-4.png" border="0" /> </a>
    
    </div>
    <div class="clear"></div>
    
    </div>

<?php
}

include "footer.php";
?>

