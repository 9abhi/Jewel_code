<?php
include "header.php";
include "connect.php";
$get_about=mysql_query("select * from pages where name='front'");
$count_ab=mysql_num_rows($get_about);
if($count_ab>0)
{
	$get_content=mysql_fetch_array($get_about);	
}
?>

<!-- Top End--->



<!-- Main pic--->
<div class="main-pic-box">

<div class="slogan-b">
	<h2>The Celebrations</h2>
    	<h1>DIAMOND</h1>
        <p>Collections <a href="#" class="order-n"> Order Now!</a></p> 

</div>
</div>

<!-- Main pic End--->

<!-- Main box--->
<div class="main-middle">
	<div class="four-bnr">
    <a href="#"> <img src="assets/images/bnr-1.png" border="0" /> </a>
    <a href="#"> <img src="assets/images/bnr-2.png" border="0" /> </a>
    <a href="#"> <img src="assets/images/bnr-3.png" border="0" /> </a>
    <a href="#"> <img src="assets/images/bnr-4.png" border="0" /> </a>
    <div class="clear"></div>
    </div>

<!-- Welcome Box--->
	<div class="welcome-box">
    	<div class="title-bar">
        <div class="name-pic"><img src="assets/images/welcome-font.png" /></div>
                <div class="name-pic" style="float:right;"><img src="assets/images/stones-p1.png" /></div>
                    <div class="clear"></div>

        </div>
        
        <div class="mtr-box">
	<h2><?=$get_content['title']?></h2>
    <p><?=$get_content['description']?></p>
</div>
<a href="about.php" class="more-link">Know More</a>

 <div class="clear"></div>
    	
    </div>

<!-- Welcome Box end --->

<?php
include "footer.php";
?>
