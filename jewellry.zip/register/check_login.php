<?php
include "../connect.php";

session_start();
$user_email	=	mysql_real_escape_string(isset($_REQUEST['user_email'])? $_REQUEST['user_email'] : '');
$password	  =	mysql_real_escape_string(isset($_REQUEST['password'])? $_REQUEST['password'] : '');

$date_time	=	 date('Y-m-d H:i:s');

if(!filter_var($user_email, FILTER_VALIDATE_EMAIL))
{
  echo "4_E-mail is not valid";
}
else
{
$query	=	mysql_query("select * from customers where email='".$user_email."' and password	= '".md5($password)."'");
$count	=	mysql_num_rows($query);
if($count>0)
{
	$row	=	mysql_fetch_array($query);
	$login_tm	=	mysql_query("UPDATE customers SET date_time='".$date_time."' WHERE id='".$row['id']."'");
		if($login_tm)
		{
			$_SESSION['user_email']=$user_email;
			echo '1_Login sucessfully';
			
		}
		else
		{
			echo '2_Something is wrong'.mysql_error();
		}
	}
	else
	{
		echo '0_Invalid Credential';
	}
}
?>