<?php
include "../connect.php";
session_start();
$user_email	=	mysql_real_escape_string(isset($_REQUEST['user_email'])? $_REQUEST['user_email'] : '');
$password	  =	mysql_real_escape_string(isset($_REQUEST['password'])? $_REQUEST['password'] : '');
$confirm_pass  =	mysql_real_escape_string(isset($_REQUEST['confirm_pass'])? $_REQUEST['confirm_pass'] : '');
$date_time	=	 date('Y-m-d H:i:s');

if(!filter_var($user_email, FILTER_VALIDATE_EMAIL))
  {
  echo "4_E-mail is not valid";
  
  }
else
{  
$query=mysql_query("select * from customers where email='".$user_email."'");
$count	=	mysql_num_rows($query);
if($count>0)
{
	echo '3_Email already taken';
}
else if($password	==	$confirm_pass)
{
	$enc_password	=	md5($password);
	$result	=	mysql_query("INSERT INTO customers SET email='".$user_email."' ,password = '".$enc_password."',date_time='".$date_time."'");
	if($result)
	{
		
		$to      = $user_email;
		$subject = 'Thanks';
		$message = 'This is from Bay Jewellers. Your Username is'.$user_email.'</br>Password is '.$password;
		$headers = 'From: webmaster@example.com' . "\r\n" .
		'Reply-To: webmaster@example.com' . "\r\n" .
		'X-Mailer: PHP/' . phpversion();
		
		mail($to, $subject, $message, $headers);
		
		$_SESSION['user_email']=$user_email;
		echo '1_Account created successfully';
		
		
	}
	else
	{
		echo '2_Oops something is wrong'.mysql_error();
	}
	
	
}
else if($password != $confirm_pass)
{
	echo '0_Password did not match';	
}
}
?>