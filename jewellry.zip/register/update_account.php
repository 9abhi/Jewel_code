<?php
include "../connect.php";
session_start();

$fname		=	trim(isset($_REQUEST['fname'])? $_REQUEST['fname'] : '');
$mname		=	trim(isset($_REQUEST['mname'])? $_REQUEST['mname'] : '');
$lname		=	trim(isset($_REQUEST['lname'])? $_REQUEST['lname'] : '');
$address1		=	isset($_REQUEST['address1'])? $_REQUEST['address1'] : '';
$address2		=	isset($_REQUEST['address2'])? $_REQUEST['address2'] : '';
$city		=	isset($_REQUEST['city'])? $_REQUEST['city'] : '';
$email_user		=	isset($_REQUEST['email_user'])? $_REQUEST['email_user'] : '';
$state		=	isset($_REQUEST['state'])? $_REQUEST['state'] : '';
$password	 =	mysql_real_escape_string(isset($_REQUEST['pass'])? $_REQUEST['pass'] : '');
$confirm_pass  =	mysql_real_escape_string(isset($_REQUEST['confirm_pass'])? $_REQUEST['confirm_pass'] : '');
$date_time	=	 date('Y-m-d H:i:s');


if(empty($password) && empty($confirm_pass))
{	
	$result	=	mysql_query("UPDATE customers SET fname='".$fname."',mname='".$mname."',lname='".$lname."',addressline1='".$address1."',addressline2='".$address2."',city='".$city."',state='".$state."',date_time='".$date_time."',phone1='".$phone1."',phone2='".$phone2."' WHERE email='".$email_user."'");
	if($result)
	{
		
		$to      = $email_user;
		$subject = 'Thanks';
		$message = 'This is from Bay Jewellers. Information successfully updated';
		$headers = 'From: webmaster@example.com' . "\r\n" .
		'Reply-To: webmaster@example.com' . "\r\n" .
		'X-Mailer: PHP/' . phpversion();
		
		mail($to, $subject, $message, $headers);
		
		
		echo 'Account created successfully';
		
		
	}
	else
	{
		echo 'Oops something is wrong'.mysql_error();
	}
}else
{
	$enc_pass=md5($password);
	$enc_confirm=md5($confirm_pass);
	if($enc_pass==$enc_confirm)
	{
	$result	=	mysql_query("UPDATE customers SET fname='".$fname."',mname='".$mname."',lname='".$lname."',addressline1='".$address1."',addressline2='".$address2."',city='".$city."',state='".$state."',date_time='".$date_time."',phone1='".$phone1."',phone2='".$phone2."',password='".$enc_pass."' WHERE email='".$email_user."'");
	if($result)
	{
		
		$to      = $email_user;
		$subject = 'Thanks';
		$message = 'This is from Bay Jewellers. Your Username is'.$email_user.'</br>Password is '.$password;
		$headers = 'From: webmaster@example.com' . "\r\n" .
		'Reply-To: webmaster@example.com' . "\r\n" .
		'X-Mailer: PHP/' . phpversion();
		
		mail($to, $subject, $message, $headers);
		
		
		echo 'Account created successfully';
		
		
	}
	else
	{
		echo 'Oops something is wrong'.mysql_error();
	}
	}else
	{
		echo 'Password did not match';
	}
}
	


?>