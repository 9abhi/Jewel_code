<?php
include "header.php";

?>
<!-- Top End--->

<!-- Main pic--->
<div class="inner-banner">
	<div class="diamond-p">
    <img src="assets/images/diamond-p.png" />
    </div>

    <div class="heading-b">
    <h2>The Celebrations</h2>
            <h1>DIAMOND</h1>
            <p>Collections </p> 
            <a href="#" class="order-in"> Order Now!</a>
           
    </div>
    
</div>

<!-- Main pic End--->

<!-- Main box--->
<div class="inner-middle">
<div class="leftbar-main">
	<?php
	include "category_bar.php";
$get_about=mysql_query("select * from pages where name='about'");
$count_ab=mysql_num_rows($get_about);
if($count_ab>0)
{
	$get_content=mysql_fetch_array($get_about);	
}
	?>
    </div>

<!-- inner Box--->
	<div class="contant-box">
    <h2><?php
	echo $get_content['title'];
    ?></h2>
       <div class="in-mtr-box">
    <p><?php
	echo $get_content['description'];
    ?></p>
</div>

    </div>
<div class="clear"></div>
<!-- inner Box End--->

<div class="four-bnr">
    <a href="#"> <img src="assets/images/bnr-1.png" border="0" /> </a>
    <a href="#"> <img src="assets/images/bnr-2.png" border="0" /> </a>
    <a href="#"> <img src="assets/images/bnr-3.png" border="0" /> </a>
    <a href="#"> <img src="assets/images/bnr-4.png" border="0" /> </a>
    <div class="clear"></div>
    </div>
</div>
<?php
include "footer.php";
?>
