<?php
include "header.php";

?>
<!-- Top End--->

<!-- Main pic--->
<div class="contact-bnr">
<img src="assets/images/contact-p.jpg" /></div>


<!-- Main pic End--->

<!-- Main box--->
<div class="inner-middle">
<div class="leftbar-main">
	<?php
	include "category_bar.php";
$get_contact=mysql_query("select * from pages where name='contact'");
$count_ab=mysql_num_rows($get_contact);
if($count_ab>0)
{
	$get_content=mysql_fetch_array($get_contact);	
}
	?>
    </div>

<!-- inner Box--->
	<div class="contant-box">
    <h2><?=$get_content['title']?></h2>
       <div class="in-mtr-box">
    <p><?php echo  htmlspecialchars_decode($get_content['description'], ENT_QUOTES);?></p>
      </div>

    </div>
<div class="clear"></div>
<!-- inner Box End--->

<div class="four-bnr">
    <a href="#"> <img src="assets/images/bnr-1.png" border="0" /> </a>
    <a href="#"> <img src="assets/images/bnr-2.png" border="0" /> </a>
    <a href="#"> <img src="assets/images/bnr-3.png" border="0" /> </a>
    <a href="#"> <img src="assets/images/bnr-4.png" border="0" /> </a>
    <div class="clear"></div>
    </div>
</div>
<?php
include "footer.php";
?>
