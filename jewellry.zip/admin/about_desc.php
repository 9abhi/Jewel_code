<?php
include "inc/connect.php";
$about_desc	=	isset($_REQUEST['about_desc']) ? trim($_REQUEST['about_desc']) : '';
$page_title    =	isset($_REQUEST['page_title']) ? trim($_REQUEST['page_title']) : '';

if(isset($_REQUEST['add_about']))
{
$chk_query	=	mysql_query("select * from pages where name='about'");
$chk_count	=	mysql_num_rows($chk_query);
if($chk_count>0)
{
	$up_abt	=	mysql_query("UPDATE pages SET description='".$about_desc."',title='".$page_title."' WHERE name='about'");
	if($up_abt)
	{
		$response	=	'Update successfully';
		echo("<script>window.location=\"about.php?response=".urlencode($response)."\"</script>");
	}
	else
	{
		$response	=	'Oops'.mysql_error();
		echo("<script>window.location=\"about.php?response=".urlencode($response)."\"</script>");
		
	}
}
else
{

$query = "INSERT INTO pages (name,description,title) VALUES ('about','".$about_desc."','".$page_title."')";
$result=mysql_query($query);
	if($result)
	{
		$response	=	'Submitted successful!';
		echo("<script>window.location=\"about.php?response=".urlencode($response)."\"</script>");	
	}
	
	
}
	
}


								
								   
									
?>