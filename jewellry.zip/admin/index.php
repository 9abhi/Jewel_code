<?PHP

	include "inc/connect.php";
	
	$query	= "select * from admin where status='1' LIMIT 1";
	$result   = mysql_query($query);
	if(isset($result))
	{
		$get_check	=	mysql_fetch_array($result);
		$user		=	isset($get_check['user_name'])? $get_check['user_name'] : '';
		$password	=	isset($get_check['password'])? $get_check['password'] : '';
	
	}
	
	$enter_username	=	mysql_real_escape_string($_SERVER['PHP_AUTH_USER']);
	$enter_password	=	md5(mysql_real_escape_string($_SERVER['PHP_AUTH_PW']));

	if(($enter_username == $user) && ($enter_password == $password))		{
		header('Location: dashboard.php');
	}
	else	{
		
        header("WWW-Authenticate: "."Basic realm=\"Restricted Area\"");
        header("HTTP/1.0 401 Unauthorized");
        print("This page is protected by HTTP " ."Authentication.<br>\n "."Enter Correct Username and Password or consult administrator" );
		print($password);
	
	}
	
?>