<?php
include "inc/header.php";
include "inc/connect.php";
include "inc/function.php";

?>
<link href="bootstrap/css/DT_bootstrap.css" rel="stylesheet" media="screen">
<script src="bootstrap/js/jquery.dataTables.min.js"></script>
<script src="bootstrap/js/DT_bootstrap.js"></script>
<div class="container-fluid">
            <div class="row-fluid">
                <?PHP	include 'sidebar.php'	?>
                <!--/span-->
                <div class="span9" id="content">
                      <!-- morris stacked chart -->
                    <div class="row-fluid">
                        <!-- block -->
                        <?php
                                $response=$_REQUEST[response];
                                if($response)
                                {
                                ?>
        <div class="alert alert-success">
          
          <button class="close" data-dismiss="alert">&times;</button>
          <strong>
          <?=$response;?>
          </strong>
          
        </div>
        <?php
		}
		?>
                            <div class="block-content collapse in">

                                <div class="span12">
                                
                                     <div class="block">
                            <div class="navbar navbar-inner block-header">
                                <div class="muted pull-left">Products</div>
                            </div>

                            <div class="block-content collapse in">


                                <div class="span12">

                                		<span class="btn-group pull-right">
						
								<a class="btn" style="font-weight:normal;" href="product.php"><i class="icon-plus-sign"></i>Add Product</a>
									<br />
									
								</span>

  									<table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered" id="example">
										<thead>
											<tr>
											<th>Sr. no</th>
												<th>Type</th>
												<th>Name</th>
												<th>Collection</th>
												<th>Retail Price</th>
												<th>Excerpt</th>
												<th></th>
												<th></th>
												
											</tr>
										</thead>
										<tbody>
                                        <?php
										
                                        $i=1;
										$pro_query=mysql_query("select pt.collection,pt.id,pt.name,pt.retail_price,pt.excerpt,py.name as type from product pt 			 																JOIN product_type py ON pt.type=py.id WHERE sold_status='0' ");
										$count_pro=mysql_num_rows($pro_query);
										if($count_pro>0)
										{
											while($p=mysql_fetch_array($pro_query))
											{ 
											
											
											?>
													 
													
                                            <tr class="gradeC">
                                            <td style="text-align:center;"><?=$i?></td>
												<td><?=$p['type']?></td>
												<td><?=$p['name']?></td>
												<td>
												<?php
												
												$arr=explode(',',$p['collection']);
												foreach($arr as $a)
												{
													
													$coll_query=mysql_query("select name from collection_type where id='".$a."'");
													$coll_data=mysql_fetch_array($coll_query);
													echo $coll_data['name'].',';
													
												}
												?>
                                                
                                                </td>
												<td><?=$p['retail_price']?></td>
												<td><?=$p['excerpt']?></td>
												<td style="text-align:center;"><a class="btn" href="edit_product.php?pro=<?=$p['id']?>"><i class="icon-pencil"></i>Edit</a></td>
												<td style="text-align:center;"><a class="btn btn-danger"  onclick="return areyousure(<?=$p['id']?>);"><i class="icon-trash icon-white"></i>Delete</a></td>
												
											</tr>
							
												<?php 
													$i++;
												}
												
											
											
										}
										?>
											
											
											
											
										</tbody>
									</table>
                                </div>
                            </div>
                        </div>

                                </div>
                            </div>
                        
                        <!-- /block -->
                    </div>

                     

                     <!-- wizard -->
                    

                </div>
            </div>
            <hr>
            

<?php
include "inc/footer.php";
?> 
<script>
function areyousure(id)
{
	
	var answer=confirm("Are you sure you want to continue");
	if (answer==true)
	  {
		
	$.ajax({
            type:"POST",
            url: "del_img/del_pro.php",
			data: {'id':id},
            success: function(data)
			{ 
			alert(data);
			location.reload();
			}
	});
	  }
	else
	{
		return false;
	}
}
</script>
