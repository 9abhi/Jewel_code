<?php
include "../inc/connect.php";
$result = mysql_query("show tables from jewel"); // run the query and assign the result to $result
$count_tabl=mysql_num_rows($result);
if($count_tabl>0)
{
	$ij=0;
	while($table = mysql_fetch_array($result)) 
	{ // go through each row that was returned in $result
	   
	   if($table[0]== 'all_products' || $table[0]== 'admin' || $table[0]== 'states' )
	   {
		 
		   
	   }else
	   {
		   
			$t_query=mysql_query("TRUNCATE TABLE $table[0]");
			$ij++;
	   }
	   
	}
	if($ij+3==$count_tabl)
	{
		echo 'Truncate db Successfully';
		
	}else
	{
		echo 'Oops something is wrong';
	}
}else
{
	echo 'No Tables';
}
?>