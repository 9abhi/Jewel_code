<?php
include "inc/connect.php";
include "inc/function.php";

$shape		=	isset($_REQUEST['shape']) 	  ? $_REQUEST['shape'] 	   : '';
$name 		 =	isset($_REQUEST['name'])       ? $_REQUEST['name']        : '';
$update_id	=    isset($_REQUEST['update_id'])  ? $_REQUEST['update_id']   : '';

$color        =    isset($_REQUEST['color'])      ? $_REQUEST['color']       : '';
$retail_price =    isset($_REQUEST['retail_price'])	 ? $_REQUEST['retail_price'] 	  : '';

$vendor      =	isset($_REQUEST['vendor'])	? $_REQUEST['vendor'] 	 : '';
$depth 	   =	isset($_REQUEST['depth']) ? $_REQUEST['depth'] 	   : '';

$table_data  =	isset($_REQUEST['table_data']) ? $_REQUEST['table_data'] 	   : '';
$cut 	     =	isset($_REQUEST['cut']) ? $_REQUEST['cut'] 	   : '';
$clarity 	 =	isset($_REQUEST['clarity']) ? $_REQUEST['clarity'] 	   : '';
$polish 	  =	isset($_REQUEST['polish']) ? $_REQUEST['polish'] 	   : '';

$symmetry 	=	isset($_REQUEST['symmetry']) ? $_REQUEST['symmetry'] 	   : '';

$flourescence=	isset($_REQUEST['flourescence']) ? $_REQUEST['flourescence'] 	   : '';
$culet 	   =	isset($_REQUEST['culet']) ? $_REQUEST['culet'] 	   : '';

$p_desc 	  =	trim(isset($_REQUEST['p_desc']) ? $_REQUEST['p_desc'] 	   : '');
$l_w 	     =	isset($_REQUEST['l_w']) ? $_REQUEST['l_w'] 	   : '';
$p_desc = htmlspecialchars($p_desc, ENT_QUOTES);

$date_time = date('Y-m-d H:i:s');

if(isset($_REQUEST['add_diamond']))
{
	if(empty($update_id))
	{
		
	if(!empty($name))
	{
		
	$query	=	mysql_query("INSERT INTO diamond VALUES('','".$shape."','".$name."','".$carat."','".$color."','".$cut."',
	'".$clarity."','".$polish."','".$symmetry."','".$depth."','".$table_data."','".$flourescence."','".$culet."','".$l_w."','".$p_desc."','".$vendor."','".$retail_price."','0','0','".$date_time."')");
	if(isset($query))
	{
		$p_id		=	 mysql_insert_id();
		$response	=	'Diamond Submitted successfully';
	
			if ($_SERVER['REQUEST_METHOD'] == 'POST' AND isset($_FILES['image'])) 
			{
				
				// settings
				$max_file_size = 1024*200; // 200kb
				$valid_exts = array('jpeg', 'jpg', 'png', 'gif');
				// thumbnail sizes
				$sizes = array(60 => 58, 204 => 179, 900 => 900);
				 
				  if($_FILES['image']['tmp_name'][0]=='')
				   {
					$response	=	'Added Successfully';
					echo("<script>window.location=\"view_diamond.php?response=".urlencode($response)."\"</script>");  
					   
				   }else
				   {
					foreach($_FILES['image']['tmp_name'] as $key => $tmp_name ){
						
					 
					
						// get file extension
						
						$ext = strtolower(pathinfo($_FILES['image']['name'][$key], PATHINFO_EXTENSION));
						if (in_array($ext, $valid_exts)) {
							/* resize image */
							foreach ($sizes as $w => $h)
							{
								$temp_name	=	resize($w,$h,$key);
								$files[]	  =	$temp_name;
								$image_query	=	mysql_query("INSERT INTO diamond_images VALUES('','".$p_id."','".$temp_name."')");
								if(isset($image_query))
								{
									$response	=	'Successfull';
									echo("<script>window.location=\"view_diamond.php?response=".urlencode($response)."\"</script>");
								}
								else
								{
									$response	=	mysql_error();
									echo("<script>window.location=\"diamond_page.php?response=".urlencode($response)."\"</script>");
								}
							}
				
						 } 
					}
				   }
					
				
			}
			
	}
	}
	else
	{
		$response	=	'Specify Product Name';
		echo("<script>window.location=\"diamond_page.php?response=".urlencode($response)."\"</script>");
	}
	}
	else
	{
		
	if(!empty($name))
	{
	$query	=	mysql_query("UPDATE diamond SET shape='".$shape."',name='".$name."',carat='".$carat."',color='".$color."',cut='".$cut."',
	clarity='".$clarity."',polish='".$polish."',symmetry='".$symmetry."',depth='".$depth."',table_data='".$table_data."',fluorescence='".$flourescence."',culet='".$culet."',l_w='".$l_w."',description='".$p_desc."',vendor_id='".$vendor."',retail_price='".$retail_price."',date_created='".$date_time."' WHERE id='".$update_id."'");
	if(isset($query))
	{
		$p_id		=	$update_id;
		$response	=	'Diamond Updated successfully';
	
			if ($_SERVER['REQUEST_METHOD'] == 'POST' AND isset($_FILES['image'])) 
			{
				
				// settings
				$max_file_size = 1024*200; // 200kb
				$valid_exts = array('jpeg', 'jpg', 'png', 'gif');
				// thumbnail sizes
				$sizes = array(60 => 58, 204 => 179, 900 => 900);
				 
				  if($_FILES['image']['tmp_name'][0]=='')
				   {
					$response	=	'Updated Successfully';
					echo("<script>window.location=\"view_diamond.php?response=".urlencode($response)."\"</script>");  
					   
				   }else
				   {
					   
					foreach($_FILES['image']['tmp_name'] as $key => $tmp_name ){
						
						// get file extension
						
						$ext = strtolower(pathinfo($_FILES['image']['name'][$key], PATHINFO_EXTENSION));
						
						if (in_array($ext, $valid_exts)) {
							/* resize image */
							foreach ($sizes as $w => $h)
							{
								$temp_name	=	resize($w,$h,$key);
								$files[]	  =	$temp_name;
								$image_query	=	mysql_query("INSERT INTO diamond_images VALUES('','".$p_id."','".$temp_name."')");
								if(isset($image_query))
								{
									$response	=	'Successfull';
									echo("<script>window.location=\"view_diamond.php?response=".urlencode($response)."\"</script>");
								}
								else
								{
									$response	=	mysql_error();
									echo("<script>window.location=\"diamond_page.php?response=".urlencode($response)."\"</script>");
								}
							}
				
						 } 
					}
				   }
					
				
			}
			
	}
	}
	else
	{
		$response	=	'Specify Product Name';
		echo("<script>window.location=\"diamond_page.php?response=".urlencode($response)."\"</script>");
	}

	}
	
}




?>