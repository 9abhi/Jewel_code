<?php
include "inc/connect.php";
include "inc/function.php";

$g_type		=	isset($_REQUEST['g_type']) 	  ? $_REQUEST['g_type'] 	   : '';
$shape 		 =	isset($_REQUEST['shape'])? $_REQUEST['shape'] : '';
$name	=	isset($_REQUEST['name'])  ? $_REQUEST['name']   : '';
$carat  =	isset($_REQUEST['carat'])? $_REQUEST['carat'] : '';
$retail_price       =    isset($_REQUEST['retail_price'])	 ? $_REQUEST['retail_price'] 	  : '';
$vendor      =	isset($_REQUEST['vendor'])	? $_REQUEST['vendor'] 	 : '';
$g_desc 	    =	trim(isset($_REQUEST['g_desc']) ? $_REQUEST['g_desc'] 	   : '');
$id 	    =	trim(isset($_REQUEST['id']) ? $_REQUEST['id'] 	   : '');
$g_desc = htmlspecialchars($g_desc, ENT_QUOTES);

$date_time = date('Y-m-d H:i:s');
if(isset($_REQUEST['update_gemstone']))
{
	if(!empty($name))
	{
	$query	=	mysql_query("UPDATE gemstone SET type='".$g_type."',name='".$name."',shape='".$shape."',carat='".$carat."',description='".$g_desc."',
	vendor_id='".$vendor."',retail_price='".$retail_price."',date_created='".$date_time."' WHERE id='".$id."'");
	if(isset($query))
	{
		$p_id		=	$id;
		$response	=	'Gemstone Updated successfully';
	
			if ($_SERVER['REQUEST_METHOD'] == 'POST' AND isset($_FILES['image'])) 
			{
				
				// settings
				$max_file_size = 1024*200; // 200kb
				$valid_exts = array('jpeg', 'jpg', 'png', 'gif');
				// thumbnail sizes
				$sizes = array(60 => 58, 204 => 179, 900 => 900);
				 
				  if($_FILES['image']['tmp_name'][0]=='')
				   {
					$response	=	'Updated Successfully';
					echo("<script>window.location=\"view_gemstone.php?response=".urlencode($response)."\"</script>");  
					   
				   }else
				   {
					foreach($_FILES['image']['tmp_name'] as $key => $tmp_name ){
						
					 
					
						// get file extension
						
						$ext = strtolower(pathinfo($_FILES['image']['name'][$key], PATHINFO_EXTENSION));
						if (in_array($ext, $valid_exts)) {
							/* resize image */
							foreach ($sizes as $w => $h)
							{
								$temp_name	=	resize($w,$h,$key);
								$files[]	  =	$temp_name;
								$image_query	=	mysql_query("INSERT INTO gemstone_images VALUES('','".$p_id."','".$temp_name."')");
								if(isset($image_query))
								{
									$response	=	'Successfull';
									echo("<script>window.location=\"view_gemstone.php?response=".urlencode($response)."\"</script>");
								}
								else
								{
									$response	=	mysql_error();
									echo("<script>window.location=\"gemstone_page.php?response=".urlencode($response)."\"</script>");
								}
							}
				
						 } 
					}
				   }
					
				
			}
			
	}
	}
	else
	{
		$response	=	'Specify Product Name';
		echo("<script>window.location=\"gemstone_page.php?response=".urlencode($response)."\"</script>");
	}
}




?>