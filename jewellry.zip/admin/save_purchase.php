 <?php
include "inc/connect.php";


$po_number		=	isset($_REQUEST['po_number']) 	  ? $_REQUEST['po_number'] 	   : '';
$item_id 		  =	isset($_REQUEST['item_id']) 		? $_REQUEST['item_id'] : '';
$item_prefix	  =	isset($_REQUEST['item_prefix'])    ? $_REQUEST['item_prefix']   : '';
$user_id          =	isset($_REQUEST['user_id'])		? $_REQUEST['user_id'] : '';
$retail_price     =    isset($_REQUEST['retail_price'])   ? $_REQUEST['retail_price'] 	  : '';

$date_time = date('Y-m-d H:i:s');

	$save_query=mysql_query("INSERT INTO user_item_purchase_history VALUES('','".$user_id."','".$item_prefix."','".$item_id."','".$po_number."','".$date_time."',
							'".$retail_price."')");
	
	if($save_query)
	{
		$up_query=mysql_query("UPDATE $item_prefix SET sold_status='1' WHERE id='".$item_id."'");
		if($up_query)
		{
		$up_query=mysql_query("UPDATE recent_product SET sold_status='1' WHERE pro_id='".$item_id."' AND type='".$item_prefix."'");
		echo 'Sold Successfully';
		}
		else
		{
			echo mysql_error();
		}
		
	}else
	{
		echo mysql_error();
	}




?>