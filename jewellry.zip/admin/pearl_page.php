<?php
include "inc/header.php";
include "inc/connect.php";

$get_pro_id= isset($_REQUEST['pro']) ? $_REQUEST['pro'] : '';

if(isset($get_pro_id))
{
	$get_data=mysql_query("select * from pearl where id='".$get_pro_id."'");
	$get_cnt=mysql_num_rows($get_data);
	if($get_cnt>0)
	{
		$all_data=mysql_fetch_array($get_data);
	}
	
	$get_pl_images=mysql_query("select * from pearl_images where  p_id='".$get_pro_id."'");
}
?>
<!-----start css---->
<link href="vendors/wysiwyg/bootstrap-wysihtml5.css" rel="stylesheet" media="screen">
<!-----end css---->
<!--------------------------start script------------------------->
<script src="vendors/wysiwyg/wysihtml5-0.3.0.js"></script>
<script src="vendors/wysiwyg/bootstrap-wysihtml5.js"></script>

<!--------------------------end script------------------------->

<div class="container-fluid">
            <div class="row-fluid">
                <?PHP	include 'sidebar.php'	?>
                <!--/span-->
                <div class="span9" id="content">
                      <!-- morris stacked chart -->
                    <div class="row-fluid">
                        <!-- block -->
                        <div class="block">
                            <div class="navbar navbar-inner block-header">
                                <div class="muted pull-left">Add Pearl</div>
                            </div>
                            <div class="block-content collapse in">
	<?php
    $response=$_REQUEST[response];
    if($response)
    {
    echo("<tr><td colspan=5 align=center><font color=green>$response</font><br><br></td></tr>");
    }
    ?>
                                <div class="span12">
                                
                                     <form class="form-horizontal" enctype="multipart/form-data" action="pearl_add.php" method="post" name="add_pearl">
                                      <fieldset>
                                        <legend>Add Pearl</legend> 
                                                                               
                                       <div class="control-group">
                                       
                                          <label class="control-label" for="fileInput">Type</label>
                                          <div class="span3">
                                          
                                          <select name="p_type">
                                          
                                          <option value="akoya" <?php if($all_data['type'] == 'akoya'){ echo 'selected';}?>>Akoya</option>
                                          <option value="freshwater" <?php if($all_data['type'] == 'freshwater'){ echo 'selected';}?>>Freshwater</option>
                                          <option value="south_sea" <?php if($all_data['type'] == 'south_sea'){ echo 'selected';}?>>South Sea</option>
                                          <option value="south_sea_golden" <?php if($all_data['type'] == 'south_sea_golden'){ echo 'selected';}?>>South Sea Golden</option>
                                          <option value="tahitian" <?php if($all_data['type'] == 'tahitian'){ echo 'selected';}?>>Tahitian</option>
                                          
                                          
                                          </select>
                                            
                                         
                                          
                                          </div>
                                          
                                        
                                          <label class="control-label" for="fileInput">Name</label>
                                          <div class="span3">
                                          <input class="input-file uniform_on" value="<?=$all_data['name'];?>" id="name" name="name" type="text">
                                            
                                          </div>
                                          </div>
                                          
                                      
                                        
                                        
                                      <input type="hidden" name="update_id" value="<?=$get_pro_id?>" />
                                        
                                        <div class="control-group">
                                          <label class="control-label" for="fileInput">Diameter</label>
                                          <div class="span3">
                                          
                                           <input class="input-file uniform_on" value="<?=$all_data['diameter']?>" id="diameter" name="diameter" type="text">
                                            
                                          </div>
                                          
                                          <label class="control-label" for="fileInput">Luster</label>
                                          <div class="span3">
                                         <select name="luster">
                                          
                                          <option value="low" <?php if($all_data['luster'] == 'low'){ echo 'selected';}?> >Low</option>
                                          <option value="medium" <?php if($all_data['luster'] == 'medium'){ echo 'selected';}?>>Medium</option>
                                          <option value="high" <?php if($all_data['luster'] == 'high'){ echo 'selected';}?>>High</option>
                                          
                                          
                                          </select>
                                            
                                          </div>
                                        </div>
                                        
                                        <div class="control-group">
                                          <label class="control-label" for="fileInput">Retail Price</label>
                                          <div class="span3">
                                          <input class="input-file uniform_on" value="<?=$all_data['retail_price']?>" id="retail_price" name="retail_price" type="number">
                                            
                                          </div>
                                          
                                          <label class="control-label" for="fileInput">Vendor</label>
                                          <div class="span3">
                                           <select name="vendor">
                                          <?php
                                          $query_ven = mysql_query("SELECT id as Value, contact_fname as DisplayText FROM vendor ORDER BY contact_fname ASC");
											
											$counter		=	mysql_num_rows($query_ven);
											if($counter>0)
											{
												while($ven=mysql_fetch_array($query_ven))
												{
													if($ven['Value']==$all_data['vendor_id'])
													{
												 ?>
												<option value="<?=$ven['Value']?>" selected><?=$ven['DisplayText']?></option>
											<?php 
													}
													else
													{ ?>
													<option value="<?=$ven['Value']?>" ><?=$ven['DisplayText']?></option>	
													<?php }
												}}
												?>
	
                                          
                                          
                                          </select>
                                            
                                          </div>
                                          
                                          
                                        </div>
                                        
                                        <div class="control-group">
                                          <label class="control-label" for="textarea">Description</label>
                                          <div class="controls">
                                            <textarea class="input-xlarge textarea" placeholder="Enter text..." name="p_desc" style="width: 600px; height: 200px">
											
											<?php echo  htmlspecialchars_decode($all_data['description'], ENT_QUOTES); ?>
											
											
                                            </textarea>
                                          </div>
                                          
                                        </div>
                                        
                                        
                                      <div class="control-group">
                                          <label class="control-label" for="fileInput">Images</label>
                                          <div class="controls">
                                          <input class="input-file uniform_on" type="file" name="image[]" accept="image/*" multiple />
                                            
                                          </div>
                                        </div>
                                       
                                        <div class="control-group">
                                        <div class="controls">
                                        
											<?php
											$get_img_count=mysql_num_rows($get_pl_images);
											if($get_img_count>0)
											{

												while($get_img=mysql_fetch_array($get_pl_images))
												{
													
													?>
                                                    <div class="span3" style="width:211px; height:203px; border:1px solid #E8E8E8; padding:5px; ">
													<img src="../uploads/<?=$get_img['image']?>" /></br>
                                                    
                                                    <div style="margin:2px; font-size:12px; float:left;">
                                                    <a id="img_del" onclick="del_img(<?=$get_img['id']?>,'<?=$get_img['image']?>')">Delete</a>
                                                    </div>
                                                    </div>
                                                    
												<?php
												 }
												
											}
											?>
                                        </div>
                                        </div>
                                       
                                        <div class="form-actions">
                                          <button type="reset" class="btn" id="cancel_click">Cancel</button>
                                          <button type="submit" class="btn btn-primary" name="add_pearl" id="add_pearl">Add Pearl</button>
                                          
                                        </div>
                                      </fieldset>
                                    </form>

                                </div>
                            </div>
                        </div>
                        <!-- /block -->
                    </div>

                     

                     <!-- wizard -->
                    

                </div>
            </div>
            <hr>
            

<?php
include "inc/footer.php";
?>                
<script>
$(document).ready(function() {
	
    $('.textarea').wysihtml5();
	$('#cancel_click').click(function() {
			window.location='view_pearl.php';
		});
	
	});
function del_img(id,img)
{
	
	$.ajax({
            type:"POST",
            url: "del_img/del_pearl_img.php",
			data: {'id':id,'img':img},
            success: function(data)
			{ 
				alert(data);
				location.reload();
			}
	});
}		
</script>