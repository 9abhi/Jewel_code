<?php
include "inc/header.php";
include "inc/connect.php";

$get_pro_id= isset($_REQUEST['pro']) ? $_REQUEST['pro'] : '';

if(!empty($get_pro_id))
{
	$get_data=mysql_query("select * from setting where id='".$get_pro_id."'");
	$get_cnt=mysql_num_rows($get_data);
	if($get_cnt>0)
	{
		$all_data=mysql_fetch_array($get_data);
	}
	$get_pl_images=mysql_query("select * from setting_images where  p_id='".$get_pro_id."'");
	$title_content='Edit';
}
else
{
	$title_content='Add';
}
?>
<!-----start css---->
<link href="vendors/wysiwyg/bootstrap-wysihtml5.css" rel="stylesheet" media="screen">
<!-----end css---->
<!--------------------------start script------------------------->
<script src="vendors/wysiwyg/wysihtml5-0.3.0.js"></script>
<script src="vendors/wysiwyg/bootstrap-wysihtml5.js"></script>

<!--------------------------end script------------------------->

<div class="container-fluid">
            <div class="row-fluid">
                <?PHP	include 'sidebar.php'	?>
                <!--/span-->
                <div class="span9" id="content">
                      <!-- morris stacked chart -->
                    <div class="row-fluid">
                        <!-- block -->
                        <div class="block">
                            <div class="navbar navbar-inner block-header">
                                <div class="muted pull-left"><?=$title_content?> Setting</div>
                            </div>
                            <div class="block-content collapse in">
	<?php
    $response=$_REQUEST[response];
    if($response)
    {
    echo("<tr><td colspan=5 align=center><font color=green>$response</font><br><br></td></tr>");
    }
    ?>
                                <div class="span12">
                                
                                     <form class="form-horizontal" enctype="multipart/form-data" action="setting_add.php" method="post" name="add_setting">
                                      <fieldset>
                                        <legend><?=$title_content?> Setting</legend> 
                                                                               
                                       <div class="control-group">
                                       
                                          <label class="control-label" for="fileInput">Style</label>
                                          <div class="span3">
                                          
                                          <select name="style">
                                          
                                          <option value="classic" <?php if($all_data['style'] == 'classic'){ echo 'selected';}?>>Classic</option>
                                          <option value="vingate" <?php if($all_data['style'] == 'vingate'){ echo 'selected';}?>>Vingate</option>
                                          <option value="gemstone" <?php if($all_data['style'] == 'gemstone'){ echo 'selected';}?>>Gemstone</option>
                                          <option value="sidestone" <?php if($all_data['style'] == 'sidestone'){ echo 'selected';}?>>Sidestone</option>
                                          <option value="halo" <?php if($all_data['style'] == 'halo'){ echo 'selected';}?>>Halo</option>
                                          <option value="stone" <?php if($all_data['style'] == 'stone'){ echo 'selected';}?>>Stone</option>
                                          <option value="monique" <?php if($all_data['style'] == 'monique'){ echo 'selected';}?>>Monique</option>
                                          <option value="ihullier" <?php if($all_data['style'] == 'ihullier'){ echo 'selected';}?>>ihullier</option>
                                          
                                          </select>
                                         
                                          </div>
                                          
                                        
                                          <label class="control-label" for="fileInput">Name</label>
                                          <div class="span3">
                                          <input class="input-file uniform_on" value="<?=$all_data['name'];?>" id="name" name="name" type="text">
                                            
                                          </div>
                                          </div>
                                          
                                      
                                        
                                        
                                      <input type="hidden" name="update_id" value="<?=$get_pro_id?>" />
                                        
                                        <div class="control-group">
                                          <label class="control-label" for="fileInput">Size</label>
                                          <div class="span3">
                                          
                                           <input class="input-file uniform_on" value="<?=$all_data['size']?>" id="size" name="size" type="text">
                                            
                                          </div>
                                          
                                          <label class="control-label" for="fileInput">Shape</label>
                                          <div class="span3">
                                         <select name="shape">
                                          
                                          <option value="round" <?php if($all_data['shape'] == 'round'){ echo 'selected';}?> >Round</option>
                                          <option value="princess" <?php if($all_data['shape'] == 'princess'){ echo 'selected';}?>>Princess</option>
                                          <option value="emerald" <?php if($all_data['shape'] == 'emerald'){ echo 'selected';}?>>emerald</option>
                                          <option value="asscher" <?php if($all_data['shape'] == 'asscher'){ echo 'selected';}?>>asscher</option>
                                          <option value="oval" <?php if($all_data['shape'] == 'oval'){ echo 'selected';}?>>oval</option>
                                          <option value="marquise" <?php if($all_data['shape'] == 'marquise'){ echo 'selected';}?>>marquise</option>
                                          <option value="cushion" <?php if($all_data['shape'] == 'cushion'){ echo 'selected';}?>>cushion</option>
                                          <option value="radiant" <?php if($all_data['shape'] == 'radiant'){ echo 'selected';}?>>radiant</option>
                                          <option value="pear" <?php if($all_data['shape'] == 'pear'){ echo 'selected';}?>>pear</option>
                                          
                                          
                                          
                                          </select>
                                            
                                          </div>
                                        </div>
                                        
                                        <div class="control-group">
                                          <label class="control-label" for="fileInput">Retail Price</label>
                                          <div class="span3">
                                          <input class="input-file uniform_on" value="<?=$all_data['retail_price']?>" id="retail_price" name="retail_price" type="number">
                                            
                                          </div>
                                          
                                          <label class="control-label" for="fileInput">Vendor</label>
                                          <div class="span3">
                                           <select name="vendor">
                                          <?php
                                          $query_ven = mysql_query("SELECT id as Value, contact_fname as DisplayText FROM vendor ORDER BY contact_fname ASC");
											
											$counter		=	mysql_num_rows($query_ven);
											if($counter>0)
											{
												while($ven=mysql_fetch_array($query_ven))
												{
													if($ven['Value']==$all_data['vendor_id'])
													{
												 ?>
												<option value="<?=$ven['Value']?>" selected><?=$ven['DisplayText']?></option>
											<?php 
													}
													else
													{ ?>
													<option value="<?=$ven['Value']?>" ><?=$ven['DisplayText']?></option>	
													<?php }
												}}
												?>
	
                                          
                                          
                                          </select>
                                            
                                          </div>
                                          
                                          
                                        </div>
                                        <div class="control-group">
                                         <label class="control-label" for="fileInput">Metal</label>
                                            <div class="span3">
                                            
                                            <select name="metal">
                                         
									  <option value="platinum" <?php if($all_data['metal'] == 'platinum'){ echo 'selected';}?> >platinum</option>
                                      <option value="14k_white_gold" <?php if($all_data['metal'] == '14k_white_gold'){ echo 'selected';}?>>14k white gold</option>
                                      <option value="14k_yellow_gold" <?php if($all_data['metal'] == '14k_yellow_gold'){ echo 'selected';}?>>14k yellow gold</option>
                                      <option value="14k_rose_gold" <?php if($all_data['metal'] == '14k_rose_gold'){ echo 'selected';}?>>14k rose gold</option>
                                      <option value="18k_white_gold" <?php if($all_data['metal'] == '18k_white_gold'){ echo 'selected';}?>>18k white gold</option>
                                      <option value="18k_yellow_gold" <?php if($all_data['metal'] == '18k_yellow_gold'){ echo 'selected';}?>>18k yellow gold</option>
                                      <option value="18k_rose_gold" <?php if($all_data['metal'] == '18k_rose_gold'){ echo 'selected';}?>>18k rose gold</option>
                                          
                                          
                                          </select>
                                          
                                            </div>
                                        </div>
                                        
                                        <div class="control-group">
                                          <label class="control-label" for="textarea">Description</label>
                                          <div class="controls">
                                            <textarea class="input-xlarge textarea" placeholder="Enter text..." name="p_desc" style="width: 600px; height: 200px">
											<?php echo  htmlspecialchars_decode($all_data['description'], ENT_QUOTES); ?>
											
											
                                            </textarea>
                                          </div>
                                          
                                        </div>
                                        
                                        
                                      <div class="control-group">
                                          <label class="control-label" for="fileInput">Images</label>
                                          <div class="controls">
                                          <input class="input-file uniform_on" type="file" name="image[]" accept="image/*" multiple />
                                            
                                          </div>
                                        </div>
                                       
                                        <div class="control-group">
                                        <div class="controls">
											<?php
											@$get_img_count=mysql_num_rows($get_pl_images);
											if($get_img_count>0)
											{

												while($get_img=mysql_fetch_array($get_pl_images))
												{
													
													?>
                                                    <div class="span3" style="height:203px; width:211px; border:1px solid #f1f1f1; padding:5px;">
													<img src="../uploads/<?=$get_img['image']?>" /></br>
                                                    
                                                    <div style="margin:2px; font-size:12px; float:left;">
                                                    <a id="img_del" onclick="del_img(<?=$get_img['id']?>,'<?=$get_img['image']?>')">Delete</a>
                                                    </div>
                                                    
                                                    </div>
												<?php
												 }
												
											}
											?>
                                        </div>
                                        </div>
                                       
                                        <div class="form-actions">
                                          <button type="reset" class="btn" id="cancel_click">Cancel</button>
                                          <button type="submit" class="btn btn-primary" name="add_setting" id="add_setting"><?=$title_content?> Settings</button>
                                          
                                        </div>
                                      </fieldset>
                                    </form>

                                </div>
                            </div>
                        </div>
                        <!-- /block -->
                    </div>

                     

                     <!-- wizard -->
                    

                </div>
            </div>
            <hr>
            

<?php
include "inc/footer.php";
?>                
<script>
$(document).ready(function() {
	
    $('.textarea').wysihtml5();
			$('#cancel_click').click(function() {
			window.location='view_setting.php';
		});

	
	});
function del_img(id,img)
{
	
	$.ajax({
            type:"POST",
            url: "del_img/del_setting_img.php",
			data: {'id':id,'img':img},
            success: function(data)
			{ 
				alert(data);
				location.reload();
			}
	});
}		
</script>