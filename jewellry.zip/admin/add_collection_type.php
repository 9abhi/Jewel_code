<?php
include "inc/header.php";
include "inc/connect.php";

?>

<div class="container-fluid">
            <div class="row-fluid">
                <?PHP	include 'sidebar.php'	?>
                <!--/span-->
                <div class="span9" id="content">
                      <!-- morris stacked chart -->
                    <div class="row-fluid">
                        <!-- block -->
                        <div class="block">
                            <div class="navbar navbar-inner block-header">
                                <div class="muted pull-left">Add Collection Type</div>
                            </div>
                            <div class="block-content collapse in">
		<?php
			$response=$_REQUEST[response];
			if($response)
			{
			echo("<tr><td colspan=5 align=center><font color=green>$response</font><br><br></td></tr>");
			}
        ?>
                                <div class="span12">
                                
                                     <form class="form-horizontal" enctype="multipart/form-data" action="collection_type.php" method="post" name="add_product">
                                      <fieldset>
                                        <legend>Add Collection Type</legend> 
                                                                               
                                        
                                        
                                        <div class="control-group">
                                          <label class="control-label" for="fileInput">Collection Type</label>
                                          <div class="controls">
                                          <input class="input-file uniform_on"  name="collection_type" type="text">
                                            
                                          </div>
                                        </div>
                                        
                                        <div class="control-group">
                                          <label class="control-label" for="fileInput">Image</label>
                                          <div class="controls">
                                          <input class="input-file uniform_on" type="file" name="image" accept="image/*" />
                                            
                                          </div>
                                        </div>
                                       
                                        <div class="form-actions">
                                          <button type="reset" class="btn">Cancel</button>
                                          <button type="submit" class="btn btn-primary" name="add_collection_type">Add Collection Type</button>
                                          
                                        </div>
                                      </fieldset>
                                    </form>

                                </div>
                            </div>
                            <div class="block-content collapse in">
                                <div class="span12">
  									<table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered" id="example">
										<thead>
											<tr>
												<th>Sr. No</th>
												<th>Collection</th>
												<th>Image</th>
												<th></th>
                                                <th></th>
												
											</tr>
										</thead>
										<tbody>
                                        <?php
										$type_query=mysql_query("select * from collection_type");
										$type_cnt=mysql_num_rows($type_query);
										if($type_cnt>0)
										{
											$i=1;
											while($itm=mysql_fetch_array($type_query))
											{
											
										?>
													
                                            <tr class="gradeC">
												<td><?=$i;?></td>
												<td><?=$itm['name']?></td>
												<td><img src="../uploads_collection/<?=$itm['image']?>" /></td>
												<td style="text-align:center;"><a class="btn" href="edit_collection_type.php?e_id=<?=$itm['id']?>"><i class="icon-pencil"></i>Edit</a></td>
												<td style="text-align:center;"><a class="btn btn-danger"  onclick="return areyousure(<?=$itm['id']?>);"><i class="icon-trash icon-white"></i>Delete</a></td>
											</tr>
							
											<?php
											$i++;
											}
										}
										
											?>	
											
											
											
											
										</tbody>
									</table>
                                </div>
                            </div>
                        </div>
                        <!-- /block -->
                    </div>

                     

                     <!-- wizard -->
                    

                </div>
            </div>
            <hr>
            

<?php
include "inc/footer.php";
?> 
<script>
function areyousure(id)
{
		
	var answer=confirm("Are you sure you want to continue");
	if (answer==true)
	  {
		
	$.ajax({
            type:"POST",
            url: "del_collection_type.php",
			data: {'id':id},
            success: function(data)
			{ 
			alert(data);
			location.reload();
			}
	});
	  }
	else
	{
		return false;
	}
}
</script>                   