<?php

	include("inc/connect.php");
	
	//Open database connection
	/*$con = mysql_connect("localhost","root","mysql");
	mysql_select_db("curtis", $con);*/
	
	
	//Get records from database
	$query			=	"SELECT id as Value, contact_fname as DisplayText FROM vendor ORDER BY contact_fname ASC ";
	$result 		=	mysql_query($query);
	$counter		=	mysql_num_rows($result);
	
	$rows = array();
	
	while($row = mysql_fetch_assoc($result))
	{
			$inner					=	array();
			$inner['DisplayText']	=	$row['DisplayText'];
			$inner['Value']			=	$row['Value'];
			$rows[]					=	$inner;
			
	}

	//Return result to jTable
	$jTableResult = array();
	$jTableResult['Result'] = "OK";
	$jTableResult['Options'] = $rows;
	print json_encode($jTableResult);
	
?>