<?php
include "inc/header.php";
include "inc/connect.php";
include "inc/function.php";

?>
<link href="bootstrap/css/DT_bootstrap.css" rel="stylesheet" media="screen">
<script src="bootstrap/js/jquery.dataTables.min.js"></script>
<script src="bootstrap/js/DT_bootstrap.js"></script>
<div class="container-fluid">
  <div class="row-fluid">
    <?PHP	include 'sidebar.php'	?>
    <!--/span-->
    <div class="span9" id="content"> 
      <!-- morris stacked chart -->
      <div class="row-fluid"> 
        <!-- block -->
        <?php
                                $response=$_REQUEST[response];
                                if($response)
                                {
                                ?>
        <div class="alert alert-success">
          
          <button class="close" data-dismiss="alert">&times;</button>
          <strong>
          <?=$response;?>
          </strong>
          
        </div>
        <?php
		}
		?>
        <div class="block-content collapse in">
          <div class="span12">
            <div class="block">
              <div class="navbar navbar-inner block-header">
                <div class="muted pull-left">Setting</div>
              </div>
              <div class="block-content collapse in">
                <div class="span12"> <span class="btn-group pull-right"> <a class="btn" style="font-weight:normal;" href="setting_page.php"><i class="icon-plus-sign"></i>Add Setting</a> <br />
                  </span>
                  <table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered" id="example">
                    <thead>
                      <tr>
                        <th>Sr. no</th>
                        <th>Style</th>
                        <th>Name</th>
                        <th>Size</th>
                        <th>Vendor</th>
                        <th>Retail Price</th>
                        <th></th>
                        <th></th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php
                                        $i=1;
										$pro_query=mysql_query("select pl.*,ven.name as ven from setting pl JOIN vendor ven ON pl.vendor_id=ven.id WHERE sold_status='0'");
										$count_pro=mysql_num_rows($pro_query);
										if($count_pro>0)
										{
											while($p=mysql_fetch_array($pro_query))
											{ ?>
                      <tr class="gradeC">
                        <td style="text-align:center;"><?=$i?></td>
                        <td><?=$p['style']?></td>
                        <td><?=$p['name']?></td>
                        <td><?=$p['size']?></td>
                        <td><?=$p['ven']?></td>
                        <td><?=$p['retail_price']?></td>
                        <td style="text-align:center;"><a class="btn" href="setting_page.php?pro=<?=$p['id']?>"><i class="icon-pencil"></i>Edit</a></td>
                        <td style="text-align:center;"><a class="btn btn-danger"  onclick="return areyousure(<?=$p['id']?>);"><i class="icon-trash icon-white"></i>Delete</a></td>
                      </tr>
                      <?php 
													$i++;
												}
												
											
											
										}
										?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <!-- /block --> 
      </div>
      
      <!-- wizard --> 
      
    </div>
  </div>
  <hr>
  <?php
include "inc/footer.php";
?>
<script>
function areyousure(id)
{
	
	var answer=confirm("Are you sure you want to continue");
	if (answer==true)
	  {
		
	$.ajax({
            type:"POST",
            url: "del_img/del_setting_pro.php",
			data: {'id':id},
            success: function(data)
			{ 
			alert(data);
			location.reload();
			}
	});
	  }
	else
	{
		return false;
	}
}
</script>