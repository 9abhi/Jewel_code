<?php
include "inc/header.php";
include "inc/connect.php";
include "inc/function.php";
?>
<link href="bootstrap/css/DT_bootstrap.css" rel="stylesheet" media="screen">
<script src="bootstrap/js/jquery.dataTables.min.js"></script>
<script src="bootstrap/js/DT_bootstrap.js"></script>
<div class="container-fluid">
            <div class="row-fluid">
                <?PHP	include 'sidebar.php'	?>
                <!--/span-->
                <div class="span9" id="content">
                      <!-- morris stacked chart -->
                    <div class="row-fluid">
                        <!-- block -->
                        
                            <div class="block-content collapse in">
<?php
$response=$_REQUEST[response];
if($response)
{
echo("<tr><td colspan=5 align=center><font color=green>$response</font><br><br></td></tr>");
}
?>
                                <div class="span12">
                                
                                     <div class="block">
                            <div class="navbar navbar-inner block-header">
                                <div class="muted pull-left">Hold Items</div>
                            </div>
                            <div class="block-content collapse in">
                                <div class="span12">
  									<table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered" id="example">
										<thead>
											<tr>
												<th>User</th>
												<th>Category(Type)</th>
												<th>Item Name</th>
												<th>Hold Time</th>
												
											</tr>
										</thead>
										<tbody>
                                        <?php
										$get_hold_data=mysql_query("select * from hold_item where status='1' ORDER BY date_time DESC");
										$get_cnt=mysql_num_rows($get_hold_data);
										if($get_cnt>0)
										{
											while($get_p=mysql_fetch_array($get_hold_data))
											{
												$chk_tm_h=$get_p['date_time'];
												$chk_dt_h= strtotime("+2 day",$chk_tm_h).'</br>';
												
												$check_today	=	time();
												if($check_today<$chk_dt_h)
												{
													$hold_time=date('d-m-Y h:i A',$chk_tm_h);
													$tab_nm=get_recent_table($get_p['item_type']);
													$get_nm=mysql_query("select * from $tab_nm where id='".$get_p['item_id']."' ORDER BY date_created DESC");
													$chk_cnt=mysql_num_rows($get_nm);
													$get_name=mysql_fetch_array($get_nm);
													 ?>
													
                                            <tr class="gradeC">
												<td><?=$get_p['user']?></td>
												<td><?=$get_p['item_type']?></td>
												<td><?=$get_name['name']?></td>
												<td class="center"><?=$hold_time?></td>
												
											</tr>
							
												<?php 
												}else
												{ ?>
												
												<?php 
												}
												
											}
											
										}
										?>
											
											
											
											
										</tbody>
									</table>
                                </div>
                            </div>
                        </div>

                                </div>
                            </div>
                        
                        <!-- /block -->
                    </div>

                     

                     <!-- wizard -->
                    

                </div>
            </div>
            <hr>
            

<?php
include "inc/footer.php";
?>                