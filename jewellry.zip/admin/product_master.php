<?php
include "inc/header.php";
?>
<div class="container-fluid">
            <div class="row-fluid">
                <div class="span3" id="sidebar">
                    <ul class="nav nav-list bs-docs-sidenav nav-collapse collapse">
                        <li>
                            <a href="index.php"><i class="icon-chevron-right"></i> Dashboard</a>
                        </li>
                        
                        
                    </ul>
                </div>
                <!--/span-->
                <div class="span9" id="content">
                      <!-- morris stacked chart -->
                    <div class="row-fluid">
                        <!-- block -->
                        <div class="block">
                            <div class="navbar navbar-inner block-header">
                                <div class="muted pull-left">Product Master</div>
                            </div>
                            <div class="block-content collapse in">
                                <div class="span12">
                                     <form class="form-horizontal">
                                      <fieldset>
                                        <legend>Add Product</legend>
                                        <div class="control-group">
                                          <label class="control-label" for="focusedInput">Sku</label>
                                          <div class="controls">
                                          
                                            <input class="input-xlarge focused" id="focusedInput" type="text" value="" placeholder="Sku">
                                            
                                          </div>
                                        </div>
                                        
                                       <div class="control-group success">
                                          <label class="control-label" for="selectError">Type</label>
                                          <div class="controls">
                                            <select id="selectError">
                                              <option>Ring</option>
                                              <option>Earring</option>
                                              <option>Bracelet</option>
                                              <option>Necklace</option>
                                            </select>
                                            
                                          </div>
                                        </div>
                                        <div class="control-group">
                                          <label class="control-label" for="focusedInput">Collection</label>
                                          <div class="controls">
                                            <input class="input-xlarge focused" id="focusedInput" type="text" value="" placeholder="Collection">
                                          </div>
                                        </div>
                                        
                                       
                                        <div class="control-group">
                                          <label class="control-label" for="textarea2">Retail Price</label>
                                          <div class="controls">
                                             <input class="input-xlarge focused" id="focusedInput" type="text" value="" placeholder="Retail Price">
                                          </div>
                                        </div>
                                        
                                        
                                        
                                        
                                        <div class="form-actions">
                                          <button type="reset" class="btn">Cancel</button>
                                          <button type="submit" class="btn btn-primary">Add Product</button>
                                          
                                        </div>
                                      </fieldset>
                                    </form>

                                </div>
                            </div>
                        </div>
                        <!-- /block -->
                    </div>

                     

                     <!-- wizard -->
                    

                </div>
            </div>
            <hr>
            

<?php
include "inc/footer.php";
?>                