<?php
include "inc/header.php";
include "inc/connect.php";
?>
<link href="bootstrap/css/DT_bootstrap.css" rel="stylesheet" media="screen">
<script src="bootstrap/js/jquery.dataTables.min.js"></script>
<script src="bootstrap/js/DT_bootstrap.js"></script>
               
        <div class="container-fluid">
            <div class="row-fluid">
                <?PHP	include 'sidebar.php'	?>
                
                <!--/span-->
                <div class="span9" id="content">
                    <div class="row-fluid">
                        <!--<div class="alert alert-success">
							<button type="button" class="close" data-dismiss="alert">&times;</button>
                            <h4>Success</h4>
                        	The operation completed successfully </div>-->
                        	
                    	</div>
                    <div class="row-fluid">
                        <!-- block -->
                        <div class="block">
                            <div class="navbar navbar-inner block-header">
                                <div class="muted pull-left">Recent Item Views</div>
                            </div>
                            <div class="block-content collapse in">
                                <div class="span12">
  									<table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered" id="example">
										<thead>
											<tr>
												<th>User</th>
												<th>Category(Type)</th>
												<th>Item Name</th>
												<th>Channel</th>
                                                <th>Time</th>
												
											</tr>
										</thead>
										<tbody>
                                       <?php
									   $get_recent=mysql_query("select * from recent_product where sold_status='0' AND status='1' ORDER BY start_time DESC");
									   $get_cnt=mysql_num_rows($get_recent);
									   if($get_cnt>0)
									   {
										   while($row=mysql_fetch_array($get_recent))
										   {
											       $tab=$row['type'];
												   $get_pro=mysql_query("select * from $tab WHERE id='".$row['pro_id']."' AND sold_status='0'");
												   $get_pr=mysql_fetch_array($get_pro);
											   
											   ?>

											<tr class="gradeC">
												<td><?=$row['user_id']?></td>
												<td><?=$row['type']?></td>
												<td><?=$get_pr['name']?></td>
												<td><?=$row['channel']?></td>
                                                <td><?php
												echo date('d-m-Y h:i A',$row['start_time']);
												 ?></td>
												
											</tr>											   
										   <?php }
									   }
									   ?>
													
                                            
							
												
											
											
											
											
										</tbody>
									</table>
                                </div>
                            </div>
                        </div>
                        <!-- /block -->
                    </div>
                    
                    
                    
                </div>
            </div>
            <hr>
            
<?php
include "inc/footer.php"; 
?>