<footer>
	<p>&copy; Bay Jewellers</p>
</footer>

</div>
        <!--/.fluid-container-->
        <script src="bootstrap/js/bootstrap.min.js"></script>
        <script src="assets/easypiechart/jquery.easy-pie-chart.js"></script>
        <script src="assets/scripts.js"></script>
        <script>$(function() {	$('.chart').easyPieChart({animate: 1000}); });</script>
        
        
    </body>

</html>