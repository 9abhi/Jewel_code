<?php
/**
 * Image resize while uploading
 * @author Resalat Haque
 * @link http://www.w3bees.com/2013/03/resize-image-while-upload-using-php.html
 */
 
/**
 * Image resize
 * @param int $width
 * @param int $height
 */
function resize($width, $height,$key){
	/* Get original image x y*/
	list($w, $h) = getimagesize($_FILES['image']['tmp_name'][$key]);
	/* calculate new image size with ratio */
	$ratio = max($width/$w, $height/$h);
	$h = ceil($height / $ratio);
	$x = ($w - $width / $ratio) / 2;
	$w = ceil($width / $ratio);
	/* new file name */
	$folder_path	= '../uploads/';
	$img_path	  =	$width.'x'.$height.'_'.md5($_FILES['image']['name'][$key]).'_'.$_FILES['image']['name'][$key];
	$path = $folder_path.$img_path;
	$save_path	=	$img_path;
	
	
	/* read binary data from image file */
	$imgString = file_get_contents($_FILES['image']['tmp_name'][$key]);
	/* create image from string */
	$image = imagecreatefromstring($imgString);
	$tmp = imagecreatetruecolor($width, $height);
	imagecopyresampled($tmp, $image,0, 0,$x, 0,$width, $height,$w, $h);
	/* Save image */
	switch ($_FILES['image']['type'][$key]) {
		case 'image/jpeg':
			imagejpeg($tmp, $path, 100);
			break;
		case 'image/png':
			imagepng($tmp, $path, 0);
			break;
		case 'image/gif':
			imagegif($tmp, $path);
			break;
		default:
			exit;
			break;
	}
	return $save_path;
	/* cleanup memory */
	imagedestroy($image);
	imagedestroy($tmp);
}

function cat_resize($width, $height){
	/* Get original image x y*/
	list($w, $h) = getimagesize($_FILES['image']['tmp_name']);
	/* calculate new image size with ratio */
	$ratio = max($width/$w, $height/$h);
	$h = ceil($height / $ratio);
	$x = ($w - $width / $ratio) / 2;
	$w = ceil($width / $ratio);
	/* new file name */
	$folder_path	= '../uploads_type/';
	$img_path	  =	$width.'x'.$height.'_'.md5(mt_rand(1,20)).'_'.$_FILES['image']['name'];
	$path = $folder_path.$img_path;
	$save_path	=	$img_path;	
	/* read binary data from image file */
	$imgString = file_get_contents($_FILES['image']['tmp_name']);
	/* create image from string */
	$image = imagecreatefromstring($imgString);
	
	$tmp = imagecreatetruecolor($width, $height);
	imagecopyresampled($dst_img,$src_img,0,0,0,0,$thumb_w,$thumb_h,$old_x,$old_y);
	imagecopyresampled($tmp, $image,
  	0, 0,
  	$x, 0,
  	$width, $height,
  	$w, $h);
	/* Save image */
	switch ($_FILES['image']['type']) {
		case 'image/jpeg':
			imagejpeg($tmp, $path, 100);
			break;
		case 'image/png':
			imagepng($tmp, $path, 0);
			break;
		case 'image/gif':
			imagegif($tmp, $path);
			break;
		default:
			exit;
			break;
	}
	return $save_path;
	/* cleanup memory */
	imagedestroy($image);
	imagedestroy($tmp);
}

function collec_resize($width, $height){
	/* Get original image x y*/
	list($w, $h) = getimagesize($_FILES['image']['tmp_name']);
	/* calculate new image size with ratio */
	$ratio = max($width/$w, $height/$h);
	$h = ceil($height / $ratio);
	$x = ($w - $width / $ratio) / 2;
	$w = ceil($width / $ratio);
	/* new file name */
	$folder_path	= '../uploads_collection/';
	$img_path	  =	$width.'x'.$height.'_'.md5(mt_rand(1,20)).'_'.$_FILES['image']['name'];
	$path = $folder_path.$img_path;
	$save_path	=	$img_path;	
	/* read binary data from image file */
	$imgString = file_get_contents($_FILES['image']['tmp_name']);
	/* create image from string */
	$image = imagecreatefromstring($imgString);
	
	$tmp = imagecreatetruecolor($width, $height);
	imagecopyresampled($dst_img,$src_img,0,0,0,0,$thumb_w,$thumb_h,$old_x,$old_y);
	imagecopyresampled($tmp, $image,
  	0, 0,
  	$x, 0,
  	$width, $height,
  	$w, $h);
	/* Save image */
	switch ($_FILES['image']['type']) {
		case 'image/jpeg':
			imagejpeg($tmp, $path, 100);
			break;
		case 'image/png':
			imagepng($tmp, $path, 0);
			break;
		case 'image/gif':
			imagegif($tmp, $path);
			break;
		default:
			exit;
			break;
	}
	return $save_path;
	/* cleanup memory */
	imagedestroy($image);
	imagedestroy($tmp);
}

function format_currency($val)
{
	$value	=	'$'.' '.$val;
	return $value;
	
}
function get_recent_table($name)
{

	if($name=='product')
				{
					return 'product';
				}
				else if($name=='diamond')
				{
					return 'diamond';
				}
				else if($name=='pearl')
				{
					return 'pearl';
				}
				else if($name=='setting')
				{
					return 'setting';
				}
				else if($name=='gemstone')
				{
					return 'gemstone';
				}
}
function get_tbl($a)
{
	if($a=='P')
				{
					return 'product';
				}
				else if($a=='D')
				{
					return 'diamond';
				}
				else if($a=='Pl')
				{
					return 'pearl';
				}
				else if($a=='S')
				{
					return 'setting';
				}
				else if($a=='G')
				{
					return 'gemstone';
				}
	
}
function get_recent_img($name)
{
	if($name=='product')
				{
					return 'product_images';
				}
				else if($name=='diamond')
				{
					return 'diamond_images';
				}
				else if($name=='pearl')
				{
					return 'pearl_images';
				}
				else if($name=='setting')
				{
					return 'setting_images';
				}
				else if($name=='gemstone')
				{
					return 'gemstone_images';
				}


}
function get_recent_prefix($name)
{
	if($name=='product')
				{
					return 'P';
				}
				else if($name=='diamond')
				{
					return 'D';
				}
				else if($name=='pearl')
				{
					return 'Pl';
				}
				else if($name=='setting')
				{
					return 'S';
				}
				else if($name=='gemstone')
				{
					return 'G';
				}

}

?>