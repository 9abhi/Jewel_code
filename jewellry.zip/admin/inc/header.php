<?php
//error_reporting(0);
?>
<!DOCTYPE html>
<html class="no-js">
    
    <head>
        <title>Jewellry</title>
        <!-- Bootstrap -->
        
        <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
        <link href="bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet" media="screen">
        <link href="assets/easypiechart/jquery.easy-pie-chart.css" rel="stylesheet" media="screen">
        <link href="assets/styles.css" rel="stylesheet" media="screen">
        <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
        <!--[if lt IE 9]>
            <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
        <![endif]-->
        <script src="assets/modernizr-2.6.2-respond-1.1.0.min.js"></script>
        <script src="assets/jquery-1.9.1.min.js"></script>
    </head>
    
    <body>
<div class="navbar navbar-fixed-top">
            <div class="navbar-inner">
                <div class="container-fluid">
                    <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse"> <span class="icon-bar"></span>
                     <span class="icon-bar"></span>
                     <span class="icon-bar"></span>
                    </a>
                    <a class="brand" href="dashboard.php">Bay Jewellers</a>
                    <div class="nav-collapse collapse">
                        <ul class="nav pull-right">
                        
                        <!--
                            <li class="dropdown">
                                <a href="#" role="button" class="dropdown-toggle" data-toggle="dropdown"> <i class="icon-user"></i> Vincent Gabriel <i class="caret"></i>

                                </a>
                                <ul class="dropdown-menu">
                                    <li>
                                        <a tabindex="-1" href="#">Profile</a>
                                    </li>
                                    <li class="divider"></li>
                                    <li>
                                        <a tabindex="-1" href="javascript:void(0)">Logout</a>
                                    </li>
                                </ul>
                            </li>
                            -->
                            
                        </ul>
                        <ul class="nav">
                            <li class="active">
                                <a href="dashboard.php">Dashboard</a>
                            </li>
                            <li class="dropdown">
                                <a href="vendor_master.php" >Vendors

                                </a>
                                
                            </li>
                            
                            <li class="dropdown">
                                <a href="edit_users.php" role="button">Customers

                                </a>
                               
                                
                            </li>
                            
                            <li class="dropdown">
                                <a href="dashboard.php" role="button" class="dropdown-toggle" data-toggle="dropdown">Products <i class="caret"></i>

                                </a>
                                <ul class="dropdown-menu">
                                <li>
                                        <a tabindex="-1" href="view_products.php">Products</a>
                                    </li>
                                    <li>
                                        <a tabindex="-1" href="view_gemstone.php">Gemstone</a>
                                    </li>
                                    <li>
                                        <a tabindex="-1" href="view_pearl.php">Pearl</a>
                                    </li>
                                    <li>
                                        <a tabindex="-1" href="view_diamond.php">Diamond</a>
                                    </li>
                                    <li>
                                        <a tabindex="-1" href="view_setting.php">Setting</a>
                                    </li>
                                    <li>
                                        <a tabindex="-1" href="add_product_type.php">Products</a>
                                    </li>
                                    <li>
                                        <a tabindex="-1" href="add_collection_type.php">Collections</a>
                                    </li>
                                    
                                </ul>
                            </li>
                            <li class="dropdown">
                                <a href="#" role="button" class="dropdown-toggle" data-toggle="dropdown">Pages<i class="caret"></i>

                                </a>
                                <ul class="dropdown-menu">
                                    <li>
                                        <a tabindex="-1" href="about.php">About Page</a>
                                    </li>
                                    <li>
                                        <a tabindex="-1" href="front_page.php">Main Page</a>
                                    </li>
                                    <li>
                                        <a tabindex="-1" href="contact.php">Contact Page</a>
                                    </li>
                                    
                                </ul>
                            </li>
                            
                            
                        </ul>
                    </div>
                    <!--/.nav-collapse -->
                </div>
            </div>
        </div>
        

<div class="container-fluid"> 