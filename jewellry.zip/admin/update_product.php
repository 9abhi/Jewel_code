<?php
include "inc/connect.php";
include "inc/function.php";

$p_type		=	isset($_REQUEST['p_type']) 	      ? $_REQUEST['p_type'] 	   : '';
$product_name  =	isset($_REQUEST['product_name'])	? $_REQUEST['product_name'] : '';
$collections	=	isset($_REQUEST['collection'])	  ? $_REQUEST['collection']   : '';
$retail_price  =	isset($_REQUEST['retail_price'])	? $_REQUEST['retail_price'] : '';
$excerpt       =    isset($_REQUEST['excerpt'])	? $_REQUEST['excerpt'] : '';
$save_arr      =	isset($_REQUEST['save_arr'])	? $_REQUEST['save_arr'] : '';
$p_desc 	    =	trim(isset($_REQUEST['p_desc'])	? $_REQUEST['p_desc'] : '');
$update_id 	    =	trim(isset($_REQUEST['update_id'])	? $_REQUEST['update_id'] : '');

$date_time = date('Y-m-d H:i:s');
if(isset($_REQUEST['add_product']))
{
	$collection	=	implode(",",$collections);
	$query	=	mysql_query("UPDATE product SET type='".$p_type."',name='".$product_name."',collection='".$collection."',retail_price='".$retail_price.				 					"',excerpt='".$excerpt."',description='".$p_desc."',composed='".$save_arr."',date_created='".$date_time."' WHERE id='".$update_id."'");
	if(isset($query))
	{
		$p_id		=	mysql_insert_id();
		$response	=	'Product Updated successfully';
		
		
			

			if ($_SERVER['REQUEST_METHOD'] == 'POST' AND isset($_FILES['image'])) 
			{
				
				// settings
				$max_file_size = 1024*200; // 200kb
				$valid_exts = array('jpeg', 'jpg', 'png', 'gif');
				// thumbnail sizes
				$sizes = array(60 => 58, 204 => 179, 900 => 900);
				 
				   if($_FILES['image']['tmp_name'][0]=='')
				   {
				$response	=	'Updated Successfully';
				echo("<script>window.location=\"view_products.php?response=".urlencode($response)."\"</script>");  
					   
				   }else
				   {
					foreach($_FILES['image']['tmp_name'] as $key => $tmp_name )
					{
						
						// get file extension
						
						$ext = strtolower(pathinfo($_FILES['image']['name'][$key], PATHINFO_EXTENSION));
						if (in_array($ext, $valid_exts)) {
							/* resize image */
							foreach ($sizes as $w => $h)
							{
								$temp_name	=	resize($w,$h,$key);
								$files[]	  =	$temp_name;
								$image_query	=	mysql_query("INSERT INTO product_images VALUES('','".$update_id."','".$temp_name."')");
								if(isset($image_query))
								{
									$response	=	'Successfull';
									echo("<script>window.location=\"view_products.php?response=".urlencode($response)."\"</script>");
								}
								else
								{
									$response	=	mysql_error();
									echo("<script>window.location=\"update_product.php?response=".urlencode($response)."\"</script>");
								}
							}
				
						 } 
					}
			}
				
					
				
			}
			
	}
}




?>