<?php
include "inc/header.php";
include "inc/connect.php";

$get_about=mysql_query("select * from pages where name='front'");
$count_ab=mysql_num_rows($get_about);
if($count_ab>0)
{
	$get_content=mysql_fetch_array($get_about);	
}


?>

<!-----start css---->
<link href="vendors/wysiwyg/bootstrap-wysihtml5.css" rel="stylesheet" media="screen">
<!-----end css---->
<!--------------------------start script------------------------->
<script src="vendors/wysiwyg/wysihtml5-0.3.0.js"></script>
<script src="vendors/wysiwyg/bootstrap-wysihtml5.js"></script>
<!--------------------------end script------------------------->

<div class="container-fluid">
            <div class="row-fluid">
                <?PHP	include 'sidebar.php'	?>
                <!--/span-->
                <div class="span9" id="content">
                      <!-- morris stacked chart -->
                    <div class="row-fluid">
                        <!-- block -->
                        <div class="block">
                            <div class="navbar navbar-inner block-header">
                                <div class="muted pull-left">Main Page</div>
                            </div>
                            <div class="block-content collapse in">
		<?php
			$response=$_REQUEST[response];
			if(isset($response))
			{
			echo("<tr><td colspan=5 align=center><font color=green>$response</font><br><br></td></tr>");
			}
		?>
                                <div class="span12">
                                
                                     <form class="form-horizontal" enctype="multipart/form-data" action="front_desc.php" method="post" name="add_product">
                                      <fieldset>
                                        <legend>Front Page</legend> 
                                        
                                        <div class="control-group">
                                          <label class="control-label" for="fileInput">Title</label>
                                          <div class="controls">
                                          <input class="input-file uniform_on" id="page_title" name="page_title" value="<?=$get_content['title']?>" type="text">
                                            
                                          </div>
                                        </div>
                                                                               
                                        <div class="control-group">
                                          <label class="control-label" for="textarea">Description</label>
                                          <div class="controls">
                                            <textarea class="input-xlarge textarea" placeholder="Enter text ..." name="front_desc" style="width: 600px; height: 200px">
											<?php 
											echo $get_content['description'];
                                            ?>
                                            </textarea>
                                          </div>
                                          
                                        </div>
                                        
                                       
                                        <div class="form-actions">
                                          <button type="reset" class="btn" id="cancel_click">Cancel</button>
                                          <button type="submit" class="btn btn-primary" name="add_front">Add Main Desc</button>
                                          
                                        </div>
                                      </fieldset>
                                    </form>

                                </div>
                            </div>
                        </div>
                        <!-- /block -->
                    </div>

                     

                     <!-- wizard -->
                    

                </div>
            </div>
            <hr>
            

<?php
include "inc/footer.php";
?>

<script>
$(document).ready(function() {
    $('.textarea').wysihtml5();
	$('#cancel_click').click(function() {
			window.location='front_page.php';
		});
});
</script>                