<?php
include "inc/header.php";
include "inc/connect.php";
$get_p_id	=	isset($_REQUEST['pro']) ? $_REQUEST['pro'] : '';
if(isset($get_p_id))
{
	$get_p_data=mysql_query("select * from product where id='".$get_p_id."'");
	$seek_data = mysql_fetch_array($get_p_data);	
	
	$get_p_images=mysql_query("select * from product_images where  p_id='".$get_p_id."'");
	
}

?>
<!-----start css---->
<link href="vendors/wysiwyg/bootstrap-wysihtml5.css" rel="stylesheet" media="screen">
 <link href="vendors/chosen.min.css" rel="stylesheet" media="screen">
<!-----end css---->
<!--------------------------start script------------------------->
<script src="vendors/wysiwyg/wysihtml5-0.3.0.js"></script>
<script src="vendors/wysiwyg/bootstrap-wysihtml5.js"></script>
<script src="vendors/chosen.jquery.min.js"></script>
<!--------------------------end script------------------------->
<style type="text/css">
span.tag {
    color: #638421;
    font-family: helvetica;
    font-size: 13px;
}
.tag {
    background: none repeat scroll 0px 0px #F2F2F2;
    border: 1px solid #D2D2D2;
    color: #638421;
    display: block;
    float: left;
    font-family: helvetica;
    font-size: 13px;
    margin-bottom: 5px;
	margin-left:5px;
    margin-right: 10px;
    padding-right: 10px;
	padding-left:5px;
	padding-top:5px;
	padding-bottom:5px;
    text-decoration: none;
	border-radius:7px;
	margin-top:2px;
}

</style>
<div class="container-fluid">
            <div class="row-fluid">
                <?PHP	include 'sidebar.php'	?>
                <!--/span-->
                <div class="span9" id="content">
                      <!-- morris stacked chart -->
                    <div class="row-fluid">
                        <!-- block -->
                        <div class="block">
                            <div class="navbar navbar-inner block-header">
                                <div class="muted pull-left">Edit Product</div>
                            </div>
                            <div class="block-content collapse in">
	<?php
    $response=$_REQUEST[response];
    if($response)
    {
    echo("<tr><td colspan=5 align=center><font color=green>$response</font><br><br></td></tr>");
    }
    ?>
                                <div class="span12">
                                
                                     <form class="form-horizontal" enctype="multipart/form-data" action="update_product.php" method="post" name="add_product">
                                      <fieldset>
                                        <legend>Edit product</legend> 
                                                                               
                                       <div class="control-group">
                                       
                                          <label class="control-label" for="fileInput">Type</label>
                                          <div class="span3">
                                          
                                          <select name="p_type">
                                          <?php
										  
										   $type_query	=	mysql_query("select * from product_type");
										  
                                          	while($row=mysql_fetch_array($type_query))
											{
												if($row['type']==$seek_data['type'])
												{
													echo '<option value="'.$row['id'].'" selected>'.$row['name'].'</option>';
													
												}else
												{
													echo '<option value="'.$row['id'].'">'.$row['name'].'</option>';
												}
											}
										  ?>
                                          </select>
                                            
                                          
                                          
                                          </div>
                                          <input type="hidden" value="<?=$get_p_id?>" name="update_id" />
                                        
                                          <label class="control-label" for="fileInput">Name</label>
                                          <div class="span3">
                                          <input class="input-file uniform_on" id="product_name" value="<?=$seek_data['name']?>" name="product_name" type="text">
                                            
                                          </div>
                                          </div>
                                          
                                      
                                        
                                        
                                      
                                        
                                        <div class="control-group">
                                          <label class="control-label" for="fileInput">Collection</label>
                                          <div class="span3">

                                          <select name="collection[]" multiple="multiple">
                                          
                                          <?php
										  $ecp=explode(',',$seek_data['collection']);
										   $collec_query	=	mysql_query("select * from collection_type");
										  
                                          	while($coll=mysql_fetch_array($collec_query))
											{
												if(in_array($coll['id'],$ecp))
												{
													echo '<option value="'.$coll['id'].'" selected>'.$coll['name'].'</option>';
													
												}else
												{
													echo '<option value="'.$coll['id'].'">'.$coll['name'].'</option>';
												}
											}
										  ?>
                                          
                                          </select>
                                            
                                          </div>
                                          
                                          <label class="control-label" for="fileInput">Retail Price</label>
                                          
                                          <div class="span3">
                                          
                                          <input class="input-file uniform_on" id="retail_price" name="retail_price" value="<?=$seek_data['retail_price']?>" type="text">
                                            
                                          </div>
                                          
                                        </div>
                                        
                                       
                                        
                                       
                                        <div class="control-group">
                                          <label class="control-label" for="fileInput">Excerpt</label>
                                          <div class="span3">
                                          <input class="input-file uniform_on" id="excerpt" name="excerpt" value="<?=$seek_data['excerpt']?>" type="text">
                                            
                                          </div>
                                          
                                          <div class="span3">
                                          <label class="control-label" for="fileInput" id="composed">Composed Of</label>
                                          </div>
                                          
                                          
                                        </div>
                                        
                                        <div style="display:none;" id="show_compose">
                                        <div class="control-group">
                                        
                                        <label class="control-label" for="select01">Select Diamond</label>
                                          <div class="span3" >
                                            <select id="diamond" class="chzn-select" >
                                              <option value="">--Select Diamond--</option>
                                              <?php
											  $get_dia=mysql_query("select id,name from diamond");
											  $dia_count=mysql_num_rows($get_dia);
											  if($dia_count>0)
											  {
												  
												  while($dia=mysql_fetch_array($get_dia))
												  { ?>
                                                  <option value="D_<?=$dia['id']?>_<?=$dia['name']?>"><?=$dia['name']?></option>
													  
												  <?php }
											  }
											  ?>
                                            </select>
                                          </div>
                                          
                                         <label class="control-label" for="select01">Select Gemstone</label>
                                          <div class="span3" >
                                            <select id="gemstone" class="chzn-select" >
                                              <option value="">--Select Gemstone--</option>
                                              <?php
											  $get_gem=mysql_query("select id,name from gemstone");
											  $gem_count=mysql_num_rows($get_gem);
											  if($gem_count>0)
											  {
												  while($gem=mysql_fetch_array($get_gem))
												  { ?>
                                                  <option value="G_<?=$gem['id']?>_<?=$gem['name']?>"><?=$gem['name']?></option>
													  
												  <?php }
											  }
											  ?>
                                            </select>
                                          </div>
                                          
                                        </div>
                                        
                                        <div class="control-group">
                                        
                                        <label class="control-label" for="select01">Select Pearl</label>
                                          <div class="span3" >
                                            <select id="pearl" class="chzn-select">
                                              <option value="">--Select Pearl--</option>
                                              <?php
											  $get_pe=mysql_query("select id,name from pearl");
											  $pe_count=mysql_num_rows($get_pe);
											  if($pe_count>0)
											  {
												  while($pe=mysql_fetch_array($get_pe))
												  { ?>
                                                  <option value="P_<?=$pe['id']?>_<?=$pe['name']?>"><?=$pe['name']?></option>
													  
												  <?php }
											  }
											  ?>
                                            </select>
                                          </div>
                                          
                                          <label class="control-label" for="select01">Select Settings</label>
                                          <div class="span3" >
                                            <select id="setting" class="chzn-select" >
                                              <option value="">--Select Setting--</option>
                                              <?php
											  $get_set=mysql_query("select id,name from setting");
											  $set_count=mysql_num_rows($get_set);
											  if($set_count>0)
											  {
												  while($set=mysql_fetch_array($get_set))
												  { ?>
                                                  <option value="S_<?=$set['id']?>_<?=$set['name']?>"><?=$set['name']?></option>
													  
												  <?php }
											  }
											  ?>
                                            </select>
                                          </div>
                                          
                                        </div>
                                        <div class="control-group" >
                                       
                                            <div  class="controls">
                                           
                                            <div id="get_all_compose"  style="width:600px; border:1px solid #ccc; min-height:100px;">
                                            
                                            </div>
                                            
                                            </div>
                                        </div>
                                        </div>
                                        
                                        <div class="control-group">
                                          <label class="control-label" for="textarea">Description</label>
                                          <div class="controls">
                                            <textarea class="input-xlarge textarea" placeholder="Enter text ..." name="p_desc" style="width: 600px; height: 200px">											<?php echo  htmlspecialchars_decode($seek_data['description'], ENT_QUOTES); ?>
											
											
                                            </textarea>
                                          </div>
                                          
                                        </div>
                                        
                                        <input type="hidden"  id="get_c_arr" value='<?=$seek_data['composed'];?>' />
                                        
                                        <div class="control-group">
                                          <label class="control-label" for="fileInput">Product Images</label>
                                          <div class="controls">
                                          <input class="input-file uniform_on" type="file" name="image[]" accept="image/*" multiple />
                                            
                                          </div>
                                        </div>
                                        <div class="control-group">
                                        <div class="controls">
											<?php
											$get_img_count=mysql_num_rows($get_p_images);
											if($get_img_count>0)
											{

												while($get_img=mysql_fetch_array($get_p_images))
												{
													
													?>
                                                    <div class="span3" style="border:1px solid #f1f1f1; height:203px; padding:5px; width:211px;">
													<img src="../uploads/<?=$get_img['image']?>" /></br>
                                                    
                                                    <div style="margin:2px; font-size:12px; float:left;">
                                                    <a id="img_del" onclick="del_img(<?=$get_img['id']?>,'<?=$get_img['image']?>')">Delete</a>
                                                    </div>
                                                    </div>
                                                    
												<?php
												 }
												
											}
											?>
                                        </div>
                                        </div>
                                        <input type="hidden" id="save_arr" name="save_arr" />
                                        
                                       
                                        <div class="form-actions">
                                          <button type="reset" class="btn" id="cancel_click">Cancel</button>
                                          <button type="submit" class="btn btn-primary" name="add_product" id="add_product">Update Product</button>
                                          
                                        </div>
                                      </fieldset>
                                      
                                    </form>

                                </div>
                            </div>
                        </div>
                        <!-- /block -->
                    </div>

                     

                     <!-- wizard -->
                    

                </div>
            </div>
            <hr>
            

<?php
include "inc/footer.php";
?>                
<script>
$(document).ready(function() {
	
	var compose_dat = [];
	var string = $('#get_c_arr').val();
	
    var arr = string.split(",");
	if(arr.length>0)
	{
		 $('#show_compose').show(200);
	}
	for(var i=0;i<arr.length;i++)
	{
		
		compose_dat.push(arr[i]);
		
		var ty	=	arr[i].split('_');
		
		$("#get_all_compose").append("<span class='tag'><span class='"+arr[i]+"'>"+ty[2]+"</span><a title='Removing tag'> x </a></span>");
		
	}
    $('.textarea').wysihtml5();
	$(".chzn-select").chosen();
	$('#composed').click(function(e) {
		
        $('#show_compose').toggle(200);
		
    });
	$('.chzn-select').change(function() {


		var sp_data	=	$(this).val();
		
		if(sp_data=='')
		{
		
		}
		else
		{
			
		compose_dat.push();	
		var sp_dat	 =	sp_data.split('_');
		var value_id   =    sp_dat[0]+'_'+sp_dat[1];
		
		compose_dat.push(sp_data);
		
		$("#get_all_compose").append("<span class='tag'><span class='"+sp_data+"'>"+sp_dat[2]+"</span><a title='Removing tag'> x </a></span>");
		
		}
        
    });
		$("#get_all_compose").on('click', '.tag', function(){
				
				var p	=	$(this).children('span').attr('class');
				var index =	compose_dat.indexOf('' + p.trim() + '');
				compose_dat.splice(index,1);
				$(this).remove();
		
		});
		$('#add_product').click(function() {
			$('#save_arr').val(compose_dat.toString());            
        });
		$('#cancel_click').click(function() {
			window.location='view_products.php';
		});
});
function del_img(id,img)
{
	
	$.ajax({
            type:"POST",
            url: "del_img/del_img.php",
			data: {'id':id,'img':img},
            success: function(data)
			{ 
				alert(data);
				location.reload();
			}
	});
}
</script>