<?php
include "inc/header.php";
include "inc/connect.php";

$get_id= isset($_REQUEST['e_id']) ? $_REQUEST['e_id'] : '';
if(!empty($get_id))
{
	$get_data=mysql_query("select * from product_type where id='".$get_id."'");
	$get_cnt=mysql_num_rows($get_data);
	if($get_cnt>0)
	{
		$row=mysql_fetch_array($get_data);
	}
?>

<div class="container-fluid">
            <div class="row-fluid">
                <?PHP	include 'sidebar.php'	?>
                <!--/span-->
                <div class="span9" id="content">
                      <!-- morris stacked chart -->
                    <div class="row-fluid">
                        <!-- block -->
                        <div class="block">
                            <div class="navbar navbar-inner block-header">
                                <div class="muted pull-left">Update Product Type</div>
                            </div>
                            <div class="block-content collapse in">
		
                                <div class="span12">
                                
                                     <form class="form-horizontal" enctype="multipart/form-data" method="post" action="edit_product_ty.php" name="up_product_type" id="up_product_type">
                                      <fieldset>
                                        <legend>Update product Type</legend> 
                                                                               
                                        
                                        
                                        <div class="control-group">
                                          <label class="control-label" for="fileInput">Enter Type</label>
                                          <div class="controls">
                                          <input class="input-file uniform_on"  name="product_type" value="<?=$row['name']?>" type="text">
                                            
                                          </div>
                                        </div>
                                        
                                        <input type="hidden" value="<?=$get_id?>" name="up_id" />
                                         <div class="control-group">
                                          <label class="control-label" for="fileInput">Image</label>
                                          <div class="controls">
                                          <input class="input-file uniform_on" type="file" name="image" accept="image/*" />
                                            
                                          </div>
                                        </div>
                                        
                                        <div class="control-group">
                                        <div class="controls">
                                            <div class="span3">
                                             <img src="../uploads_type/<?=$row['image']?>" />
                                            </div>
                                        </div>
                                        </div>
                                       
                                        <div class="form-actions">
                                          <button type="reset" class="btn">Cancel</button>
                                          <button type="submit" class="btn btn-primary" name="add_product_type">Update Product Type</button>
                                          
                                        </div>
                                      </fieldset>
                                    </form>

                                </div>
                            </div>
                            
                        </div>
                        <!-- /block -->
                    </div>

                     

                     <!-- wizard -->
                    

                </div>
            </div>
            <hr>
            

<?php
include "inc/footer.php";
}
?> 
               