<?PHP	include "inc/header.php";	?>




	<div class="row-fluid">

		<?PHP	include 'sidebar.php'	?>
       
        
        
        <div class="span9" id="content">
        	
            <div class="row-fluid">
            	
                <button class="btn btn-default" id="import_cust">Import Customers</button>
                <br>
<br>


                <?PHP include 'usersView.php';	?>
                
                
			</div>
		
        </div>
        
	</div>

	

<?php
include "inc/footer.php";
?>                
<script>
$(document).ready(function() {
    $('#import_cust').click(function() {
        window.location = 'import_users.php';
    });
});
</script>