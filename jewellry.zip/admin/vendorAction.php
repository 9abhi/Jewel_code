<?php

try
{
	include("inc/connect.php");	
	
	$tblName	=	"vendor";
	
	if($_GET["action"] == "list")
	{
		
		//Get record count
		$result	=	mysql_query("SELECT COUNT(*) AS RecordCount FROM ".$tblName." ");
		$row	=	mysql_fetch_array($result);
		$recordCount	=	 $row['RecordCount'];
		
		//Get records from database
		$query	=	"SELECT * FROM ".$tblName." ORDER BY " . $_GET["jtSorting"] . " LIMIT " . $_GET["jtStartIndex"] . "," . $_GET["jtPageSize"] . "";
		$result =	mysql_query($query);
		
		//Add all records to an array
		$rows 	= array();
		$start	=	isset($_GET["jtStartIndex"])	?	$_GET["jtStartIndex"]	:	0;
		while($row = mysql_fetch_assoc($result))
		{
		    $start++;
			
			$row['sr_no'] 	= $start;
			$row['contact_name']= $row['contact_fname']. ($row['contact_mname'] <> '' ? ' ' . $row['contact_lname'] : '') . ' ' . $row['contact_lname'];
			$row['address'] 	= $row['addressline1']. ($row['addressline1'] <> ''  &&  $row['addressline2'] <> '' ? ', ' : '') .($row['addressline2'] <> '' ? ' ' . $row[			 								 'addressline2'] : '');
			$row['phone']		= $row['phone1']. ($row['phone1'] <> ''  &&  $row['phone2'] <> '' ? ', ' : '') .($row['phone2'] <> '' ? ' ' . $row['phone2'] : '');	
			$rows[] = $row;
			
		}

		//Return result to jTable
		$jTableResult = array();
		$jTableResult['Result'] = "OK";
		$jTableResult['TotalRecordCount'] = $recordCount;
		$jTableResult['query'] = $query;
		$jTableResult['Records'] = $rows;
		print json_encode($jTableResult);
	}
	
	//Creating a new record (createAction)
	else if($_GET["action"] == "create")
	{
		//Insert record into database
		$result = mysql_query("INSERT INTO ".$tblName." VALUES('', '".$_POST["name"]."', '".$_POST["contact_fname"]."', '".$_POST["contact_mname"]."', '".$_POST["contact_lname"]."', '".$_POST["addressline1"]."', '".$_POST["addressline2"]."', '".$_POST["city"]."', '".$_POST["state"]."', '".$_POST["phone1"]."', '".$_POST["phone2"]."', '".$_POST["email"]."');") ;
		
		//Get last inserted record (to return to jTable)
		$result = mysql_query("SELECT * FROM ".$tblName." WHERE id = LAST_INSERT_ID();");
		$row = mysql_fetch_array($result);

		//Return result to jTable
		$jTableResult = array();
		$jTableResult['Result'] = "OK";
		$jTableResult['Record'] = $row;
		print json_encode($jTableResult);
	}
	
	
	//Updating a record (updateAction)
	else if($_GET["action"] == "update")
	{
		//Update record in database
		$result = mysql_query("UPDATE ".$tblName." SET name = '" . $_POST["name"] . "', contact_fname ='" . $_POST["contact_fname"] . "', contact_mname ='" . $_POST["contact_mname"] . "', contact_lname ='" . $_POST["contact_lname"] . "', addressline1 ='" . $_POST["addressline1"] . "', addressline2 ='" . $_POST["addressline2"] . "', city ='" . $_POST["city"] . "', state ='" . $_POST["state"] . "', phone1 ='" . $_POST["phone1"] . "', phone2 ='" . $_POST["phone2"] . "', email ='" . $_POST["email"] . "'  WHERE id = " . $_POST["id"] . ";");

		//Return result to jTable
		$jTableResult = array();
		$jTableResult['Result'] = "OK";
		print json_encode($jTableResult);
	}
	
	
	//Deleting a record (deleteAction)
	else if($_GET["action"] == "delete")
	{
		
		//Delete from database
		$result = mysql_query("DELETE FROM ".$tblName." WHERE id = " . $_POST["id"] . "");
		//$resultI= mysql_query("DELETE FROM mstorders_items WHERE order_no = " . $row["order_no"] . "");
		//Return result to jTable
		$jTableResult = array();
		$jTableResult['Result'] = "OK";
		print json_encode($jTableResult);
	}

	//Close database connection
	//mysql_close($con);

}
catch(Exception $ex)
{
    //Return error message
	$jTableResult = array();
	$jTableResult['Result'] = "ERROR";
	$jTableResult['Message'] = $ex->getMessage();
	print json_encode($jTableResult);
}
	
?>