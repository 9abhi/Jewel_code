<?php
include "jtable_inc.php";
?>    
   	<div id="usersTable" style="width:100%;"></div>
	
	<script type="text/javascript">

		$(document).ready(function () {
			
			//Prepare jTable
			$('#usersTable').jtable({
				title: 'Edit Customers',
				paging: true,
				pageSize: 25,
				sorting: true,
				defaultSorting: 'id ASC',
				actions: {
					listAction: 'usersAction.php?action=list',
					createAction: 'usersAction.php?action=create',
					updateAction: 'usersAction.php?action=update',
					deleteAction: 'usersAction.php?action=delete'
				},
				fields: {
					id: {
						key: true,
						create: false,
						edit: false,
						list: false
					},
					sr_no: {
						title:'S. No.',
						create: false,
						edit: false,
						width:'7%',
						sorting:false,
					},
					
					fname: {
						title: 'First name',
						width: '12%',
						create: true,
						edit: true,
						list: true,
						
					},
					mname: {
						title: 'Middle name',
						width: '13%',
						create: true,
						edit: true,
						list: true,
					},
					lname: {
						title: 'Last name',
						width: '12%',
						create: true,
						edit: true,
						list: true,
						
					},
					addressline1: {
						title: 'Addressline1',
						width:'12%',
						create:true,
						edit:true,
						
						list:true,
					},
					addressline2: {
						title: 'Addressline2',
						create:true,
						edit:true,
						list: true,
						width:'12%',
						
					},
					city: {
						title: 'City',
						create:true,
						edit:true,
						list: true,
						width:'10%',
					},
					state: {
						title: 'State',
						create:true,
						edit:true,
						list: true,
						width:'10%',
						options:'get_states.php',
						
					},
					phone1: {
						title: 'Phone 1',
						create:true,
						edit:true,
						list: true,
						width:'10%',
						
					},
					
					phone2: {
						title: 'Phone 2',
						create:true,
						edit:true,
						list: true,
						width:'10%',
						
					},
					
					email: {
						title: 'Email',
						create:true,
						edit:true,
						list: true,
						width:'20%',
						
					},
					password: {
						title: 'Password',
						create:true,
						edit:false,
						list: false,
						width:'20%',
						
					},
					
				},
				messages: {
                addNewRecord: 'Add new customer'
            }
				
				
				
			});
			
			
			$('#usersTable').jtable('load');

		});

	</script>
