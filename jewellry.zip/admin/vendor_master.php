<?PHP	include "inc/header.php";	?>




	<div class="row-fluid">

		<?PHP	include 'sidebar.php'	?>
       
        
        
        <div class="span9" id="content">
        
        <div class="row-fluid">
            	
                <button class="btn btn-default" id="import_vendor">Import Vendor</button>
                <br>
<br>
        	
            <div class="row-fluid">
            	
                
                <?PHP include 'vendorView.php';	?>
                
                
			</div>
		
        </div>
        
	</div>

	

<?php
include "inc/footer.php";
?>                
<script>
$(document).ready(function() {
    $('#import_vendor').click(function() {
        window.location = 'import_vendors.php';
    });
});
</script>