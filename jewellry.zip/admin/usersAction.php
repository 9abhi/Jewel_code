<?php

try
{
	include("inc/connect.php");	
	
	$tblName	=	"customers";
	$date_time = date('Y-m-d H:i:s');
	if($_GET["action"] == "list")
	{
		
		//Get record count
		$result	=	mysql_query("SELECT COUNT(*) AS RecordCount FROM ".$tblName." ");
		$row	=	mysql_fetch_array($result);
		$recordCount	=	 $row['RecordCount'];
		
		//Get records from database
		$query	=	"SELECT * FROM ".$tblName." ORDER BY " . $_GET["jtSorting"] . " LIMIT " . $_GET["jtStartIndex"] . "," . $_GET["jtPageSize"] . "";
		$result =	mysql_query($query);
		
		//Add all records to an array
		$rows 	= array();
		$start	=	isset($_GET["jtStartIndex"])	?	$_GET["jtStartIndex"]	:	0;
		while($row = mysql_fetch_assoc($result))
		{
		    $start++;
			$row['sr_no'] 	= $start;
			$row['fname']	= $row['fname'];
			$row['mname']	= $row['mname'];
			$row['lname'] 	= $row['lname'];
			
			$row['adressline1'] = $row['adressline1'];
			$row['adressline2'] = $row['adressline2'];
			$row['city'] 		= $row['city'];
			
			$row['state']	 = $row['state'];
			$row['phone1']	= $row['phone1'];
			$row['phone2'] 	= $row['phone2'];
			
			$row['email']	   = $row['email'];
			$row['password'] 	= $row['password'];
			
		
			$rows[] = $row;
			
		}

		//Return result to jTable
		$jTableResult = array();
		$jTableResult['Result'] = "OK";
		$jTableResult['TotalRecordCount'] = $recordCount;
		$jTableResult['query'] = $query;
		$jTableResult['Records'] = $rows;
		print json_encode($jTableResult);
	}
	
	//Creating a new record (createAction)
	else if($_GET["action"] == "create")
	{
		
		//Insert record into database
		$result = mysql_query("INSERT INTO ".$tblName." VALUES('', '".$_POST["fname"]."', '".$_POST["mname"]."', '".$_POST["lname"]."','".$_POST["addressline1"]."','".$_POST["addressline2"]."','".$_POST["city"]."','".$_POST["state"]."','".$_POST["phone1"]."','".$_POST["phone2"]."','".$_POST["email"]."','".$password."','".$date_time."');") ;
		
		//Get last inserted record (to return to jTable)
		$result = mysql_query("SELECT * FROM ".$tblName." WHERE id = LAST_INSERT_ID();");
		$row = mysql_fetch_array($result);

		//Return result to jTable
		$jTableResult = array();
		$jTableResult['Result'] = "OK";
		$jTableResult['Record'] = $row;
		print json_encode($jTableResult);
	}
	
	
	//Updating a record (updateAction)
	else if($_GET["action"] == "update")
	{
		//Update record in database
		$result = mysql_query("UPDATE ".$tblName." SET fname = '" . $_POST["fname"] . "',mname='".$_POST['mname']."',lname='".$_POST['lname']."',
		addressline1='".$_POST['addressline1']."',addressline2='".$_POST['addressline2']."',city='".$_POST['city']."',state='".$_POST['state']."',
		phone1='".$_POST['phone1']."',phone2='".$_POST['phone2']."',email='".$_POST['email']."'
		  WHERE id = " . $_POST["id"] . "");

		//Return result to jTable
		$jTableResult = array();
		$jTableResult['Result'] = "OK";
		print json_encode($jTableResult);
	}
	
	
	//Deleting a record (deleteAction)
	else if($_GET["action"] == "delete")
	{
		
		//Delete from database
		$result = mysql_query("DELETE FROM ".$tblName." WHERE id = " . $_POST["id"] . "");
		//$resultI= mysql_query("DELETE FROM mstorders_items WHERE order_no = " . $row["order_no"] . "");
		//Return result to jTable
		$jTableResult = array();
		$jTableResult['Result'] = "OK";
		print json_encode($jTableResult);
	}

	//Close database connection
	//mysql_close($con);

}
catch(Exception $ex)
{
    //Return error message
	$jTableResult = array();
	$jTableResult['Result'] = "ERROR";
	$jTableResult['Message'] = $ex->getMessage();
	print json_encode($jTableResult);
}
	
?>