<?php

include "../inc/connect.php";
$id=isset($_REQUEST['id']) ? $_REQUEST['id'] : '';

if(isset($id))
{
	$get_p_del=mysql_query("delete from diamond where id='".$id."'");
	if($get_p_del)
	{	
	 $get_del=mysql_query("select * from diamond_images where p_id='".$id."'");
	 $get_count=mysql_num_rows($get_del);
	 if($get_count>0)
	 {
		 while($row=mysql_fetch_array($get_del))
		 {
			 unlink('../../uploads/'.$row['image']);
		 }
	 }
	 $get_dele=mysql_query("delete from diamond_images where p_id='".$id."'");
	 
	 if($get_dele)
	 {
		 echo 'Deleted';
	 }
	 else
	 {
		 echo mysql_error();
	 }
		
	}
}
?>