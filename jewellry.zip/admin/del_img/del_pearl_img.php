<?php

include "../inc/connect.php";
$id=isset($_REQUEST['id']) ? $_REQUEST['id'] : '';
$img=isset($_REQUEST['img']) ? $_REQUEST['img'] : '';
if(isset($id))
{
$get_del=mysql_query("delete from pearl_images where id='".$id."'");
if($get_del)
{
	unlink('../../uploads/'.$img);
	echo 'deleted';
}
else
{
	echo mysql_error();
}
}
?>