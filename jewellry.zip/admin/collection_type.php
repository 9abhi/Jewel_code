<?php
include "inc/connect.php";
include "inc/function.php";

 $collection_type	=	isset($_REQUEST['collection_type']) ? $_REQUEST['collection_type'] : '';

if(isset($_REQUEST['add_collection_type']))
{
	
if ($_SERVER['REQUEST_METHOD'] == 'POST' AND isset($_FILES['image'])) 
			{
				
				// settings
				$max_file_size = 1024*200; // 200kb
				$valid_exts = array('jpeg', 'jpg', 'png', 'gif');
				// thumbnail sizes
				$sizes = array(60 => 58);
		
						// get file extension
						
						$ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
						if (in_array($ext, $valid_exts)) {
							/* resize image */
							foreach ($sizes as $w => $h)
							{
								   $temp_name	=	collec_resize($w,$h);
								
								   $query = "INSERT INTO collection_type (name, image) VALUES ('".$collection_type."','".$temp_name."' )";
								   $result=mysql_query($query);
								   if($result)
								   {
									   
									$response	=	'Your file upload was successful!';
									echo("<script>window.location=\"add_collection_type.php?response=".urlencode($response)."\"</script>");
									
								   }
								   else
								   {
									   $response	=	mysql_error();
									   echo("<script>window.location=\"add_collection_type.php?response=".urlencode($response)."\"</script>");
								   }
							}
				
						 } 
					
				
					
				
			}	
	
}
?>