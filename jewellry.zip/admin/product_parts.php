<?php
include "inc/header.php";
include "inc/connect.php";
?>
<div class="container-fluid">
            <div class="row-fluid">
                <?PHP	include 'sidebar.php'	?>
                <!--/span-->
                <div class="span9" id="content">
                      <!-- morris stacked chart -->
                    <div class="row-fluid">
                        <!-- block -->
                        <div class="block">
                            <div class="navbar navbar-inner block-header">
                                <div class="muted pull-left">Product Parts</div>
                            </div>
                            <div class="block-content collapse in">
                                <div class="span12">
                                     <form class="form-horizontal">
                                      <fieldset>
                                        <legend>Add Product Parts</legend>
                                                                                
                                       <div class="control-group ">
                                          <label class="control-label" for="selectError">Part Type</label>
                                          <div class="controls">
                                            <select id="selectError">
                                              <option value="diamond">Diamond</option>
                                              <option value="gemstone">Gemstone</option>
                                              <option value="pearl">Pearl</option>
                                              <option value="setting">Setting</option>
                                            </select>
                                            
                                          </div>
                                        </div>
                                        
                                         <div class="control-group">
                                          <label class="control-label" for="products">Products</label>
                                          <div class="controls">
                                          
                                            <select multiple="multiple" id="products" name="products[]" class="chzn-select span4">
                                            
											<?php
											
											$get_products=mysql_query("select * from product");
											$count_product	=	mysql_num_rows($get_products);
											if($count_product>0)
											{
												while($row=mysql_fetch_array($get_products))
												{
													
												?>
												<option value="<?=$row['id'];?>"><?=$row['collection'];?></option>
                                                <?php	
												
												}
											 
											}
												
											?>
                                            
                                              
                                              
                                            </select>
                                            
                                          </div>

                                        </div>
                                        
                                      
                                       
                                        
                                        
                                        
                                        
                                        <div class="form-actions">
                                          <button type="reset" class="btn">Cancel</button>
                                          <button type="submit" class="btn btn-primary">Add Product</button>
                                          
                                        </div>
                                      </fieldset>
                                    </form>

                                </div>
                            </div>
                        </div>
                        <!-- /block -->
                    </div>

                     

                     <!-- wizard -->
                    

                </div>
            </div>
            <hr>
            

<?php
include "inc/footer.php";
?>                