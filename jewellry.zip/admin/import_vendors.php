<?php
include "inc/header.php";
include "inc/connect.php";
?>
<div class="container-fluid">
            <div class="row-fluid">
                <?PHP	include 'sidebar.php'	?>
                <!--/span-->
                <div class="span9" id="content">
                      <!-- morris stacked chart -->
                    <div class="row-fluid">
                        <!-- block -->
                        <div class="block">
                            <div class="navbar navbar-inner block-header">
                                <div class="muted pull-left">Import Vendors</div>
                            </div>
                            <div class="block-content collapse in">
<?php
$response=$_REQUEST[response];
if($response)
{
echo("<tr><td colspan=5 align=center><font color=green>$response</font><br><br></td></tr>");
}
?>
                                <div class="span12">
                                
                                     <form class="form-horizontal" enctype="multipart/form-data" method="post" action="import_vendor.php">
                                      <fieldset>
                                        <legend>Import Vendors</legend>                                        
                                       <div class="control-group">
                                          <label class="control-label" for="fileInput">Import File</label>
                                          <div class="controls">
                                            <input class="input-file uniform_on" id="import_users" name="import_users" type="file">
                                          </div>
                                        </div>
                                       
                                        <div class="form-actions">
                                          <button type="reset" class="btn">Cancel</button>
                                          <button type="submit" class="btn btn-primary" name="import_click">Add Vendor</button>
                                          
                                        </div>
                                      </fieldset>
                                    </form>

                                </div>
                            </div>
                        </div>
                        <!-- /block -->
                    </div>

                     

                     <!-- wizard -->
                    

                </div>
            </div>
            <hr>
            

<?php
include "inc/footer.php";
?>                