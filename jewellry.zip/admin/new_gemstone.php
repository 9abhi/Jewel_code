<?php
include "inc/header.php";
include "inc/connect.php";
?>

	<div class="container-fluid">
            <div class="row-fluid">
                <?PHP	include 'sidebar.php'	?>
                <!--/span-->
                <div class="span9" id="content">
                      <!-- morris stacked chart -->
                    <div class="row-fluid">
                        <!-- block -->
                        <div class="block">
                            <div class="navbar navbar-inner block-header">
                                <div class="muted pull-left">Add Product</div>
                            </div>
                            <div class="block-content collapse in">
				<?php
                $response=$_REQUEST[response];
                if($response)
                {
                echo("<tr><td colspan=5 align=center><font color=green>$response</font><br><br></td></tr>");
                }
                ?>
                                <div class="span12">
                                
                                     <form class="form-horizontal" enctype="multipart/form-data" action="add_product.php" method="post" name="add_product">
                                      <fieldset>
                                        <legend>Add product</legend> 
                                                                               
                                       <div class="control-group">
                                          <label class="control-label" for="fileInput">Type</label>
                                          <div class="controls">
                                          
                                          <select name="p_type">
                                          <?php
										  
										   $type_query	=	mysql_query("select * from product_type");
										  
                                          	while($row=mysql_fetch_array($type_query))
											{
												echo '<option value="'.$row['id'].'">'.$row['name'].'</option>';
											}
										  ?>
                                          </select>
                                            
                                          </div>
                                        </div>
                                        
                                        
                                        <div class="control-group">
                                          <label class="control-label" for="fileInput">Name</label>
                                          <div class="controls">
                                          <input class="input-file uniform_on" id="product_name" name="product_name" type="text">
                                            
                                          </div>
                                        </div>
                                        
                                        <div class="control-group">
                                          <label class="control-label" for="fileInput">Collection</label>
                                          <div class="controls">
                                          
                                          <select name="collection">
                                          <?php
										  
										   $collec_query	=	mysql_query("select * from collection_type");
										  
                                          	while($coll=mysql_fetch_array($collec_query))
											{
												echo '<option value="'.$coll['id'].'">'.$coll['name'].'</option>';
											}
										  ?>
                                          </select>
                                            
                                          </div>
                                        </div>
                                        
                                       
                                        
                                        <div class="control-group">
                                          <label class="control-label" for="fileInput">Retail Price</label>
                                          <div class="controls">
                                          <input class="input-file uniform_on" id="retail_price" name="retail_price" type="text">
                                            
                                          </div>
                                        </div>
                                        
                                        <div class="control-group">
                                          <label class="control-label" for="fileInput">Description</label>
                                          <div class="controls">
                                          <textarea rows="4" cols="10" name="p_desc">
                                          </textarea>

                                            
                                          </div>
                                        </div>
                                        
                                        <div class="control-group">
                                          <label class="control-label" for="fileInput">Product Images</label>
                                          <div class="controls">
                                          <input class="input-file uniform_on" type="file" name="image[]" accept="image/*" multiple />
                                            
                                          </div>
                                        </div>
                                        
                                         <div class="control-group">
                                          <label class="control-label" for="textarea2">Textarea WYSIWYG</label>
                                          <div class="controls">
                                            <textarea class="input-xlarge textarea" placeholder="Enter text ..." style="width: 810px; height: 200px"></textarea>
                                          </div>
                                        </div>
                                        
                                       
                                        <div class="form-actions">
                                          <button type="reset" class="btn">Cancel</button>
                                          <button type="submit" class="btn btn-primary" name="add_product">Add Product</button>
                                          
                                        </div>
                                      </fieldset>
                                    </form>

                                </div>
                            </div>
                        </div>
                        <!-- /block -->
                    </div>

                     

                     <!-- wizard -->
                    

                </div>
            </div>
            <hr>
            

<?php
include "inc/footer.php";
?>
<script>
$(document).ready(function() {
	
    $('.textarea').wysihtml5();
});
</script>                