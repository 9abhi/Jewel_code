<?php
include "inc/header.php";
include "inc/connect.php";
include "inc/function.php";

$arr=array();
$get_user=mysql_query("select * from customers");
$get_user_cnt=mysql_num_rows($get_user);
if($get_user_cnt>0)
{
	while($itms=mysql_fetch_array($get_user))
	{
		$arr[$itms['id']]=$itms['email'];
	}
}


?>
<link href="bootstrap/css/DT_bootstrap.css" rel="stylesheet" media="screen">
<script src="bootstrap/js/jquery.dataTables.min.js"></script>
<script src="bootstrap/js/DT_bootstrap.js"></script>
<div class="container-fluid">
            <div class="row-fluid">
                <?PHP	include 'sidebar.php'	?>
                <!--/span-->
                <div class="span9" id="content">
                      <!-- morris stacked chart -->
                    <div class="row-fluid">
                        <!-- block -->
                        
                            <div class="block-content collapse in">
<?php
$response=$_REQUEST[response];
if($response)
{
echo("<tr><td colspan=5 align=center><font color=green>$response</font><br><br></td></tr>");
}
?>
                                <div class="span12">
                                
                                     <div class="block">
                            <div class="navbar navbar-inner block-header">
                                <div class="muted pull-left">Purchase Items</div>
                            </div>
                            <div class="block-content collapse in">
                                <div class="span12">
  									<table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered" id="example">
										<thead>
											<tr>
                                            
												<th>User</th>
												<th>Category(Type)</th>
												<th>Item Name</th>
                                                <th>Purchase Price</th>
												<th>PO Number</th>
                                                <th>Status</th>
                                                
											</tr>
										</thead>
										<tbody>
                                        <?php
										
										$get_tbl = mysql_query("select * from all_products");
										while($tb_name=mysql_fetch_array($get_tbl))
										{
											
											$tb_n=$tb_name['name'];
											$pr_fix=get_recent_prefix($tb_n);
										$get_pr=mysql_query("select * from $tb_n where sold_status='0'");
										$get_pr_cnt=mysql_num_rows($get_pr);
										if($get_pr_cnt>0)
										{
												while($pr=mysql_fetch_array($get_pr))
												{
												
											?>
											 <?php $id=$tb_n.'_'.$pr['id']; ?>		
                                            <tr class="gradeC">
												<td>
                                                
                                                <select style="width:140px;" id="user_<?=$id?>">
                                                <?php
												if(count($arr)>0)
												{
													foreach($arr as $key=>$val)
													{ ?>
													<option value="<?=$key?>"><?=$val?></option>	
													<?php }
												}
												?>
                                                </select>
                                                </td>
												<td><?=$tb_n?></td>
												<td><?=$pr['name'];?></td>
                                                <td><input type="text" value="<?=$pr['retail_price']?>" id="retpr_<?=$id?>"  style="width:100px;" /></td>
												<td class="center"><input type="text" style="width:100px;" id="po_<?=$id?>" /></td>
                                               
                                                <td><input type="button"  value="UNSOLD" id="<?=$id?>" onclick="get_sold('<?=$id?>')" class="btn btn-primary"  /></td>
                                                
												
											</tr>
							
											<?php
											$cj++;
												}
												$cj++;
											}
											
											}
											?>	
											
											
											
											
										</tbody>
									</table>
                                </div>
                            </div>
                        </div>

                                </div>
                            </div>
                        
                        <!-- /block -->
                    </div>

                     

                     <!-- wizard -->
                    

                </div>
            </div>
            <hr>
            

<?php
include "inc/footer.php";
?>  
<div id="saving_container" style="display:none;">
	<div id="saving" style="background-color:#000; position:fixed; width:100%; height:100%; top:0px; left:0px;z-index:100000"></div>
	<img id="saving_animation" src="../assets/images/storing_animation.gif" alt="saving" style="z-index:100001; margin-left:-32px; margin-top:-32px; position:fixed; left:50%; top:50%"/>
	<div id="saving_text" style="text-align:center; width:100%; position:fixed; left:0px; top:50%; margin-top:40px; color:#fff; z-index:100001">
	Processing Request...</div>
</div>              
<script>
function get_sold(id)
{
	
	var sp_data=id.split('_');
	
	var po_number=$('#po_'+id).val();
	
	var retail_price=$('#retpr_'+id).val();
	var user_id=$('#user_'+id).val();
	
	if(po_number=='')
	{
		alert('Enter PO number');
		$('#po_'+id).focus();
		return false;
	}
	
	if(retail_price=='')
	{
		alert('Enter Retail price');
		$('#retpr_'+id).focus();
		return false;
	}
	
			show_animation();
			$.ajax({
            type:"POST",
            url: "save_purchase.php",
			data: {'po_number':po_number,'item_id':sp_data[1],'item_prefix':sp_data[0],'user_id':user_id,'retail_price':retail_price},
            success: function(data)
			{ 
				setTimeout('hide_animation()', 500);
				
				$('#'+id).val('SOLD');
				
				
			}
			
			});
	
	
}
function show_animation()
{
	$('#saving_container').css('display', 'block');
	$('#saving').css('opacity', '.8');
}

function hide_animation()
{
	$('#saving_container').fadeOut();
}
</script>