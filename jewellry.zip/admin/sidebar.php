<div class="span3" id="sidebar">
        <ul class="nav nav-list bs-docs-sidenav nav-collapse collapse">
            <li>
                <a href="index.php"><i class="icon-chevron-right"></i> Dashboard</a>
            </li>
            
             <li>
                <a href="hold_items.php"><i class="icon-chevron-right"></i> Hold Items</a>
            </li>
            
            <li>
                <a href="purchase_items.php"><i class="icon-chevron-right"></i> Purchase Items</a>
            </li>
            
            <li>
                <a href="view_purchase_history.php"><i class="icon-chevron-right"></i> Purchase History</a>
            </li>
            
        </ul>
</div>