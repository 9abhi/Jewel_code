    <link href="themes/redmond/jquery-ui-1.8.16.custom.css" rel="stylesheet" type="text/css" />
	<link href="scripts/jtable/themes/lightcolor/gray/jtable.css" rel="stylesheet" type="text/css" />
		
	<script src="scripts/jquery-1.6.4.min.js" type="text/javascript"></script>
    <script src="scripts/jquery-ui-1.8.16.custom.min.js" type="text/javascript"></script>
    <script src="scripts/jtable/jquery.jtable.js" type="text/javascript"></script>
    
    <style>
        .child-opener-image { cursor: pointer; }
        .child-opener-image-column { text-align: center; }
		.jtable-dialog-form { min-width: 220px; height:50px; }
		.jtable-dialog-form input[type="text"] { min-width: 200px; }
		#filterForm { width:95%;  padding:10px; }
		input, select {width:auto; padding:7px 6px ; height: 33px; border-radius:6px; -moz-border-radius:6px; -webkit-border-radius:6px; border:solid 1px #DDD; font-size:12px; font-family:Arial; margin-left:0; } 
		select.elements option { padding:1px}
		select.elements option:first-child { display:none; padding:0px 2px;}
		input[type=submit], input[type=button]  { padding: 4px 6px; background-color:#BBB; color:#333; font-weight:600; cursor:pointer }
		.tag { background: none repeat scroll 0 0 #f2f2f2; border: 1px solid #82AD2B; color: #638421; display: block; float: left; font-family: Arial; font-size: 13px; margin-bottom: 5px; margin-right: 5px; padding: 0; text-decoration: none; }
		span.tag { color: #638421; font-family: Arial; font-size: 13px; }
		span.tag span { float:left; padding:5px;}
		span.tag a { margin:0; color: white; font-size: 13px; font-weight: bold; text-decoration: none; cursor:pointer; padding:5px 10px; height:100%; background-color:#82AD2B; float:right; }
		.ui-widget-content { width:500px !important;}
		input.elements, select.elements { width:auto; max-width:200px; min-width:80px; }
		.jtable-input-field-container { float:left !important; margin-left:10px;  height: 63px; }
		.showing { margin-left:10px;}
		.jtable-input-field-container select { width:211px; height: 32px;}
    </style>