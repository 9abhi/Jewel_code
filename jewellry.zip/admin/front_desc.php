<?php
include "inc/connect.php";
$front_desc	=	isset($_REQUEST['front_desc']) ? trim($_REQUEST['front_desc']) : '';
$page_title    =	isset($_REQUEST['page_title']) ? trim($_REQUEST['page_title']) : '';

if(isset($_REQUEST['add_front']))
{
$chk_query	=	mysql_query("select * from pages where name='front'");
$chk_count	=	mysql_num_rows($chk_query);
if($chk_count>0)
{
	$up_abt	=	mysql_query("UPDATE pages SET description='".$front_desc."',title='".$page_title."' WHERE name='about'");
	if($up_abt)
	{
		$response	=	'Update successfully';
		echo("<script>window.location=\"front_page.php?response=".urlencode($response)."\"</script>");
	}
	else
	{
		$response	=	'Oops'.mysql_error();
		echo("<script>window.location=\"front_page.php?response=".urlencode($response)."\"</script>");
		
	}
}
else
{

$query = "INSERT INTO pages (name,description,title) VALUES ('front','".$front_desc."','".$page_title."')";
$result=mysql_query($query);
	if($result)
	{
		$response	=	'Submitted successful!';
		echo("<script>window.location=\"front_page.php?response=".urlencode($response)."\"</script>");	
	}
	
	
}
	
}


								
								   
									
?>