<?PHP	include "inc/header.php";	?>




	<div class="row-fluid">

		<?PHP	include 'sidebar.php'	?>
       
        
        
        <div class="span9" id="content">
        	
            <div class="row-fluid">
            	
                
                <?PHP include 'pearlView.php';	?>
                
                
			</div>
		
        </div>
        
	</div>

	

<?php
include "inc/footer.php";
?>                