<?php

include "inc/connect.php";
$id=isset($_REQUEST['id']) ? $_REQUEST['id'] : '';

if(isset($id))
{
$query=mysql_query("select * from collection_type where id='".$id."'");
$gt_dat=mysql_fetch_array($query);
	if($query)
	{	
	unlink('../uploads_collection/'.$gt_dat['image']);
	$get_del=mysql_query("delete from collection_type where id='".$id."'");
	
	if($get_del)
	{
		
		echo 'deleted';
	}
	else
	{
		echo mysql_error();
	}
	}
}
?>