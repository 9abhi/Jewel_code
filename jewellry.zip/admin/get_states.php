<?php

	include("inc/connect.php");
	
	
	
	//Get records from database
	$query			=	"SELECT code as Value, state as DisplayText FROM states ORDER BY id ASC ";
	$result 		=	mysql_query($query);
	$counter		=	mysql_num_rows($result);
	
	$rows = array();
	
	while($row = mysql_fetch_assoc($result))
	{
			$inner					=	array();
			$inner['DisplayText']	=	$row['DisplayText'];
			$inner['Value']			=	$row['Value'];
			$rows[]					=	$inner;
			
	}

	//Return result to jTable
	$jTableResult = array();
	$jTableResult['Result'] = "OK";
	$jTableResult['Options'] = $rows;
	print json_encode($jTableResult);
	
?>