<?php
include "inc/connect.php";
include "inc/function.php";

$p_type		=	isset($_REQUEST['p_type']) 	  ? $_REQUEST['p_type'] 	   : '';
$name 		  =	isset($_REQUEST['name'])? $_REQUEST['name'] : '';
$update_id	=	 isset($_REQUEST['update_id'])  ? $_REQUEST['update_id']   : '';

$diameter  =	isset($_REQUEST['diameter'])? $_REQUEST['diameter'] : '';
$luster       =    isset($_REQUEST['luster'])	 ? $_REQUEST['luster'] 	  : '';

$retail_price      =	isset($_REQUEST['retail_price'])	? $_REQUEST['retail_price'] 	 : '';

$vendor 	    =	trim(isset($_REQUEST['vendor']) ? $_REQUEST['vendor'] 	   : '');
$p_desc 	    =	isset($_REQUEST['p_desc']) ? $_REQUEST['p_desc'] 	   : '';

$date_time = date('Y-m-d H:i:s');
$p_desc = htmlspecialchars($p_desc, ENT_QUOTES);
if(isset($_REQUEST['add_pearl']))
{
	if($update_id=='')
	{
	if(!empty($name))
	{
	$query	=	mysql_query("INSERT INTO pearl VALUES('','".$p_type."','".$name."','".$diameter."','".$luster."','".$p_desc."',
	'".$vendor."','".$retail_price."','0','0','".$date_time."')");
	if(isset($query))
	{
		$p_id		=	mysql_insert_id();
		$response	=	'Pearl Submitted successfully';
	
			if ($_SERVER['REQUEST_METHOD'] == 'POST' AND isset($_FILES['image'])) 
			{
				
				// settings
				$max_file_size = 1024*200; // 200kb
				$valid_exts = array('jpeg', 'jpg', 'png', 'gif');
				// thumbnail sizes
				$sizes = array(60 => 58, 204 => 179, 900 => 900);
				 
				  if($_FILES['image']['tmp_name'][0]=='')
				   {
					$response	=	'Added Successfully';
					echo("<script>window.location=\"view_pearl.php?response=".urlencode($response)."\"</script>");  
					   
				   }else
				   {
					foreach($_FILES['image']['tmp_name'] as $key => $tmp_name ){
						
					 
					
						// get file extension
						
						$ext = strtolower(pathinfo($_FILES['image']['name'][$key], PATHINFO_EXTENSION));
						if (in_array($ext, $valid_exts)) {
							/* resize image */
							foreach ($sizes as $w => $h)
							{
								$temp_name	=	resize($w,$h,$key);
								$files[]	  =	$temp_name;
								$image_query	=	mysql_query("INSERT INTO pearl_images VALUES('','".$p_id."','".$temp_name."')");
								if(isset($image_query))
								{
									$response	=	'Successfullsd';
									echo("<script>window.location=\"view_pearl.php?response=".urlencode($response)."\"</script>");
								}
								else
								{
									$response	=	mysql_error();
									echo("<script>window.location=\"pearl_page.php?response=".urlencode($response)."\"</script>");
								}
							}
				
						 } 
					}
				   }
					
				
			}
			
	}
	}
	else
	{
		$response	=	'Specify Product Name';
		echo("<script>window.location=\"gemstone_page.php?response=".urlencode($response)."\"</script>");
	}
	}else
	{
		
	if(!empty($name))
	{
	$query	=	mysql_query("UPDATE pearl SET type='".$p_type."',name='".$name."',diameter='".$diameter."',luster='".$luster."',description='".$p_desc."',
	vendor_id='".$vendor."',retail_price='".$retail_price."',date_created='".$date_time."' WHERE id='".$update_id."'");
	if(isset($query))
	{
		$p_id		=	$update_id;
		$response	=	'Pearl Updated successfully';
	
			if ($_SERVER['REQUEST_METHOD'] == 'POST' AND isset($_FILES['image'])) 
			{
				
				// settings
				$max_file_size = 1024*200; // 200kb
				$valid_exts = array('jpeg', 'jpg', 'png', 'gif');
				// thumbnail sizes
				$sizes = array(60 => 58, 204 => 179, 900 => 900);
				 
				  if($_FILES['image']['tmp_name'][0]=='')
				   {
					$response	=	'Update Successfully';
					echo("<script>window.location=\"view_pearl.php?response=".urlencode($response)."\"</script>");  
					   
				   }else
				   {
					   
					foreach($_FILES['image']['tmp_name'] as $key => $tmp_name ){
						
						// get file extension
						
						$ext = strtolower(pathinfo($_FILES['image']['name'][$key], PATHINFO_EXTENSION));
						
						if (in_array($ext, $valid_exts)) {
							/* resize image */
							foreach ($sizes as $w => $h)
							{
								$temp_name	=	resize($w,$h,$key);
								$files[]	  =	$temp_name;
								$image_query	=	mysql_query("INSERT INTO pearl_images VALUES('','".$p_id."','".$temp_name."')");
								if(isset($image_query))
								{
									$response	=	'Successfully updated';
									echo("<script>window.location=\"view_pearl.php?response=".urlencode($response)."\"</script>");
								}
								else
								{
									$response	=	mysql_error();
									echo("<script>window.location=\"pearl_page.php?response=".urlencode($response)."\"</script>");
								}
							}
				
						 } 
					}
				   }
					
				
			}
			
	}
	}
	else
	{
		$response	=	'Specify Product Name';
		echo("<script>window.location=\"pearl_page.php?response=".urlencode($response)."\"</script>");
	}

	}
	
}




?>