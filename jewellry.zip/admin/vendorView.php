<?php
include "jtable_inc.php";
?>    
   	<div id="vendorTable" style="width:100%;"></div>
	
	<script type="text/javascript">

		$(document).ready(function () {
			
			//Prepare jTable
			$('#vendorTable').jtable({
				title: 'Vendor List',
				paging: true,
				pageSize: 25,
				sorting: true,
				defaultSorting: 'name ASC',
				actions: {
					listAction: 'vendorAction.php?action=list',
					createAction: 'vendorAction.php?action=create',
					updateAction: 'vendorAction.php?action=update',
					deleteAction: 'vendorAction.php?action=delete'
				},
				fields: {
					id: {
						key: true,
						create: false,
						edit: false,
						list: false
					},
					sr_no: {
						title:'Sr. No.',
						create: false,
						edit: false,
						width:'7%',
						sorting:false,
					},
					name: {
						title: 'Name',
						width: '15%',
						create: true,
						edit: true,
					},
					contact_name: {
						title: 'Contact Name',
						width: '15%',
						create: false,
						edit: false,
						sorting: false
					},
					contact_fname: {
						title: 'Contact First Name',
						width: '30%',
						create: true,
						edit: true,
						list: false,
					},
					contact_mname: {
						title: 'Contact Middle Name',
						width: '30%',
						create: true,
						edit: true,
						list: false,
					},
					contact_lname: {
						title: 'Contact Last Name',
						width: '30%',
						create: true,
						edit: true,
						list: false,
					},
					address: {
						title: 'Address',
						width:'15%',
						create:false,
						edit:false,
						sorting: false,
					},
					addressline1: {
						title: 'Address Line 1',
						create:true,
						edit:true,
						list: false,
					},
					addressline2: {
						title: 'Address Line 2',
						create:true,
						edit:true,
						list: false,
					},
					city: {
						title: 'City',
						create:true,
						edit:true,
					},
					state: {
						title: 'State',
						create:true,
						edit:true,
						list:true,
						options:'get_states.php'
						
					},
					phone: {
						title: 'Contact No.s',
						width:'15%',
						create:false,
						edit:false,
						sorting: false
					},
					phone1: {
						title: 'Phone 1',
						create:true,
						edit:true,
						list:false,
					},
					phone2: {
						title: 'Phone 2',
						create:true,
						edit:true,
						list:false,
					},
					email: {
						title: 'Email ID',
						width: '20%',
						create: true,
						edit: true,
					}
				},
				 messages: {
                addNewRecord: 'Add new vendor'
            }
				
				
				
			});
			
			
			$('#vendorTable').jtable('load');

		});

	</script>
