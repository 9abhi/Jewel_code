<?php
include "inc/header.php";
include "inc/connect.php";
include "inc/function.php";


?>
<link href="bootstrap/css/DT_bootstrap.css" rel="stylesheet" media="screen">
<script src="bootstrap/js/jquery.dataTables.min.js"></script>
<script src="bootstrap/js/DT_bootstrap.js"></script>
<div class="container-fluid">
            <div class="row-fluid">
                <?PHP	include 'sidebar.php'	?>
                <!--/span-->
                <div class="span9" id="content">
                      <!-- morris stacked chart -->
                    <div class="row-fluid">
                        <!-- block -->
                        
                            <div class="block-content collapse in">
<?php
$response=$_REQUEST[response];
if($response)
{
echo("<tr><td colspan=5 align=center><font color=green>$response</font><br><br></td></tr>");
}
?>
                                <div class="span12">
                                
                                     <div class="block">
                            <div class="navbar navbar-inner block-header">
                                <div class="muted pull-left">Purchase History</div>
                            </div>
                            <div class="block-content collapse in">
                                <div class="span12">
  									<table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered" id="example">
										<thead>
											<tr>
                                            
												<th>User</th>
												<th>Category(Type)</th>
												<th>Item Name</th>
                                                <th>Purchase Price</th>
												<th>PO Number</th>
                                                <th>Status</th>
                                                
											</tr>
										</thead>
										<tbody>
                                        <?php
										$get_tbl = mysql_query("select * from user_item_purchase_history ORDER BY date_purchased DESC");
										while($tb_name=mysql_fetch_array($get_tbl))
										{
										$get_user_name=mysql_query("select * from customers where id='".$tb_name['user_id']."'");
										$user_name=mysql_fetch_array($get_user_name);	
										$tb_n=$tb_name['item_type'];
										$get_pr=mysql_query("select * from $tb_n where sold_status='1'");
										$get_pr_cnt=mysql_num_rows($get_pr);
										if($get_pr_cnt>0)
										{
											while($pr=mysql_fetch_array($get_pr))
											{
												
											?>
													
                                            <tr class="gradeC">
												<td>
                                                   <?=$user_name['email'];?>                                             
                                                </td>
												<td><?=$tb_name['item_type']?></td>
												<td><?=$pr['name'];?></td>
                                                <td><?=$pr['retail_price']?></td>
												<td class="center"><?=$tb_name['po_number']?></td>
                                              
                                                <td class="center">SOLD</td>
                                                
												
											</tr>
							
											<?php
												}
											}
											
											}
											?>	
											
											
											
											
										</tbody>
									</table>
                                </div>
                            </div>
                        </div>

                                </div>
                            </div>
                        
                        <!-- /block -->
                    </div>

                     

                     <!-- wizard -->
                    

                </div>
            </div>
            <hr>
            

<?php
include "inc/footer.php";
?>  
