<?php
include "inc/connect.php";
include "inc/function.php";

$product_coll =	isset($_REQUEST['product_coll']) 	  ?  $_REQUEST['product_coll'] 	   : '' ;
$up_id		=	isset($_REQUEST['up_id']) 	  ?  $_REQUEST['up_id'] 	   : '' ;

if(isset($_REQUEST['add_collection_type']))
{
	if ($_SERVER['REQUEST_METHOD'] == 'POST' AND isset($_FILES['image'])) 
			{
				
				// settings
				$max_file_size = 1024*200; // 200kb
				$valid_exts = array('jpeg', 'jpg', 'png', 'gif');
				
				// thumbnail sizes
				$sizes = array(60 => 58);
		
						// get file extension
						if(!empty($_FILES['image']['name']))
						{
						$ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
						if (in_array($ext, $valid_exts)) {
							/* resize image */
							foreach ($sizes as $w => $h)
							{
								   $temp_name	=	collec_resize($w,$h);
								   $get_p=mysql_query("select * from collection_type where id='".$up_id."'");
								   $get_pd=mysql_fetch_array($get_p);
								   
								   unlink('../uploads_collection/'.$get_pd['image']);
								   
								   $query = "UPDATE collection_type SET name='".$product_coll."',image='".$temp_name."' WHERE id='".$up_id."' ";
								   $result=mysql_query($query);
								   if($result)
								   {
									   
									$response	=	'Update successful!';
									echo("<script>window.location=\"add_collection_type.php?response=".urlencode($response)."\"</script>");
									
								   }
								   else
								   {
									   $response	=	mysql_error();
									   echo("<script>window.location=\"add_collection_type.php?response=".urlencode($response)."\"</script>");
								   }
							}
				
						 } 
			}else
			{
								   $query = "UPDATE collection_type SET name='".$product_coll."' WHERE id='".$up_id."'";
								   $result=mysql_query($query);
								   if($result)
								   {
									   
									$response	=	'Update successful!';
									echo("<script>window.location=\"add_collection_type.php?response=".urlencode($response)."\"</script>");
									
								   }
								   else
								   {
									   $response	=	mysql_error();
									   echo("<script>window.location=\"add_collection_type.php?response=".urlencode($response)."\"</script>");
								   }
				
			}
					
				
					
				
			}
	
}
?>