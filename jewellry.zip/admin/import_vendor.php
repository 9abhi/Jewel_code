<?php
include "inc/connect.php";
if(isset($_POST['import_click']))
{


/** Include path **/
set_include_path(get_include_path() . PATH_SEPARATOR . 'Classes/');

/** PHPExcel_IOFactory */
include 'PHPExcel/IOFactory.php';


$inputFileName = $_FILES["import_users"]["tmp_name"];  // File to read
//echo 'Loading file ',pathinfo($inputFileName,PATHINFO_BASENAME),' using IOFactory to identify the format<br />';
try {
	
	$objPHPExcel = PHPExcel_IOFactory::load($inputFileName);
} catch(Exception $e) {
	
	$response	=	'Error loading file "'.pathinfo($inputFileName,PATHINFO_BASENAME).'": '.$e->getMessage();
	
	echo("<script>window.location=\"import_vendors.php?response=".urlencode($response)."\"</script>");
}


echo '<hr />';
echo "<pre>";
$sheetData = $objPHPExcel->getActiveSheet()->toArray(null,true,true,true);

if(count($sheetData)>0)
{
	for($i=2;$i<=count($sheetData);$i++)
	{
		$password=	md5($sheetData[$i]['L']);
		
		 $save_data=mysql_query("INSERT INTO vendor VALUES('','".$sheetData[$i]['A']."','".$sheetData[$i]['B']."','".$sheetData[$i]['C']."'
		,'".$sheetData[$i]['D']."','".$sheetData[$i]['E']."','".$sheetData[$i]['F']."','".$sheetData[$i]['G']."','".$sheetData[$i]['H']."','".$sheetData[$i]['I']."'
		,'".$sheetData[$i]['J']."','".$sheetData[$i]['K']."') ");
		if($save_data)
		{
			$response = 'File Uploaded Successfully'.count($sheetData);
			echo("<script>window.location=\"import_vendors.php?response=".urlencode($response)."\"</script>");
			
		}
		else
		{
			$response	= "Something is wrong".mysql_error();
			echo("<script>window.location=\"import_vendors.php?response=".urlencode($response)."\"</script>");
		
		}
		
	}
}

 
}

?>