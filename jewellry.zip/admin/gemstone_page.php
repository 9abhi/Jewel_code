<?php
include "inc/header.php";
include "inc/connect.php";
?>
<!-----start css---->
<link href="vendors/wysiwyg/bootstrap-wysihtml5.css" rel="stylesheet" media="screen">

<!-----end css---->
<!--------------------------start script------------------------->
<script src="vendors/wysiwyg/wysihtml5-0.3.0.js"></script>
<script src="vendors/wysiwyg/bootstrap-wysihtml5.js"></script>

<!--------------------------end script------------------------->

<div class="container-fluid">
            <div class="row-fluid">
                <?PHP	include 'sidebar.php'	?>
                <!--/span-->
                <div class="span9" id="content">
                      <!-- morris stacked chart -->
                    <div class="row-fluid">
                        <!-- block -->
                        <div class="block">
                            <div class="navbar navbar-inner block-header">
                                <div class="muted pull-left">Add Gemstone</div>
                            </div>
                            <div class="block-content collapse in">
	<?php
    $response=$_REQUEST[response];
    if($response)
    {
    echo("<tr><td colspan=5 align=center><font color=green>$response</font><br><br></td></tr>");
    }
    ?>
                                <div class="span12">
                                
                                     <form class="form-horizontal" enctype="multipart/form-data" action="gemstone_add.php" method="post" name="add_product">
                                      <fieldset>
                                        <legend>Add Gemstone</legend> 
                                                                               
                                       <div class="control-group">
                                       
                                          <label class="control-label" for="fileInput">Type</label>
                                          <div class="span3">
                                          
                                          <select name="g_type">
                                          <option value="agate">Agate</option>
                                          <option value="amethyst">Amethyst</option>
                                          <option value="aquamarine">Aquamarine</option>
                                          <option value="blue_topaz">Blue Topaz</option>
                                          <option value="morganite">Morganite</option>
                                          <option value="multi_gemstone">Multi Gemstone</option>
                                          <option value="opal">Opal</option>
                                          <option value="peridot">Peridot</option>
                                          <option value="pink_tourmaline">Pink tourmaline</option>
                                          <option value="quartz">quartz</option>
                                          <option value="ruby">Ruby</option>
                                          <option value="sapphire">sapphire</option>
                                          <option value="tanzanite">tanzanite</option>
                                          <option value="white_topaz">White Topaz</option>
                                          <option value="other">Other</option>
                                          
                                          </select>
                                            
                                         
                                          
                                          </div>
                                          
                                        
                                          <label class="control-label" for="fileInput">Shape</label>
                                          <div class="span3">
                                          <select name="shape">
                                          <option value="princess">princess</option>
                                          <option value="emerald">emerald</option>
                                          <option value="asscher">asscher</option>
                                          <option value="oval">oval</option>
                                          <option value="marquise">marquise</option>
                                          <option value="custion">custion</option>
                                          <option value="radiant">radiant</option>
                                          <option value="pear">pear</option>
                                          
                                          
                                          </select>
                                            
                                          </div>
                                          </div>
                                          
                                      
                                        
                                        
                                      
                                        
                                        <div class="control-group">
                                          <label class="control-label" for="fileInput">Name</label>
                                          <div class="span3">
                                          
                                           <input class="input-file uniform_on" id="name" name="name" type="text">
                                            
                                          </div>
                                          
                                          <label class="control-label" for="fileInput">Carat</label>
                                          <div class="span3">
                                          <input class="input-file uniform_on" id="carat" name="carat" type="text">
                                            
                                          </div>
                                        </div>
                                        
                                        <div class="control-group">
                                          <label class="control-label" for="fileInput">Retail Price</label>
                                          <div class="span3">
                                          <input class="input-file uniform_on" id="retail_price" name="retail_price" type="number">
                                            
                                          </div>
                                          
                                          <label class="control-label" for="fileInput">Vendor</label>
                                          <div class="span3">
                                           <select name="vendor">
                                          <?php
                                          $query_ven = mysql_query("SELECT id as Value, contact_fname as DisplayText FROM vendor ORDER BY contact_fname ASC");
											
											$counter		=	mysql_num_rows($query_ven);
											if($counter>0)
											{
												while($ven=mysql_fetch_array($query_ven))
												{
												 ?>
												<option value="<?=$ven['Value']?>"><?=$ven['DisplayText']?></option>
											<?php 
												}}
												?>
	
                                          
                                          
                                          </select>
                                            
                                          </div>
                                          
                                          
                                        </div>
                                        
                                        <div class="control-group">
                                          <label class="control-label" for="textarea">Description</label>
                                          <div class="controls">
                                            <textarea class="input-xlarge textarea" placeholder="Enter text ..." name="g_desc" style="width: 600px; height: 200px">
											
                                            </textarea>
                                          </div>
                                          
                                        </div>
                                        
                                        
                                      <div class="control-group">
                                          <label class="control-label" for="fileInput">Images</label>
                                          <div class="controls">
                                          <input class="input-file uniform_on" type="file" name="image[]" accept="image/*" multiple />
                                            
                                          </div>
                                        </div>
                                       
                                        
                                       
                                        <div class="form-actions">
                                          <button type="reset" class="btn" id="cancel_click">Cancel</button>
                                          <button type="submit" class="btn btn-primary" name="add_gemstone" id="add_product">Add Gemstone</button>
                                          
                                        </div>
                                      </fieldset>
                                    </form>

                                </div>
                            </div>
                        </div>
                        <!-- /block -->
                    </div>

                     

                     <!-- wizard -->
                    

                </div>
            </div>
            <hr>
            

<?php
include "inc/footer.php";
?>                
<script>
$(document).ready(function() {
	
    $('.textarea').wysihtml5();
	$('#cancel_click').click(function() {
			window.location='view_gemstone.php';
		});
	
	});
</script>