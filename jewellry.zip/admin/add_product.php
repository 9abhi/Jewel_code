<?php
include "inc/connect.php";
include "inc/function.php";

$p_type		=	isset($_REQUEST['p_type']) 	  ? $_REQUEST['p_type'] 	   : '';
$product_name  =	isset($_REQUEST['product_name'])? $_REQUEST['product_name'] : '';
$collections	=	isset($_REQUEST['collection'])  ? $_REQUEST['collection']   : '';
$retail_price  =	isset($_REQUEST['retail_price'])? $_REQUEST['retail_price'] : '';
$excerpt       =    isset($_REQUEST['excerpt'])	 ? $_REQUEST['excerpt'] 	  : '';
$save_arr      =	isset($_REQUEST['save_arr'])	? $_REQUEST['save_arr'] 	 : '';
$p_desc 	    =	trim(isset($_REQUEST['p_desc']) ? $_REQUEST['p_desc'] 	   : '');
$p_desc = htmlspecialchars($p_desc, ENT_QUOTES);
$date_time = date('Y-m-d H:i:s');
if(isset($_REQUEST['add_product']))
{
	if(!empty($product_name) && !empty($collections))
	{
		
	$collection	=	implode(",",$collections);
	$query	=	mysql_query("INSERT INTO product VALUES('','".$p_type."','".$product_name."','".$collection."','".$retail_price."','".$excerpt."',
	'".$p_desc."','".$save_arr."','0','".$date_time."')");
	if($query)
	{
		$p_id		=	mysql_insert_id();
		if(!empty($save_arr))
		{
			$arr=explode(",",$save_arr);
			foreach($arr as $ab)
			{
				$val_arr=explode("_",$ab);
				$table=get_tbl($val_arr[0]);
				$upda_query=mysql_query("UPDATE $table SET inc_status='1' WHERE id='".$val_arr[1]."'");
			}
			
		}
		
		$response	=	'Product Submitted successfully';
		
			if ($_SERVER['REQUEST_METHOD'] == 'POST' AND isset($_FILES['image'])) 
			{
				
				// settings
				$max_file_size = 1024*200; // 200kb
				$valid_exts = array('jpeg', 'jpg', 'png', 'gif');
				// thumbnail sizes
				$sizes = array(60 => 58, 204 => 179, 900 => 900);
				 
				  if($_FILES['image']['tmp_name'][0]=='')
				   {
					$response	=	'Added Successfully';
					echo("<script>window.location=\"view_products.php?response=".urlencode($response)."\"</script>");  
					   
				   }else
				   {
					foreach($_FILES['image']['tmp_name'] as $key => $tmp_name ){
						
					 
					
						// get file extension
						
						$ext = strtolower(pathinfo($_FILES['image']['name'][$key], PATHINFO_EXTENSION));
						if (in_array($ext, $valid_exts)) {
							/* resize image */
							foreach ($sizes as $w => $h)
							{
								$temp_name	=	resize($w,$h,$key);
								$files[]	  =	$temp_name;
								$image_query	=	mysql_query("INSERT INTO product_images VALUES('','".$p_id."','".$temp_name."')");
								if(isset($image_query))
								{
									$response	=	'Successfull';
									echo("<script>window.location=\"view_products.php?response=".urlencode($response)."\"</script>");
								}
								else
								{
									$response	=	mysql_error();
									echo("<script>window.location=\"product.php?response=".urlencode($response)."\"</script>");
								}
							}
				
						 } 
					}
				   }
					
				
			}
			
	}
	}
	else
	{
		if(empty($collections))
		{
			$response = 'Assign Collection To Product';	
		}else
		{
		$response	=	'Specify Product Name';
		}
		echo("<script>window.location=\"product.php?response=".urlencode($response)."\"</script>");
	}
}




?>