<?php

session_start();
include 'connect.php';

if(empty($_SESSION['user_email']) && empty($_SESSION['user_id']))
{
	$_SESSION['user_id'] = rand(1, 1000000);
}

$tmp_stamp	=	time();

$pro_type_id    =   isset($_REQUEST['product']) ? $_REQUEST['product'] : '';

if(!empty($pro_type_id))
{
$t_name = explode('_',$pro_type_id);
$type_id    =   $t_name[1];
if($t_name[0]=='P')
{
	
    $type='product';
    $tab_name='product';
    $tab_img='product_images';
	
   
}
else if($t_name[0]=='D')
{
    $type='diamond';
    $tab_name='diamond';
    $tab_img='diamond_images';
    
}
else if($t_name[0]=='Pl')
{
    $type='pearl';
    $tab_name='pearl';
    $tab_img='pearl_images';
   
}
else if($t_name[0]=='S')
{
    $type='setting';
    $tab_name='setting';
    $tab_img='setting_images';

}
else if($t_name[0]=='C')
{
    $type='product';
    $tab_name='product';
    $tab_img='product_images';
    
}
else if($t_name[0]=='G')
{
    $type='gemstone';
    $tab_name='gemstone';
    $tab_img='gemstone_images';
    
}


	if($_SESSION['user_id'] != '' && $_SESSION['user_email']== '')
	{	
	
		$query = mysql_query("SELECT * FROM recent_product WHERE user_id = '".$_SESSION['user_id']."' AND pro_id ='".$type_id."' AND type='".$type."' AND sold_status='0'");
		$count_pr = mysql_num_rows($query);
		if($count_pr>0)
		{
				
			mysql_query('UPDATE recent_product SET pro_id="'.$type_id.'",start_time= "'.$tmp_stamp.'" WHERE user_id="'.$_SESSION['user_id'].'" AND 	 pro_id="'.$type_id.'" AND type="'.$type.'"');  
		}
		else
		{
			mysql_query("INSERT INTO recent_product(user_id,pro_id,status,channel,type,start_time,sold_status) VALUES('".$_SESSION['user_id']."','".$type_id."','0','web','".$type."','".$tmp_stamp."','0')");
		}
		
	
	}
	
	else if($_SESSION['user_email'] != '')
	{
		
		
		$query_email = mysql_query("SELECT * FROM recent_product WHERE user_id = '".$_SESSION['user_email']."' AND pro_id ='".$type_id."' AND type='".$type."' AND sold_status='0'");
		$count_em = mysql_num_rows($query_email);
		
		if($count_em>0)
		{
			mysql_query("UPDATE recent_product SET pro_id='".$type_id."',status='1',start_time='".$tmp_stamp."' WHERE user_id='".$_SESSION['user_email']."' AND pro_id='".$_REQUEST['product']."'");  
		}
		else
		{
			mysql_query("INSERT INTO recent_product(user_id,pro_id,status,channel,type,start_time,sold_status) VALUES('".$_SESSION['user_email']."','".$type_id."','1','web','".$type."','".$tmp_stamp."','0')");
		}
		
		$query_ch=mysql_query("select * from  recent_product where user_id='".$_SESSION['user_id']."'");
         $count_ch = mysql_num_rows($query_ch);
        if($count_ch>0)
        {
			while($row=mysql_fetch_array($query_ch))
            {
                $query_p=mysql_query("select * from recent_product where pro_id='".$row['pro_id']."' AND user_id='".$_SESSION['user_email']."' AND type='".$type."' AND sold_status='0'");
                $count_cp=mysql_num_rows($query_p);
                if($count_cp>0)
                {
                    $query_del=mysql_query("delete from recent_product where pro_id='".$row['pro_id']."' AND user_id='".$_SESSION['user_id']."' AND type='".$type."'");
                }else
                {
					
				$query_dell=mysql_query("delete from recent_product where pro_id='".$row['pro_id']."' AND user_id='".$_SESSION['user_id']."' AND type='".$type."'");
                $query_de=mysql_query("INSERT INTO recent_product(user_id,pro_id,status,channel,type,start_time,sold_status) VALUES('".$_SESSION['user_email']."','".$row['pro_id']."','1','web','".$type."','".$tmp_stamp."','0')");  
				 
                }
            }
        }
		
		
	}
}
	


?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Bay Jewelers ::</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="assets/css/style-main.css" rel="stylesheet" type="text/css" />
<link href="assets/css/responsive.css" rel="stylesheet" type="text/css" />

<script src="assets/js/mtr-pop.js" type="text/javascript"></script>
<script src="assets/js/jquery-1.9.1.min.js" type="text/javascript"></script>

</head>

<body>
<div class="main-container">

<!-- Top --->
<div class="top">

            <div class="top-in">
                <div class="logo"><a href="index.php"><img src="assets/images/logo.png" border="0" /></a></div>
            
            
            <div class="top-link">
        
            <ul>
               <li><a href="
                        <?php
						if(empty($_SESSION['user_email']))
						{
							echo 'login.php';
						}else
						{
							echo 'my_account.php';
						}
						?>
                        "> My acoount</a>
                 <div class="top-sub-in">
                	<ul>
                    	<li><a href="
                        <?php
						if(empty($_SESSION['user_email']))
						{
							echo 'login.php';
						}else
						{
							echo 'hold_history.php';
						}
						?>
                        "> Hold History</a></li>
                    	<li><a href="
                         <?php
						if(empty($_SESSION['user_email']))
						{
							echo 'login.php';
						}else
						{
							echo 'recent_shows.php';
						}
						?>
                        "> Recently View</a></li>
                    	<li><a href="
                         <?php
						if(empty($_SESSION['user_email']))
						{
							echo 'login.php';
						}else
						{
							echo 'my_account.php';
						}
						?>
                        "> Account Setting</a></li>
                    </ul>
                </div>         
                </li>
                    <li style="border-right:none;">
                    <?php
                    if(isset($_SESSION['user_email']))
					{
					?>
                    <a href="logout.php">Logout</a>
                    <?php
					}else{
					?>
                    <a href="login.php">Login</a>
                    <?php
					}
					?>
                    </li>
            
            </ul>

        </div>
        <div class="clear"></div>        
<!-- Navigation-------------->
<div class="menu_bar-grid">

<div class="menu_bar">
	<ul>
    	<li><a href="index.php">Home</a></li>
    	<li><a href="about.php">About Us</a></li>
    	<li><a href="javascript:void(0)">Browse Jewelry </a>
        
        <div class="drop_down">
	<div class="drop-box">
    	<h2>Browse Jewelry</h2>
        
        <div class="pro-range_box">
        <?php
				$type_query=mysql_query("select * from product_type");
				$count_type = mysql_num_rows($type_query);
				if($count_type>0)
				{
					while($row=mysql_fetch_array($type_query))
					{
					?>
                     <div class="pro-range">
                        <div class="pro-range_pic"><img src="uploads_type/<?=$row['image']?>" /></div>
                        <p><a href="browse.php?pro=P_<?=$row['id'];?>"><?=$row['name']?></a></p>
                    </div>
                    						
					<?php
                    }
					
				}
				?>
       
		
       
        <div class="clear"></div>
        </div>
        
        <div class="more-prod">
        	<h5> More Product :-</h5>
            <ul>
            	<li><a href="browse.php?pro=D_all"> Loose Diamonds</a></li>
            	<li><a href="browse.php?pro=G_all"> Gemstones</a></li>
            	<li><a href="browse.php?pro=Pl_all"> Pearls</a></li>
            </ul>
        </div>
    </div>
</div>
        
        </li>
    	<li><a href="javascript:void(0)">Collections</a>
        
        <div class="drop_down1">
	<div class="drop-box">
    	<h2>Collections</h2>
        
        <div class="pro-range_box">
        
        <?php
		$collections_query	=	mysql_query("select * from collection_type LIMIT 4");
		$count_c			  =	mysql_num_rows($collections_query);
		if($count_c>0)
		{
			while($collec=mysql_fetch_array($collections_query))
			{
		?>
        
        <div class="pro-range">
        
        	<div class="pro-range_pic"><img src="uploads_collection/<?=$collec['image']?>" /></div>
            <p><a href="browse.php?pro=C_<?=$collec['id']?>"><?=$collec['name']?></a></p>
            
        </div>
        
			<?php
                }
            }
            ?>
        

        
        <div class="clear"></div>
        </div>
        
        <div class="more-prod">
        	<h5> More Product :-</h5>
            <ul>
            	<li><a href="#"> Loose Diamonds</a></li>
            	<li><a href="#"> Gemstones</a></li>
            	<li><a href="#"> Pearls</a></li>
            </ul>
        </div>
    </div>
</div>
        
        </li>
    	<li><a href="contact.php">Contact Us</a></li>

    
    </ul>

</div>

<div class="clear"></div>

<div class="mob_menubar">
<!--<div class="mob_menu_icon"><a href="#"><img src="assets/images/menu-icon.png" /></a>-->
<div class="mob_menubar_grid">

<select id="media_change">
<option value="" > Menu</option>
<option value="index.php"> Home</option>
<option value="about.php"> About Us</option>
<option value="#"> Browse Gallery</option>
<option value=""> -Rings</option>
<option value="neckleces"> --Neckleces</option>
<option value="earrings"> ---Earrings</option>
<option value="bracelets"> ----Bracelets</option>
<option value="#"> Collections</option>
<option value="weddings"> -Weddings</option>
<option value="gifts"> --Gifts</option>
<option value="contacts"> Contact Us</option>

</select>
</div>
</div>

</div>

<!-- Mob_Navigation End-------------->

</div>
<!-- Navigation End-------------->


    
    </div>
    <div class="clear"></div>
<script>
$(document).ready(function()
{
	$('#media_change').change(function()
	{
		var loc=$('#media_change').val();
		window.location=loc;
	});
	
});
</script>