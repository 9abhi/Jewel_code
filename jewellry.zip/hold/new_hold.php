<?php
include "../connect.php";
session_start();
$user_email	=	    mysql_real_escape_string(isset($_REQUEST['email_new'])? $_REQUEST['email_new'] : '');
$password	  =	    mysql_real_escape_string(isset($_REQUEST['password_new'])? $_REQUEST['password_new'] : '');
$confirm_pass  =	mysql_real_escape_string(isset($_REQUEST['confirm_pass'])? $_REQUEST['confirm_pass'] : '');
$fname  =			mysql_real_escape_string(isset($_REQUEST['fname'])? $_REQUEST['fname'] : '');
$lname  =			mysql_real_escape_string(isset($_REQUEST['lname'])? $_REQUEST['lname'] : '');
$hold_this  =		isset($_REQUEST['hold_this'])? $_REQUEST['hold_this'] : '';
$item_id  =			isset($_REQUEST['item_id'])? $_REQUEST['item_id'] : '';
$contact  =			isset($_REQUEST['contact_no']) ? $_REQUEST['contact_no'] : '';
$item_type  =			isset($_REQUEST['item_type']) ? $_REQUEST['item_type'] : '';
$date_time	=	    time();

if(!filter_var($user_email, FILTER_VALIDATE_EMAIL))
  {
  echo "4_E-mail is not valid";
  
  }
else
{  
$query=mysql_query("select * from customers where email='".$user_email."'");
$count	=	mysql_num_rows($query);
if($count>0)
{
	echo '3_Email already taken please Login to your account';
}
else if($password	==	$confirm_pass)
{
	$enc_password	=	md5($password);
	$result	=	mysql_query("INSERT INTO customers SET email='".$user_email."' ,password = '".$enc_password."',date_time='".$date_time."',fname='".$fname."',lname='".$lname."', phone1='".$contact."'");
	if($result)
	{
		
		//$to      = $user_email;
		//$subject = 'Thanks';
		//$message = 'This is from Bay Jewellers. Your Username is'.$user_email.'</br>Password is '.$password;
		//$headers = 'From: webmaster@example.com' . "\r\n" .
		//'Reply-To: webmaster@example.com' . "\r\n" .
		//'X-Mailer: PHP/' . phpversion();
		
		//mail($to, $subject, $message, $headers);
		
		$_SESSION['user_email']=$user_email;

		if($hold_this=='1')
		{


			$item_hold	=	mysql_query("INSERT INTO hold_item VALUES('','".$item_id."','".$user_email."','".$hold_this."','".$item_type."','".$date_time."')");
			if($item_hold)
			{
				echo '1_Item hold succssfully';
			}
			else
			{
				echo '5_'.mysql_error();
			}
		}else
		{
			echo '6_Account created but not hold this product';
		}
		
		
	}
	else
	{
		echo '2_Oops something is wrong'.mysql_error();
	}
	
	
}
else if($password != $confirm_pass)
{
	echo '0_Password did not match';	
}
}
?>