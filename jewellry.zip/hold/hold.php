<?php
include "../connect.php";
session_start();
$hold_this    =      isset($_REQUEST['hold_this'])? $_REQUEST['hold_this'] : '';
$item_id      =	  isset($_REQUEST['item_id'])? $_REQUEST['item_id'] : '';
$ch_session   =      isset($_REQUEST['ch_session'])? $_REQUEST['ch_session'] : '';
$item_type  =			isset($_REQUEST['item_type']) ? $_REQUEST['item_type'] : '';
$date_time	=	  time();

//echo date('Y-m-d H:i:s',$date).'</br>';

//echo $dat = strtotime("+2 day");
//echo date('Y-m-d H:i:s',$dat).'</br>';

$check_today	=	time();
$get_query=mysql_query("select * from hold_item where user ='".$ch_session."' AND item_id='".$item_id."' AND item_type='".$item_type."'");
$get_count=mysql_num_rows($get_query);
if($get_count>0)
{
	if($hold_this=='1')
	{
		$get_chk=mysql_fetch_array($get_query);
		$chk_tm=$get_chk['date_time'];
		$chk_dt= strtotime("+2 day",$chk_tm);
		
		if($check_today<$chk_dt)
		{
			$up_query = mysql_query("UPDATE hold_item SET date_time='".$check_today."',status='".$hold_this."' WHERE user ='".$ch_session."' AND item_id='".$item_id."' AND item_type='".$item_type."'");
			if($up_query)
			{
				echo '1_Hold Successfully';
			}
			else
			{
				echo '0_Oops something is wrong'.mysql_error();
			}
			
		}
		else
		{
			echo '2_Already hold';
		}
	}else
	{
		$up_query 	=	mysql_query("UPDATE hold_item SET date_time='".$check_today."', status='".$hold_this."' WHERE user ='".$ch_session."' AND item_id='".$item_id."' AND item_type='".$item_type."'");
			if($up_query)
			{
				echo '7_Unhold Successfully';
			}
			else
			{
				echo '0_Oops something is wrong'.mysql_error();
			}
	}
	
	
	
}
else
{
	$in_query=mysql_query("INSERT INTO hold_item VALUES('','".$item_id."','".$ch_session."','".$hold_this."','".$item_type."','".$check_today."'	)");
	if($in_query)
	{
		echo '1_Hold Successfully';
	}
	else
	{
		echo '0_Oops something is wrong'.mysql_error();
	}
}





?>