<?php
include "header.php";
include "connect.php";
include "admin/inc/function.php";


if(!empty($type_id))
{
	$get_product=mysql_query("select * from $tab_name where id='".$type_id."'");
	$count_p = mysql_num_rows($get_product);
	if($count_p>0)
	{
		$get_data = mysql_fetch_array($get_product);
		$get_img_query=mysql_query("select * from $tab_img where p_id='".$type_id."' AND image LIKE '900x900%' LIMIT 1");
		$img_count=mysql_num_rows($get_img_query);
		if($img_count>0)
		{
			$large_img=mysql_fetch_array($get_img_query);
		}
	
?>

<!-- Top End--->

<link href="admin/bootstrap/css/bootstrap.css" type="text/css" rel="stylesheet" media="screen" />

       
<!-- Main pic--->
<div class="inner-banner">

	<div class="diamond-p">
    <img src="assets/images/diamond-p.png" />
    </div>

<div class="heading-b">
<h2>The Celebrations</h2>
    	<h1>DIAMOND</h1>
        <p>Collections </p> 
        
        <a href="#" class="order-in">Order Now!</a>
       
</div>
</div>

<!-- Main pic End--->

<!-- Main box--->
<div class="inner-middle">
<!-- inner Box--->
	<div class="product-main">
    <div class=" product-main-left">
    
    <h2><?=$get_data['name']?></h2>
    
    <p style="font-size:14px; color:#666;">
    <?php
	if(array_key_exists('excerpt',$get_data))
	{
		echo $get_data['excerpt'];
	}else
	{
		
	}
	?>
    </p>
      
       <div class="slect-prod">
       
   		<div class="prod-big" id="zoom_img">
        <img id="new_img" src="uploads/<?=$large_img['image']?>" />
        	
        </div>
         <div class="small-pic-bar">
        <?php

		$get_small_pic=mysql_query("select * from $tab_img where p_id='".$type_id."' AND image LIKE '60x58%'");
		$get_small_count=mysql_num_rows($get_small_pic);
		if($get_small_count>0)
		{
			while($sml=mysql_fetch_array($get_small_pic))
			{
		?>
          
                <div class="prod-small">
                	<img src="uploads/<?=$sml['image']?>" onclick="change_img('<?=$sml['image']?>')" />
                </div>
               
                
                <?php
			}
		}
				?>
                <div class="clear"></div>
           </div>
           </div>
   
</div>

	<div class="product-main-right">
    <div class="disc-box">
    
    	<h3 style="color:#666;">Description</h3>
        <p><?=$get_data['description'];?></p>
        
        <?php
        if(array_key_exists('composed',$get_data) )
		{
			if(!empty($get_data))
			{
		?>
        <h3 style="color:#666;">Composed of</h3>
        <p>
		<?php
		$arr_data=explode(',',$get_data['composed']);
        foreach($arr_data as $ab)
		{
			$av=explode('_',$ab);
			echo $av[2].'</br>';
		}
			}
		}
		?></p>
        
        <div class="pro-price">
        <p>Product Price :</p>
        <b style="color:#F30;"><?=format_currency($get_data['retail_price'])?>
        </div>
          <div  class="holding_b">
        	<a id="hold_item"   style="cursor:pointer; text-decoration:none;">
            <?php
				if(!empty($_SESSION['user_email']))
				{
					
		$get_query_h=mysql_query("select * from hold_item where user ='".$_SESSION['user_email']."' AND item_id='".$type_id."' AND item_type='".$tab_name."' AND 		 								  status='1'");
					$get_count_h=mysql_num_rows($get_query_h);
					if($get_count_h>0)
					{
						$get_chk_h=mysql_fetch_array($get_query_h);
						$chk_tm_h=$get_chk_h['date_time'];
						$chk_dt_h= strtotime("+2 day",$chk_tm_h);
						$check_today	=	time();
						if($check_today<$chk_dt_h)
						{
							echo 'Holded';
							
						}else
						{
							echo 'Hold';
						}
						
					}
					else
					{
						echo 'Hold';
					}
				}
				else
				{
					echo 'Hold';
				}
				?>
             </a>
        </div>
        </div>
      
    </div>
    
<div class="clear"></div>
</div>

<?php

	$get_coll=mysql_query("select * from $tab_name  ORDER BY id DESC LIMIT 4");
	$get_all_count=mysql_num_rows($get_coll);
	if($get_all_count>0)
	{
		
?>


<div class="more_product">
	<div class="line"></div>
    <div class="col_grid_1">Bay Jewelers More Products</div>
    
    <div class="in-mtr-box">
   
<?php
while($pro=mysql_fetch_array($get_coll))
{
	 $get_pimages	=	mysql_query("select * from $tab_img where p_id='".$pro['id']."' AND image LIKE '204x179%' LIMIT 1");
				   $count_img	=	mysql_num_rows($get_pimages);
				   if($count_img>0)
				   {
					   $p_img=mysql_fetch_array($get_pimages);
					   
				   }
?>           
           
           <div class="product">
           <a style="font-size: 12px; text-decoration:none;color: #666;" href="product_details.php?product=<?=$t_name[0]?>_<?=$pro['id']?>">
            <div class="product_pic">
                <img src="uploads/<?=$p_img['image']?>" />
            </div>
            <h3><?=$pro['name'];?></h3>
            </a>
            <div class="product_disc">
            <?php
				$string = strip_tags($pro['description']);
				
				if (strlen($string) > 16) {
				
					// truncate string
					$stringCut = substr($string, 0, 50);
				
					// make sure it ends in a word so assassinate doesn't become ass...
					$string = substr($stringCut, 0, strrpos($stringCut, ' ')).'... <a style="color:#C60;" href="">More</a>'; 
				}
				echo $string;
                   ?>
            </div>
            <div class=" price_pro">
            <?=format_currency($pro['retail_price']);?>
            </div>
           
           </div>

<?php
}
?>
           

   <div class="clear"></div>
</div><br />
<br />

</div>
<div class="modal fade" id="hold_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display:none;">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title" id="myModalLabel">Hold &nbsp;<?=$get_data['name'];?></span> </h4>
              </div>

              <div class="modal-body">
             <?php
			 if(empty($_SESSION['user_email']))
			 { ?>
			<form class="form-horizontal" method="post" name="new_hold" id="new_hold">
                                   
                                   <div class="control-group">
                                       <label>Enter Details</label>
                                       </div>
                                        <div class="control-group">
                                         
                                          <div class="span3">
                                          <input class="input-file uniform_on" placeholder="First Name" id="fname" name="fname" type="text">
                                            
                                            </div>
                                            
                                             <div class="span3">
                                             
                                             <input class="input-file uniform_on" id="lname" placeholder="Last Name" name="lname" type="text">
                                             <input type="hidden" value="<?=$type_id?>" name="item_id" />
                                             <input type="hidden" value="<?=$type?>" name="item_type" />
                                            
                                          </div>
                                          
                                        </div>
                                       
                                       <hr>
                                        <div class="control-group">
                                            <label>Account info</label>
                                       </div>
                                   
                                        <div class="control-group">
                                         
                                          <div class="span3">
                                          <input class="input-file uniform_on" placeholder="Email" id="email_new" name="email_new" type="email" />
                                            
                                            </div>
                                            
                                             <div class="span3">
                                             
                                          <input class="input-file uniform_on" id="password_new" placeholder="password"  name="password_new" type="password" />
                                            
                                          </div>
                                        </div>
                                        
                                        <div class="control-group">
                                         
                                          <div class="span3">
                                          <input class="input-file uniform_on" placeholder="Confirm password" id="confirm_pass" name="confirm_pass" type="password" />
                                            
                                            </div>
                                            <div class="span3">
                                             
                                          <input class="input-file uniform_on" id="contact_no" placeholder="Contact number"  name="contact_no" type="number" />
                                            
                                          </div>
                                            
                                             
                                        </div>
                                       <hr>
                                        <div class="control-group">
                                       <label>Hold If</label>
                                           <div class="span3">

                                            <input type="radio" name="hold_this" value="1" checked />
                                            yes
                                            <input type="radio" name="hold_this" value="0" />
                                            no
                                           </div>
                                       </div>
                                      </form>
                                       
                                   
            	 
			 <?php
             }
			 else
			 {
				 ?>
                 <form class="form-horizontal" method="post" id="al_hold" name="al_hold" >
                 <div class="control-group">
                                       <label>Hold If</label>
                                           <div class="span3">

                                            <input type="radio" name="hold_this" value="1" checked />
                                            yes
                                            <input type="radio" name="hold_this" value="0" />
                                            no

                                           </div>
             <input type="hidden" value="<?=$type_id?>" name="item_id" />
             <input type="hidden" value="<?=$type?>" name="item_type" />
             <input type="hidden" name="ch_session" value="<?php echo isset($_SESSION['user_email']) ? $_SESSION['user_email'] : ''; ?>" id="ch_session" />
                                       </div>
                                      </form>
				 <?php
			 }
			 ?>
                
                 
  
                
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Back</button>
                <button type="button" class="btn btn-primary" id="hold_click" >
                Hold
                
                </button>
              </div>
            </div>
          </div>
        </div>
<?php
  }
 }
}
?>
    </div>

<!-- inner Box End--->
<input type="hidden" name="chk_session" value="<?php echo isset($_SESSION['user_email']) ? $_SESSION['user_email'] : ''; ?>" id="chk_session" />
<div class="four-bnr">
    <a href="#"> <img src="assets/images/bnr-1.png" border="0" /> </a>
    <a href="#"> <img src="assets/images/bnr-2.png" border="0" /> </a>
    <a href="#"> <img src="assets/images/bnr-3.png" border="0" /> </a>
    <a href="#"> <img src="assets/images/bnr-4.png" border="0" /> </a>
    <div class="clear"></div>
    </div>

<div id="saving_container" style="display:none;">
  <div id="saving" style="background-color:#000; position:fixed; width:100%; height:100%; top:0px; left:0px;z-index:100000"></div>
  <img id="saving_animation" src="assets/images/storing_animation.gif" alt="saving" style="z-index:100001; margin-left:-32px; margin-top:-32px; position:fixed; left:50%; top:50%"/>
  <div id="saving_text" style="text-align:center; width:100%; position:fixed; left:0px; top:50%; margin-top:40px; color:#fff; z-index:100001">
  <?php if(empty($_SESSION['user_email'])) { echo 'Creating account and holding...'; } else { 'Holding product'; }?></div>
</div>


<?php
include "footer.php";
?>
</div>
<script src='assets/js/jquery.elevatezoom.js' type="text/javascript"></script>
<script src="admin/bootstrap/js/bootstrap.js" type="text/javascript"></script>
<script>
$(document).ready(function() {

get_zoomer_on(); 
    var form_name='';

    $('#hold_item').click(function(e) {
		e.preventDefault();
      		
		$('#hold_modal').modal('show');
		
    });

    $('#hold_click').click(function()
    { 
			
	    var chk_session=$('#chk_session').val();
     	
        if(chk_session=='')
        {
		     
            form_name='new_hold';

            var email_new 	= $('#email_new').val();
            var password_new = $('#password_new').val();
            var confirm_pass = $('#confirm_pass').val(); 
            
              if(email_new ==  '' || password_new  ==  '' || confirm_pass  ==  '')
              {
                alert('Enter Required Fields');
                return false;
              }
              show_animation();
			  
            var user_new = $('form#'+form_name).serializeArray();
            
            
            $.ajax({
                  type:"POST",
                  url: "hold/new_hold.php",
                  data: $.param(user_new),
                  success: function(data)
                    { 
						alert(data);
                        setTimeout('hide_animation()', 500);
                        var bt=data.split('_');
        
                        if(bt[0]=='1')
                        {
                          
                          $('#hold_modal').modal('hide');
                          
                          $('#hold_item').html('Holded');
						  

                        }
                        else
                        {
							
                         $('#hold_modal').modal('hide');
                         alert(bt[1]);
                        }
                        
                        

                    }

                    });
					
        }
		
        else
        {
			
			show_animation();
			
          form_name='al_hold';
		  
          var user_new = $('form#'+form_name).serializeArray();
            
            $.ajax({
                  type:"POST",
                  url: "hold/hold.php",
                  data: $.param(user_new),
                  success: function(data)
                    {
						setTimeout('hide_animation()', 500);
						
						var bt=data.split('_');
        
                        if(bt[0]=='1')
                        {
                          
                          $('#hold_modal').modal('hide');
                          $('#hold_item').html('Holded');
						  

                        }
                        else if(bt[0]=='7')
                        {
							
                         $('#hold_modal').modal('hide');
						 $('#hold_item').html('Hold');
                         alert(bt[1]);
                        }
                  
                    }
                    });

        }

  
    });
 

  
});
function show_animation()
{
  $('#saving_container').css('display', 'block');
  $('#saving').css('opacity', '.8');
}

function hide_animation()
{
  $('#saving_container').fadeOut();
}
function change_img(img)
{
	var sp_data=img.split('_');
	$('#new_img').attr('src','uploads/900x900_'+sp_data[1]+'_'+sp_data[2]);
	
	get_zoomer_on();
}
function get_zoomer_on()
{
	
	$('#new_img').elevateZoom({tint:true, tintColour:'#000000', tintOpacity:0.2});
}
</script>