<?php
include "header.php";
include "admin/inc/function.php";

?>
<!-- Top End--->

<!-- Main pic--->
<div class="inner-banner">
	<div class="diamond-p">
    <img src="assets/images/diamond-p.png" />
    </div>

    <div class="heading-b">
    <h2>The Celebrations</h2>
            <h1>DIAMOND</h1>
            <p>Collections </p> 
            <a href="#" class="order-in"> Order Now!</a>
           
    </div>
    
</div>

<!-- Main pic End--->

<!-- Main box--->
<div class="inner-middle">
<div class="leftbar-main">

<?php
include "category_bar.php";

?>
    </div>

<!-- inner Box--->
	<div class="contant-box">
    <h2>Hold History</h2>
<?php
$get_history=mysql_query("select * from hold_item where user='".$_SESSION['user_email']."'");
$count_history	=	mysql_num_rows($get_history);
if($count_history>0)
{
	while($get_p=mysql_fetch_array($get_history))
	{
		$tb_name=$get_p['item_type'];
		$get_info=mysql_query("select * from $tb_name where id='".$get_p['item_id']."'");
		$get_d=mysql_fetch_array($get_info);
		$tab_img=get_recent_img($tb_name);
		$get_img=mysql_query("select * from $tab_img where p_id='".$get_p['item_id']."' AND image LIKE '204x179%' LIMIT 1 ");
		$get_img_cnt=mysql_num_rows($get_img);
		if($get_img_cnt>0)
		{
			$r_img=mysql_fetch_array($get_img);
		}else
		{
			$r_img='';
		}
$prf=get_recent_prefix($tb_name);
?>    
 <div class="hold_bar">
 
    	<div class="hold_prod"><img src="uploads/<?=$r_img['image']?>" /></div>
        
        <div class="hold_pro_disc">
        
        <h2>
        <?php
		if($get_d['sold_status']=='1')
		{
			echo $get_d['name'];
		}else
		{ ?>
        <a style="color:#F90; text-decoration:none;" href="product_details.php?product=<?=$prf?>_<?=$get_p['item_id']?>"><?=$get_d['name']?></a>
		<?php }
		?>
        </h2>
        <p>
		<?php echo  htmlspecialchars_decode($get_d['description'], ENT_QUOTES); ?>
		
         </p>
        </div>
        
        <div class="hold_pro_price">
        	<div class=" hold-price">Price</div>
            <p><?=format_currency($get_d['retail_price'])?></p>
        </div>
        
        <div class="hold_pro-date">
        	<div class="prod_date-titl"> Holding Status</div>
            <div style="font-size:14px; text-align:center; width:100px; border:1px solid #ccc; background-color:#f1f1f1; color:#999; margin:4px 0px 4px 0px; padding:1px; border-radius:5px;"><strong>
            <?php
			if($get_p['status']=='1')
			{
				echo 'Hold';
			}else
			{
				echo 'UNHOLD';
			}
			?>
            
            
            </strong></div>
            <div class="prod_date"><?php echo date('d-m-Y h:i A',$get_p['date_time']);?></div>
           
			<?php
			if($get_d['sold_status']=='1')
			{ ?>
				 <div style="font-size:15px; text-align:center; width:100px; border:1px solid #ccc; background-color:#f1f1f1; color:#090; margin:9px 0px 4px 0px; padding:1px; border-radius:5px; text-decoration:line-through;">
				<?php
                echo 'SOLD';
				echo '</div>';
				
			}else
			{
				
			}
			
			?>
        </div>
        
         
        
<div class="clear"></div>        
</div>

<?php
 }
}
?>
        <div class="clear"></div>
    </div>
<div class="clear"></div>
<!-- inner Box End--->

<div class="four-bnr">
    <a href="#"> <img src="assets/images/bnr-1.png" border="0" /> </a>
    <a href="#"> <img src="assets/images/bnr-2.png" border="0" /> </a>
    <a href="#"> <img src="assets/images/bnr-3.png" border="0" /> </a>
    <a href="#"> <img src="assets/images/bnr-4.png" border="0" /> </a>
    <div class="clear"></div>
    </div>

</div>
<?php
include "footer.php";
?>
