<?php
include "header.php";
?>

<!-- Top End--->

<!-- Main pic--->
<div class="inner-banner">
	<div class="diamond-p">
    <img src="assets/images/diamond-p.png" />
    </div>

<div class="heading-b">
<h2>The Celebrations</h2>
    	<h1>DIAMOND</h1>
        <p>Collections </p> 
        <a href="#" class="order-in"> Order Now!</a>
       
</div>
</div>

<!-- Main pic End--->

<!-- Main box--->
<div class="inner-middle">
	
<!-- inner Box--->
	<div class="login_main-box">
	<div class="login_box">
		<h2>Welcome back to Bay Jewelers.</h2>
		<p>We're glad you've returned. We're ready to resume helping you.</p>
		
		<form  name="forgot_password" id="forgot_password" method="post">
		<div id="password-credentials">
			<div class="row">
				<label for="customer_email">Email</label>
                <input type="email" name="customer_email" id="customer_email" size="30" tabindex="1" class="title"  />
               
				
			</div>
			
		</div>
		<br />

    <input type="submit" name="forgot_submit" id="forgot_submit" value="Reset My Password" class="sign-in-btn" />
   
</form>		
	</div>
    
    
    
<div class="clear"></div>
</div>

<!-- inner Box End--->

<div class="four-bnr">
    <a href="#"> <img src="assets/images/bnr-1.png" border="0" /> </a>
    <a href="#"> <img src="assets/images/bnr-2.png" border="0" /> </a>
    <a href="#"> <img src="assets/images/bnr-3.png" border="0" /> </a>
    <a href="#"> <img src="assets/images/bnr-4.png" border="0" /> </a>
    <div class="clear"></div>
    </div>

<?php
include "footer.php";
?>
<script>
$(document).ready(function() {
	
  
  

$('#forgot_submit').click(function(e) {
	  e.preventDefault();
	  
	  var customer_email	=	$('#customer_email').val();
	 
	  
	  if(customer_email	==	'' )
	  {
		  alert('Enter Account Email Address');
		  return false;
	  }

	var forgot_dat = $('form#forgot_password').serializeArray();
	
			
			$.ajax({
            type:"POST",
            url: "forgot/forgot_password.php",
			data: $.param(forgot_dat),
            success: function(data)
			{ 
				alert(data);
			}
			
			});
    
});


  
});

</script>