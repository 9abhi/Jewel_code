<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>create account</title>
<script src="jquery-1.9.1.min.js"></script>
</head>

<body>

<table>
<form  name="login_user" id="login_user" method="post">

<tr><td>
<input type="email" name="user_email" id="user_email"  />
</td>
</tr>
<tr><td>
<input type="password" name="password" id="password"  />
</td></tr>
<tr>
<td>
<input type="submit" name="click_submit" id="click_submit" value="Sign In" />
</td>
</tr>
<tr>
<td>
<a id="forgot_pass">forgot password</a>
</td>
</tr>
</form>

</table>

<div style="display:none;" id="forgot_p">

<table>
<form  name="forgot_password" id="forgot_password" method="post">

<tr><td>
<input type="email" name="customer_email" id="customer_email"  />
</td>
</tr>
<tr>
<td>
<input type="submit" name="forgot_submit" id="forgot_submit" value="Reset My Password" />
</td>
</tr>
</form>

</table>

</div>
</body>
</html>

<script>
$(document).ready(function() {
	
  
  $('#click_submit').click(function(e) {
	  e.preventDefault();
	  
	  var user_email	=	$('#user_email').val();
	  var password	  =	$('#password').val();
	 
	  
	  if(user_email	==	'' || password	==	'' )
	  {
		  alert('Enter required fields');
		  return false;
	  }

	var user_dat = $('form#login_user').serializeArray();
	
			
			$.ajax({
            type:"POST",
            url: "check_login.php",
			data: $.param(user_dat),
            success: function(data)
			{ 
				alert(data);
			}
			
			});
    
});
$('#forgot_pass').click(function(e) {
    e.preventDefault();
	
	$('#forgot_p').show(300);
});
$('#forgot_submit').click(function(e) {
	  e.preventDefault();
	  
	  var customer_email	=	$('#customer_email').val();
	 
	  
	  if(customer_email	==	'' )
	  {
		  alert('Enter Account Email Address');
		  return false;
	  }

	var forgot_dat = $('form#forgot_password').serializeArray();
	
			
			$.ajax({
            type:"POST",
            url: "forgot_password.php",
			data: $.param(forgot_dat),
            success: function(data)
			{ 
				alert(data);
			}
			
			});
    
});


  
});

</script>